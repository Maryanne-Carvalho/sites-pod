/* ==========================================================================
   ATELIÊ DE CORES — Modelo Avançado (Beatriz Nascimento | Podologia)
   Painel de demonstração: 9 paletas + 5 cores manuais (seletor e HEX
   editável), prévia instantânea, relatório de contraste e restauração.

   • Demonstração: a escolha fica salva SÓ neste navegador, com chave
     própria (js/content.js → storageKey) e vale para o site e o portal.
   • Modo real (Supabase): o painel não aparece para visitantes. As cores
     oficiais são salvas por clínica em Painel › Configurações › Identidade
     visual e lidas do banco por todas as páginas.
   • O painel administrativo mantém a própria identidade (não é afetado).
   ========================================================================== */
(function () {
  "use strict";
  var PS = window.PS;
  var theme = PS.theme;
  if (!theme) return;
  var html = document.documentElement;
  if (html.classList.contains("sem-seletor") || document.body.getAttribute("data-area") === "admin") return;

  var NOMES = { primary: "Principal", deep: "Profunda", accent: "Destaque", background: "Fundo", text: "Texto" };
  var DICAS = { primary: "botões e links", deep: "seções escuras e rodapé", accent: "detalhes e filetes", background: "fundo das páginas", text: "textos" };
  function icon(n) { return '<svg class="icon" aria-hidden="true"><use href="#i-' + n + '"/></svg>'; }
  function toast(msg) { if (PS.ui && PS.ui.toast) PS.ui.toast(msg); }

  var linhas = theme.editable.map(function (k) {
    return '<div class="atl-row" data-row="' + k + '">' +
      '<label class="atl-row__sw"><input type="color" data-pick="' + k + '" aria-label="Escolher cor ' + NOMES[k] + '"><span class="atl-row__dot" aria-hidden="true"></span></label>' +
      '<div class="atl-row__txt"><label for="atl-hex-' + k + '">' + NOMES[k] + '</label><small>' + DICAS[k] + "</small></div>" +
      '<input class="atl-row__hex" id="atl-hex-' + k + '" data-hex="' + k + '" inputmode="text" autocomplete="off" spellcheck="false" maxlength="7" aria-describedby="atl-hex-help">' +
      '<button type="button" class="atl-row__reset" data-reset="' + k + '" aria-label="Voltar a cor ' + NOMES[k] + ' ao padrão da paleta" title="Voltar ao padrão da paleta">' + icon("reset") + "</button></div>";
  }).join("");

  document.body.insertAdjacentHTML("beforeend",
    '<button class="atl-fab" type="button" data-atl-open aria-controls="atelie" aria-expanded="false">' +
      '<span class="atl-fab__dots" data-atl-dots aria-hidden="true"></span><span>Ateliê de cores</span></button>' +
    '<section class="atl" id="atelie" role="dialog" aria-modal="false" aria-labelledby="atl-t" hidden data-atl>' +
      '<header class="atl__head"><div><p class="atl__kicker">Demonstração</p><h2 id="atl-t">Ateliê de cores</h2></div>' +
        '<button type="button" class="atl__close" data-atl-close aria-label="Fechar o ateliê de cores">' + icon("close") + "</button></header>" +
      '<p class="atl__label" id="atl-pal">Paletas · <strong data-atl-current></strong></p>' +
      '<div class="atl__pals" role="radiogroup" aria-labelledby="atl-pal" data-atl-pals></div>' +
      '<p class="atl__label">Cores manuais</p>' +
      '<div class="atl__rows">' + linhas + "</div>" +
      '<p class="atl__help" id="atl-hex-help">Digite o código no formato #RRGGBB. A prévia é instantânea.</p>' +
      '<div class="atl__checks" data-atl-checks aria-live="polite"></div>' +
      '<button type="button" class="atl__restore" data-atl-restore>' + icon("reset") + "Restaurar identidade original</button>" +
      '<p class="atl__foot">Vale para o site e a Área do cliente e fica salvo apenas neste navegador.</p>' +
    "</section>");

  var panel = document.querySelector("[data-atl]");
  var fab = document.querySelector("[data-atl-open]");
  var pals = panel.querySelector("[data-atl-pals]");

  var botoes = PS.palettes.map(function (p) {
    var b = document.createElement("button");
    b.type = "button"; b.className = "atl-pal"; b.setAttribute("role", "radio"); b.setAttribute("aria-checked", "false"); b.tabIndex = -1;
    b.dataset.palette = p.id;
    b.innerHTML = '<span class="atl-pal__sw" aria-hidden="true">' +
      ["primary", "deep", "accent", "background"].map(function (k) { return '<i style="background:' + p.colors[k] + '"></i>'; }).join("") +
      '</span><span class="atl-pal__n"></span>';
    b.querySelector(".atl-pal__n").textContent = p.name;
    b.addEventListener("click", function () {
      var r = theme.setPalette(p.id);
      toast("Paleta “" + r.palette.name + "” aplicada.");
    });
    pals.appendChild(b);
    return b;
  });
  pals.addEventListener("keydown", function (e) {
    var i = botoes.indexOf(document.activeElement);
    if (i < 0) return;
    var n = { ArrowRight: 1, ArrowDown: 1, ArrowLeft: -1, ArrowUp: -1 }[e.key];
    if (!n) return;
    e.preventDefault();
    var b = botoes[(i + n + botoes.length) % botoes.length];
    b.focus(); b.click();
  });

  panel.querySelectorAll("[data-pick]").forEach(function (inp) {
    inp.addEventListener("input", function () { theme.setOverride(inp.dataset.pick, inp.value, { animate: false }); });
  });
  panel.querySelectorAll("[data-hex]").forEach(function (inp) {
    inp.addEventListener("input", function () {
      var v = inp.value.trim();
      if (v && v.charAt(0) !== "#") v = "#" + v;
      var ok = /^#[0-9a-fA-F]{6}$/.test(v);
      var ruim = !/^#?[0-9a-fA-F]{0,6}$/.test(inp.value.trim()) || (v.length >= 7 && !ok);
      inp.setAttribute("aria-invalid", ruim ? "true" : "false");
      if (ok) theme.setOverride(inp.dataset.hex, v, { animate: false });
    });
    inp.addEventListener("blur", function () { sync(theme.getState()); });
  });
  panel.querySelectorAll("[data-reset]").forEach(function (b) {
    b.addEventListener("click", function () { theme.resetColor(b.dataset.reset); toast("Cor " + NOMES[b.dataset.reset] + " restaurada."); });
  });
  panel.querySelector("[data-atl-restore]").addEventListener("click", function () {
    theme.resetOriginal(); toast("Identidade original restaurada.");
  });

  function sync(st) {
    if (!st) return;
    panel.querySelector("[data-atl-current]").textContent = st.palette.name + (st.customized ? " (personalizada)" : "");
    botoes.forEach(function (b) {
      var on = b.dataset.palette === st.palette.id;
      b.setAttribute("aria-checked", on ? "true" : "false");
      b.tabIndex = on ? 0 : -1;
      b.classList.toggle("is-custom", on && st.customized);
    });
    theme.editable.forEach(function (k) {
      var row = panel.querySelector('[data-row="' + k + '"]');
      var v = st.colors[k];
      row.querySelector("[data-pick]").value = v;
      row.querySelector(".atl-row__dot").style.background = v;
      var hex = row.querySelector("[data-hex]");
      if (document.activeElement !== hex) { hex.value = v.toUpperCase(); hex.setAttribute("aria-invalid", "false"); }
      row.classList.toggle("is-changed", Object.prototype.hasOwnProperty.call(st.overrides, k));
    });
    panel.querySelector("[data-atl-checks]").innerHTML = '<p class="atl__label">Legibilidade (WCAG)</p><ul role="list">' + st.checks.map(function (c) {
      var ok = c.ratio >= 4.5;
      return '<li class="' + (ok ? "ok" : "bad") + '"><span>' + c.name + "</span><strong>" + c.ratio.toFixed(1) + ":1 · " + (c.ratio >= 7 ? "AAA" : ok ? "AA" : "abaixo de AA") + "</strong></li>";
    }).join("") + "</ul>";
    var dots = document.querySelector("[data-atl-dots]");
    if (dots) dots.innerHTML = ["primary", "accent", "deep"].map(function (k) { return '<i style="background:' + st.colors[k] + '"></i>'; }).join("");
  }
  document.addEventListener("ps:themechange", function (e) { sync(e.detail); });
  sync(theme.getState());

  function abrir() {
    panel.hidden = false; fab.setAttribute("aria-expanded", "true"); html.classList.add("atl-aberto");
    var sel = panel.querySelector('[aria-checked="true"]') || botoes[0]; sel.focus();
  }
  function fechar() {
    panel.hidden = true; fab.setAttribute("aria-expanded", "false"); html.classList.remove("atl-aberto"); fab.focus();
  }
  fab.addEventListener("click", function () { if (panel.hidden) abrir(); else fechar(); });
  panel.querySelector("[data-atl-close]").addEventListener("click", fechar);
  document.addEventListener("keydown", function (e) { if (e.key === "Escape" && !panel.hidden) fechar(); });
})();
