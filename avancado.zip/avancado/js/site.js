/* ==========================================================================
   SITE PÚBLICO — Beatriz Nascimento | Podologia (Modelo Avançado)
   Monta cabeçalho, rodapé, textos (data-bind), listas (data-render),
   quadros de foto (data-photo) e botões de WhatsApp (data-whatsapp)
   a partir de js/content.js. Não depende do Básico nem do Elegance.
   ========================================================================== */
(function () {
  "use strict";
  var PS = window.PS = window.PS || {};
  var C = PS.content, CFG = PS.config || {}, SYS = PS.sistema || {};
  var body = document.body;
  var page = body.getAttribute("data-page") || "";
  var R = body.getAttribute("data-raiz") || "";

  function esc(v) {
    return String(v == null ? "" : v).replace(/[&<>"']/g, function (ch) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[ch];
    });
  }
  function icon(n) { return '<svg class="icon" aria-hidden="true"><use href="#i-' + n + '"/></svg>'; }
  function get(path) {
    return path.split(".").reduce(function (o, k) { return o == null ? undefined : o[k]; }, C);
  }
  var demo = !SYS.modo || SYS.modo !== "supabase";

  /* ---------- Destino do botão "Agendar" ----------
     agendamentoOnline: false → o botão leva ao WhatsApp/contato.
     Caso contrário → agendar.html, que usa a demonstração ou o Supabase
     conforme sistema/js/config.js (modo "demo" ou "supabase"). */
  function linkAgendar() {
    if (SYS.agendamentoOnline === false) return R + "contato.html";
    return R + "agendar.html";
  }
  PS.linkAgendar = linkAgendar;

  function logo(cls) {
    return '<a class="brand' + (cls ? " " + cls : "") + '" href="' + R + 'index.html" aria-label="' + esc(C.brand.name) + ' — início">' +
      '<span class="brand__mark" aria-hidden="true">' + esc(C.brand.monogram) + "</span>" +
      '<span class="brand__text"><span class="brand__name">' + esc(C.brand.short) + '</span><span class="brand__sub">' + esc(C.brand.sub) + "</span></span></a>";
  }

  /* ---------- Cabeçalho ---------- */
  function header() {
    var nav = C.pages.map(function (p) {
      return '<li><a href="' + R + p.href + '"' + (p.id === page ? ' aria-current="page"' : "") + ">" + esc(p.label) + "</a></li>";
    }).join("");
    return '<a class="skip-link" href="#conteudo">Pular para o conteúdo</a>' +
      (demo ? '<div class="strip" role="note"><div class="wrap strip__in"><span>Site modelo com dados fictícios</span>' +
        '<a href="' + R + 'demonstracao.html">Central de demonstração ' + icon("arrow-right") + "</a></div></div>" : "") +
      '<header class="top" data-top><div class="wrap top__in">' + logo() +
        '<nav class="top__nav" id="menu" aria-label="Menu principal" data-menu><ul role="list">' + nav + "</ul>" +
          '<div class="top__mobile-extra"><a class="btn btn--primary" href="' + linkAgendar() + '">' + icon("calendar") + "Agendar on-line</a>" +
            '<a class="btn btn--ghost" href="' + R + 'cliente/entrar.html">' + icon("user") + "Área do cliente</a></div></nav>" +
        '<div class="top__actions">' +
          '<a class="top__client" href="' + R + 'cliente/entrar.html">' + icon("user") + "<span>Área do cliente</span></a>" +
          '<a class="btn btn--primary btn--sm" href="' + linkAgendar() + '" data-cta-agendar>' + icon("calendar") + "<span>Agendar</span></a>" +
          '<button class="top__toggle" type="button" aria-controls="menu" aria-expanded="false" aria-label="Abrir menu" data-menu-toggle><span></span><span></span></button>' +
        "</div></div></header>";
  }

  function fotosPexels() {
    var f = PS.photos || {};
    return Object.keys(f).some(function (k) { return /pexels\.com/.test(f[k].src || ""); });
  }

  /* ---------- Rodapé ---------- */
  function footer() {
    var c = C.contact;
    var nav = C.pages.map(function (p) { return '<li><a href="' + R + p.href + '">' + esc(p.label) + "</a></li>"; }).join("");
    var hours = c.hours.map(function (h) { return "<li><span>" + esc(h.days) + "</span><span>" + esc(h.time) + "</span></li>"; }).join("");
    return '<footer class="foot"><div class="wrap">' +
      '<div class="foot__grid">' +
        '<div class="foot__brand">' + logo("brand--light") + '<p class="foot__tag">' + esc(C.brand.tagline) + "</p>" +
          '<a class="btn btn--accent" href="' + linkAgendar() + '">' + icon("calendar") + "Agendar on-line</a></div>" +
        '<div><h2 class="foot__h">Navegação</h2><ul role="list" class="foot__list">' + nav +
          '<li><a href="' + R + 'privacidade.html">Privacidade</a></li></ul></div>' +
        '<div><h2 class="foot__h">Contato</h2><ul role="list" class="foot__list">' +
          '<li><button type="button" class="foot__link" data-whatsapp>' + icon("whatsapp") + "WhatsApp " + esc(c.whatsappDisplay) + "</button></li>" +
          "<li>" + icon("phone") + esc(c.phoneDisplay) + "</li>" +
          "<li>" + icon("mail") + esc(c.email) + "</li>" +
          "<li>" + icon("pin") + c.addressLines.map(esc).join("<br>") + "</li></ul></div>" +
        '<div><h2 class="foot__h">Horários</h2><ul role="list" class="foot__hours">' + hours + "</ul>" +
          '<p class="foot__access"><a href="' + R + 'cliente/entrar.html">Área do cliente</a> · <a href="' + R + 'admin/entrar.html">Área da podóloga</a></p></div>' +
      "</div>" +
      '<div class="foot__base"><p>© <span data-ano></span> ' + esc(C.brand.name) + (demo ? " · conteúdo fictício de demonstração" : "") + "</p>" +
        '<p>' + (fotosPexels() ? "Fotos de demonstração: Pexels · " : "") + 'Modelo Avançado · We Lúmen</p></div>' +
      "</div></footer>" +
      '<div class="toast" role="status" aria-live="polite" data-toast>' + icon("check") + "<span data-toast-text></span></div>";
  }

  var hSlot = document.querySelector('[data-layout="header"]');
  var fSlot = document.querySelector('[data-layout="footer"]');
  if (hSlot) hSlot.outerHTML = header();
  if (fSlot) fSlot.outerHTML = footer();
  var ano = document.querySelector("[data-ano]"); if (ano) ano.textContent = new Date().getFullYear();
  document.querySelectorAll("[data-cta-agendar-link]").forEach(function (a) { a.setAttribute("href", linkAgendar()); });

  /* ---------- Menu no celular ---------- */
  var tog = document.querySelector("[data-menu-toggle]"), menu = document.querySelector("[data-menu]");
  if (tog && menu) {
    function fechar() { menu.classList.remove("is-open"); tog.setAttribute("aria-expanded", "false"); tog.setAttribute("aria-label", "Abrir menu"); body.classList.remove("menu-aberto"); }
    tog.addEventListener("click", function () {
      var abrir = !menu.classList.contains("is-open");
      if (!abrir) return fechar();
      menu.classList.add("is-open"); tog.setAttribute("aria-expanded", "true"); tog.setAttribute("aria-label", "Fechar menu"); body.classList.add("menu-aberto");
      var a = menu.querySelector("a"); if (a) a.focus();
    });
    document.addEventListener("keydown", function (e) { if (e.key === "Escape" && menu.classList.contains("is-open")) { fechar(); tog.focus(); } });
    window.addEventListener("resize", function () { if (window.innerWidth > 960) fechar(); });
  }
  var top = document.querySelector("[data-top]");
  if (top) {
    var onScroll = function () { top.classList.toggle("is-scrolled", window.scrollY > 8); };
    window.addEventListener("scroll", onScroll, { passive: true }); onScroll();
  }

  /* ---------- Textos ---------- */
  document.querySelectorAll("[data-bind]").forEach(function (el) {
    var v = get(el.getAttribute("data-bind"));
    if (v != null && v !== "") el.textContent = v;
  });

  /* ---------- Quadros de foto ---------- */
  function placeholder(key, ph) {
    return '<div class="ph" role="img" aria-label="' + esc(ph.alt) + ' (espaço reservado para foto)">' +
      '<span class="ph__mono" aria-hidden="true">' + esc(C.brand.monogram) + "</span>" +
      '<span class="ph__label">' + icon("image") + "Foto real: " + esc(ph.hint) + "</span></div>";
  }
  function photo(key) {
    var ph = (PS.photos || {})[key];
    if (!ph) return "";
    if (!ph.src) return placeholder(key, ph);
    return '<img src="' + esc(ph.src) + '" alt="' + esc(ph.alt) + '"' + (key === "retrato" ? ' fetchpriority="high"' : ' loading="lazy"') +
      ' decoding="async" referrerpolicy="no-referrer" style="object-position:' + esc(ph.position || "50% 50%") + '" data-ph-fallback="' + esc(key) + '">';
  }
  function photos(scope) {
    (scope || document).querySelectorAll("[data-photo]").forEach(function (el) {
      el.innerHTML = photo(el.getAttribute("data-photo"));
    });
    (scope || document).querySelectorAll("img[data-ph-fallback]").forEach(function (img) {
      img.addEventListener("error", function () {
        var k = img.getAttribute("data-ph-fallback");
        img.outerHTML = placeholder(k, PS.photos[k]);
      }, { once: true });
    });
  }

  /* ---------- Listas ---------- */
  var R_ = {
    proof: function () {
      return '<ul role="list" class="proof">' + C.hero.proof.map(function (t) { return "<li>" + icon("check") + esc(t) + "</li>"; }).join("") + "</ul>";
    },
    pillars: function () {
      return C.pillars.map(function (p) {
        return '<article class="pillar"><span class="pillar__n">Nº ' + esc(p.n) + '</span><h3 class="pillar__t">' + esc(p.title) + "</h3><p>" + esc(p.text) + "</p></article>";
      }).join("");
    },
    journey: function () {
      return '<ol class="journey">' + C.journey.map(function (s, i) {
        return '<li class="journey__step"><span class="journey__n" aria-hidden="true">' + (i + 1) + '</span><div><h3>' + esc(s.title) + "</h3><p>" + esc(s.text) + "</p></div></li>";
      }).join("") + "</ol>";
    },
    "services-preview": function () {
      return C.services.slice(0, 3).map(function (s, i) {
        return '<article class="svc-card"><p class="svc-card__tag"><span>' + String(i + 1).padStart(2, "0") + "</span>" + esc(s.tag) + '</p><h3 class="svc-card__t">' + esc(s.title) + "</h3><p>" + esc(s.summary) + "</p>" +
          '<a class="link" href="' + R + "servicos.html#" + esc(s.id) + '">Ver detalhes' + icon("arrow-right") + "</a></article>";
      }).join("");
    },
    services: function () {
      return C.services.map(function (s, i) {
        return '<article class="svc" id="' + esc(s.id) + '"><div class="svc__head"><span class="svc__n">' + String(i + 1).padStart(2, "0") + '</span><p class="svc__tag">' + esc(s.tag) + "</p></div>" +
          '<div class="svc__body"><h2 class="svc__t">' + esc(s.title) + '</h2><p class="svc__sum">' + esc(s.summary) + "</p>" +
          '<ul role="list" class="ticks">' + s.how.map(function (h) { return "<li>" + icon("check") + esc(h) + "</li>"; }).join("") + "</ul></div>" +
          '<div class="svc__act"><a class="btn btn--primary btn--sm" href="' + linkAgendar() + '">' + icon("calendar") + "Agendar</a>" +
          '<button type="button" class="btn btn--ghost btn--sm" data-whatsapp data-servico="' + esc(s.title) + '">' + icon("whatsapp") + "Tirar dúvidas</button></div></article>";
      }).join("");
    },
    "testimonial-featured": function () {
      var t = C.testimonials.filter(function (x) { return x.featured; })[0] || C.testimonials[0];
      return '<blockquote class="quote"><p>“' + esc(t.text) + '”</p><footer><strong>' + esc(t.name) + "</strong> · " + esc(t.service) + "</footer></blockquote>";
    },
    testimonials: function () {
      return C.testimonials.map(function (t) {
        return '<figure class="review"><blockquote><p>“' + esc(t.text) + '”</p></blockquote><figcaption><strong>' + esc(t.name) + "</strong><span>" + esc(t.service) + "</span></figcaption></figure>";
      }).join("");
    },
    "demo-note": function () {
      return C.testimonialsAreDemo ? '<p class="note">' + icon("info") + esc(C.reviewsIntro) + "</p>" : "";
    },
    faq: function () {
      return C.faq.map(function (f) {
        return '<details class="faq"><summary>' + esc(f.q) + '<span class="faq__sign" aria-hidden="true"></span></summary><p>' + esc(f.a) + "</p></details>";
      }).join("");
    },
    "about-story": function () { return C.about.story.map(function (p) { return "<p>" + esc(p) + "</p>"; }).join(""); },
    "about-education": function () {
      return '<ul role="list" class="edu">' + C.about.education.filter(function (e) { return e.title; }).map(function (e) {
        return "<li><strong>" + esc(e.title) + "</strong><span>" + esc(e.place) + (e.year ? " · " + esc(e.year) : "") + "</span></li>";
      }).join("") + '</ul><p class="note">' + icon("info") + esc(C.about.educationNote) + "</p>";
    },
    "about-values": function () {
      return C.about.values.map(function (v) { return '<article class="value"><h3>' + esc(v.title) + "</h3><p>" + esc(v.text) + "</p></article>"; }).join("");
    },
    "clinic-facts": function () {
      return C.clinic.facts.map(function (f) { return '<div class="fact"><strong>' + esc(f.value) + "</strong><span>" + esc(f.label) + "</span></div>"; }).join("");
    },
    "clinic-spaces": function () {
      return C.clinic.spaces.map(function (s, i) {
        return '<article class="space"><figure class="frame frame--' + (i % 2 ? "r" : "l") + '" data-photo="' + esc(s.photo) + '"></figure>' +
          '<div class="space__txt"><span class="space__n">Nº 0' + (i + 1) + "</span><h3>" + esc(s.title) + "</h3><p>" + esc(s.text) + "</p></div></article>";
      }).join("");
    },
    biosafety: function () {
      return '<ol class="bio">' + C.clinic.biosafety.map(function (b) { return "<li><h3>" + esc(b.title) + "</h3><p>" + esc(b.text) + "</p></li>"; }).join("") + "</ol>" +
        '<p class="note note--on-deep">' + icon("info") + esc(C.clinic.biosafetyNote) + "</p>";
    },
    hours: function () {
      return '<ul role="list" class="hours">' + C.contact.hours.map(function (h) { return "<li><span>" + esc(h.days) + "</span><span>" + esc(h.time) + "</span></li>"; }).join("") + "</ul>" +
        '<p class="note">' + icon("info") + esc(C.contact.hoursNote) + "</p>";
    },
    address: function () {
      var c = C.contact;
      return "<address>" + c.addressLines.map(esc).join("<br>") + "</address>" + (c.addressNote ? '<p class="muted">' + esc(c.addressNote) + "</p>" : "") +
        (c.mapUrl ? '<a class="link" href="' + esc(c.mapUrl) + '" target="_blank" rel="noopener">Abrir no mapa' + icon("arrow-right") + "</a>" : "");
    },
    channels: function () {
      var c = C.contact;
      var mail = c.emailLink ? '<a href="mailto:' + esc(c.email) + '">' + esc(c.email) + "</a>" : esc(c.email);
      return '<div class="channel"><span class="channel__ic">' + icon("whatsapp") + '</span><div><h3>WhatsApp</h3><p>' + esc(c.whatsappDisplay) + '</p><button type="button" class="link" data-whatsapp>Enviar mensagem' + icon("arrow-right") + "</button></div></div>" +
        '<div class="channel"><span class="channel__ic">' + icon("calendar") + '</span><div><h3>Agendamento on-line</h3><p>Horários livres em tempo real</p><a class="link" href="' + linkAgendar() + '">Agendar agora' + icon("arrow-right") + "</a></div></div>" +
        '<div class="channel"><span class="channel__ic">' + icon("phone") + "</span><div><h3>Telefone</h3><p>" + esc(c.phoneDisplay) + "</p></div></div>" +
        '<div class="channel"><span class="channel__ic">' + icon("mail") + "</span><div><h3>E-mail</h3><p>" + mail + "</p></div></div>";
    }
  };
  document.querySelectorAll("[data-render]").forEach(function (el) {
    var fn = R_[el.getAttribute("data-render")];
    if (fn) el.innerHTML = fn();
  });
  photos();
  PS.site = { photos: photos, esc: esc, linkAgendar: linkAgendar };

  /* ---------- WhatsApp ---------- */
  function waLink(servico) {
    var w = CFG.whatsapp || {};
    var msg = servico ? (w.serviceMessage || "").replace("{servico}", servico) : w.defaultMessage;
    return "https://wa.me/" + w.number + "?text=" + encodeURIComponent(msg || "");
  }
  function avisoDemo(url) {
    var d = document.createElement("dialog");
    d.className = "dlg";
    d.setAttribute("aria-labelledby", "dlg-wa-t");
    d.innerHTML = '<h2 id="dlg-wa-t">Número de demonstração</h2><p>Este site é um modelo e o WhatsApp exibido é fictício. Na versão final, o botão abre a conversa diretamente com a clínica.</p>' +
      '<div class="dlg__act"><button type="button" class="btn btn--ghost" data-x>Fechar</button><a class="btn btn--primary" href="' + esc(url) + '" target="_blank" rel="noopener" data-x>Abrir mesmo assim</a></div>';
    body.appendChild(d);
    d.addEventListener("close", function () { d.remove(); });
    d.querySelectorAll("[data-x]").forEach(function (b) { b.addEventListener("click", function () { d.close(); }); });
    if (d.showModal) d.showModal(); else d.setAttribute("open", "");
  }
  document.addEventListener("click", function (e) {
    var b = e.target.closest && e.target.closest("[data-whatsapp]");
    if (!b) return;
    e.preventDefault();
    var w = CFG.whatsapp || {};
    if (!w.number) { location.href = R + "contato.html"; return; }
    var url = waLink(b.getAttribute("data-servico"));
    if (w.isDemoNumber) avisoDemo(url); else window.open(url, "_blank", "noopener");
  });

  /* ---------- Entrada suave das seções ---------- */
  var reduz = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  var alvos = document.querySelectorAll("[data-reveal]");
  if (!reduz && "IntersectionObserver" in window) {
    var io = new IntersectionObserver(function (es) {
      es.forEach(function (en) { if (en.isIntersecting) { en.target.classList.add("is-in"); io.unobserve(en.target); } });
    }, { rootMargin: "0px 0px -8% 0px" });
    alvos.forEach(function (el) { el.classList.add("reveal"); io.observe(el); });
  }
})();
