/* ==========================================================================
   BEATRIZ NASCIMENTO | PODOLOGIA — CONTEÚDO DO SITE (Modelo Avançado)

   Arquivo único de personalização das páginas públicas (Início, Sobre,
   Clínica, Serviços, Avaliações, Contato e Privacidade).

   ⚠ TUDO AQUI É DEMONSTRATIVO: a profissional "Beatriz Nascimento", o
   endereço, os telefones, os horários e os depoimentos são fictícios.
   Não há registro profissional, instituição de ensino ou certificação real
   citados — preencha somente com dados verdadeiros e comprováveis.

   ⚠ Estes dados NÃO são os dados operacionais do sistema. Serviços,
   horários e regras de agendamento reais ficam no banco (Supabase) e são
   editados no painel. A demonstração usa sistema/js/dados-demo.js.
   ========================================================================== */

window.PS = window.PS || {};

/* ---------- Configurações técnicas ---------- */
window.PS.config = {
  model: "Avançado",
  defaultPalette: "ameixa-champagne",
  // Chave exclusiva do Avançado (demonstração). Não afeta Básico nem Elegance.
  storageKey: "avancado-demo:beatriz-nascimento:cores",
  imageTimeout: 9000,

  /* WhatsApp: somente dígitos (55 + DDD + número). isDemoNumber: true mostra
     um aviso antes de abrir; troque para false ao usar o número real. */
  whatsapp: {
    number: "5511900000000",              // NÚMERO FICTÍCIO
    isDemoNumber: true,
    defaultMessage: "Olá, Beatriz! Vi o seu site e gostaria de agendar um atendimento.",
    serviceMessage: "Olá, Beatriz! Vi o seu site e gostaria de saber mais sobre: {servico}."
  }
};

/* ---------- Fotos ----------
   Fotos de DEMONSTRAÇÃO do banco Pexels (licença gratuita, uso comercial
   permitido, sem obrigação de crédito — https://www.pexels.com/license/).
   São carregadas direto do Pexels; sem internet, aparece o quadro gráfico.
   ⚠ Na versão final, troque pelas fotos da PRÓPRIA profissional e do PRÓPRIO
   consultório (ex.: "assets/img/beatriz-retrato.jpg"). Veja docs/FOTOS.md.
   Nunca publique pacientes sem autorização por escrito. */
window.PS.photos = {
  retrato:      { src: "https://images.pexels.com/photos/7904416/pexels-photo-7904416.jpeg?auto=compress&cs=tinysrgb&w=1200", position: "50% 22%",
                  alt: "Profissional de saúde sorridente, de jaleco branco, em sua mesa de atendimento", hint: "Retrato vertical da Beatriz, de jaleco, no consultório",
                  credit: "Anna Tarazevich / Pexels" },
  atendimento:  { src: "https://images.pexels.com/photos/5619447/pexels-photo-5619447.jpeg?auto=compress&cs=tinysrgb&w=1200", position: "50% 50%",
                  alt: "Atendimento podológico em consultório", hint: "Beatriz atendendo (mãos, luvas, instrumental) — sem identificar o paciente",
                  credit: "Pexels" },
  sala:         { src: "https://images.pexels.com/photos/5619462/pexels-photo-5619462.jpeg?auto=compress&cs=tinysrgb&w=1200", position: "50% 50%",
                  alt: "Sala de atendimento com cadeira e equipamentos", hint: "Sala de atendimento: cadeira podológica, iluminação, bancada",
                  credit: "Pexels" },
  recepcao:     { src: "https://images.pexels.com/photos/5619496/pexels-photo-5619496.jpeg?auto=compress&cs=tinysrgb&w=1200", position: "50% 50%",
                  alt: "Consultório organizado, com divisória de proteção", hint: "Recepção do consultório",
                  credit: "Pexels" },
  instrumental: { src: "https://images.pexels.com/photos/5619451/pexels-photo-5619451.jpeg?auto=compress&cs=tinysrgb&w=1200", position: "50% 50%",
                  alt: "Profissional de uniforme atendendo sob luminária técnica", hint: "Instrumental esterilizado em embalagem lacrada",
                  credit: "Pexels" },
  detalhe:      { src: "", alt: "Detalhe do consultório", hint: "Detalhe do ambiente (luz, plantas, materiais)" }
};

window.PS.content = {
  brand: {
    name: "Beatriz Nascimento | Podologia",
    short: "Beatriz Nascimento",
    sub: "Podologia",
    monogram: "BN",
    tagline: "Podologia técnica, humana e sem pressa."
  },

  professional: {
    name: "Beatriz Nascimento",
    firstName: "Beatriz",
    role: "Podóloga",
    // Preencha com o registro profissional REAL quando houver. Vazio = não exibido.
    registry: ""
  },

  pages: [
    { id: "inicio", label: "Início", href: "index.html" },
    { id: "sobre", label: "Sobre", href: "sobre.html" },
    { id: "clinica", label: "Clínica", href: "clinica.html" },
    { id: "servicos", label: "Serviços", href: "servicos.html" },
    { id: "avaliacoes", label: "Avaliações", href: "avaliacoes.html" },
    { id: "contato", label: "Contato", href: "contato.html" }
  ],

  /* ======================= INÍCIO ======================= */
  hero: {
    eyebrow: "Podologia · atendimento individual",
    titleStart: "Cuidado técnico para",
    titleEmphasis: "caminhar com confiança.",
    subtitle: "Sou a Beatriz, podóloga. Atendo uma pessoa por vez, com protocolo de biossegurança, explicação clara de cada etapa e orientações que cabem na sua rotina.",
    proof: ["Hora marcada, sem fila", "Instrumental esterilizado e lacrado", "Agendamento on-line 24h"]
  },

  manifesto: {
    kicker: "O que orienta o meu trabalho",
    text: "Pés carregam a história de quem caminha. Meu trabalho é olhar para eles com técnica e respeito — e devolver conforto, informação e autonomia.",
    signature: "Beatriz Nascimento"
  },

  pillars: [
    { n: "01", title: "Técnica", text: "Avaliação criteriosa, procedimentos explicados antes de acontecer e registro do que foi feito." },
    { n: "02", title: "Biossegurança", text: "Instrumental limpo, esterilizado e aberto na sua frente. Descartáveis de uso único." },
    { n: "03", title: "Escuta", text: "Tempo para conversar sobre rotina, calçados e o que incomoda — sem julgamentos." },
    { n: "04", title: "Continuidade", text: "Orientações por escrito e retorno combinado apenas quando fizer sentido." }
  ],

  journey: [
    { title: "Agende on-line", text: "Escolha o serviço, o dia e o horário livre. A confirmação aparece na hora ou após a aprovação da clínica." },
    { title: "Chegue com calma", text: "Hora marcada e intervalo entre atendimentos para a higienização completa da sala." },
    { title: "Avaliação e cuidado", text: "Conversa, avaliação e os cuidados indicados para o seu caso, com pausas sempre que quiser." },
    { title: "Acompanhe pela sua área", text: "Veja, remarque ou cancele seus horários dentro das regras da clínica." }
  ],

  /* ======================= SOBRE ======================= */
  about: {
    heroTitle: "Muito prazer, eu sou a Beatriz.",
    heroText: "Escolhi a podologia porque ela junta duas coisas que me movem: precisão técnica e cuidado com gente. Cada atendimento é uma conversa — e cada pé, uma história diferente.",
    story: [
      "Comecei a me interessar por saúde dos pés ao acompanhar de perto pessoas da minha família que conviviam com dores e incômodos que ninguém explicava direito. Entendi cedo que informação também é cuidado.",
      "Hoje atendo em um consultório pensado nos detalhes: luz adequada, cadeira confortável, instrumental lacrado e tempo para que você entenda o que está acontecendo com os seus pés.",
      "Acredito em uma podologia sem pressa e sem julgamento, que respeita o corpo, a pele e a história de cada pessoa."
    ],
    // Preencha APENAS com formação real e comprovável. Itens vazios não aparecem.
    education: [
      { title: "Formação técnica em Podologia", place: "Instituição a preencher", year: "" },
      { title: "Atualizações e cursos livres", place: "Liste aqui cursos reais concluídos", year: "" }
    ],
    educationNote: "Modelo: substitua por formação, registro e cursos reais. Não invente instituições nem certificações.",
    values: [
      { title: "Respeito", text: "Ao seu tempo, ao seu corpo e às suas escolhas." },
      { title: "Clareza", text: "Você sabe o que será feito, por que e como cuidar depois." },
      { title: "Rigor", text: "Biossegurança não é detalhe: é o ponto de partida." },
      { title: "Representatividade", text: "Um cuidado que acolhe todos os tipos de pele, pés e histórias." }
    ]
  },

  /* ======================= SERVIÇOS =======================
     Textos de apresentação. Duração e preço REAIS vêm do sistema (painel). */
  servicesIntro: "Cada atendimento começa com avaliação. Os cuidados realizados dependem do que o seu caso pede — e são sempre explicados antes.",
  services: [
    { id: "avaliacao", title: "Avaliação podológica", tag: "Primeira consulta",
      summary: "Análise da pele, das unhas e dos pontos de apoio, com um plano de cuidados possível para a sua rotina.",
      how: ["Conversa sobre rotina, calçados e queixas", "Avaliação da pele, unhas e áreas de apoio", "Plano de cuidados e orientações por escrito"] },
    { id: "unhas", title: "Unhas encravadas e espessas", tag: "Unhas",
      summary: "Manejo delicado de unhas que machucam, encravam ou ficaram difíceis de cortar, com orientação para evitar recorrências.",
      how: ["Avaliação da unha e da pele ao redor", "Cuidado indicado, com explicação prévia", "Orientação de corte e calçado"] },
    { id: "calos", title: "Calos e calosidades", tag: "Pele",
      summary: "Remoção cuidadosa de calos e áreas de pressão, investigando a causa para diminuir o retorno.",
      how: ["Identificação dos pontos de pressão", "Desbaste técnico e confortável", "Hidratação e orientações"] },
    { id: "preventivo", title: "Podologia preventiva", tag: "Prevenção",
      summary: "Manutenção periódica de unhas e pele para quem quer manter os pés saudáveis e confortáveis.",
      how: ["Corte técnico das unhas", "Cuidados com a pele", "Orientações para casa"] },
    { id: "sensiveis", title: "Pés sensíveis e pessoas com diabetes", tag: "Cuidado especial",
      summary: "Atendimento atento para pés que exigem mais cuidado, em diálogo com o acompanhamento médico de cada pessoa.",
      how: ["Avaliação detalhada e cuidadosa", "Cuidados com o máximo de segurança", "Orientação sobre sinais de alerta"] },
    { id: "orientacao", title: "Orientação de calçados e rotina", tag: "Educação",
      summary: "Conversa técnica sobre calçados, meias, hidratação e hábitos que fazem diferença no dia a dia.",
      how: ["Análise do calçado de uso diário", "Ajustes possíveis na rotina", "Material de apoio por escrito"] }
  ],
  servicesNote: "A podologia não substitui a consulta médica. Quando necessário, você é orientada a procurar o profissional adequado.",

  /* ======================= CLÍNICA ======================= */
  clinic: {
    heroTitle: "Um consultório pensado nos detalhes.",
    heroText: "Silencioso, organizado e preparado para um atendimento seguro. Uma pessoa por vez, com intervalo entre horários para higienização completa.",
    facts: [
      { value: "1", label: "pessoa por horário" },
      { value: "15 min", label: "entre atendimentos para higienização (exemplo)" },
      { value: "100%", label: "com hora marcada" }
    ],
    spaces: [
      { title: "Ambiente organizado", text: "Espaço limpo e silencioso, com divisória de proteção e materiais sempre em ordem.", photo: "recepcao" },
      { title: "Sala de atendimento", text: "Cadeira podológica reclinável, iluminação técnica e privacidade total.", photo: "sala" },
      { title: "Luz e precisão", text: "Luminária técnica e instrumental à mão para um trabalho minucioso, confortável e seguro.", photo: "instrumental" }
    ],
    biosafety: [
      { title: "Limpeza", text: "Instrumental lavado e seco logo após cada atendimento." },
      { title: "Esterilização", text: "Esterilização em autoclave, com controle de cada ciclo." },
      { title: "Embalagem lacrada", text: "Guardado em embalagem fechada e identificada até o uso." },
      { title: "Abertura na sua frente", text: "A embalagem é aberta no início do seu atendimento." }
    ],
    biosafetyNote: "Exemplo de protocolo. Descreva somente o que é praticado de fato no consultório."
  },

  /* ======================= AVALIAÇÕES =======================
     Substitua por relatos REAIS e AUTORIZADOS e mude testimonialsAreDemo para false.
     Não publique notas, estrelas ou números inventados. */
  testimonialsAreDemo: true,
  reviewsIntro: "Relatos de exemplo, para mostrar como a página fica. Na versão final, use apenas depoimentos reais, com autorização.",
  testimonials: [
    { text: "Fui recebida pelo nome, sem pressa. Ela explicou cada etapa antes de começar e me deu as orientações por escrito.", name: "Ana", service: "Avaliação podológica", featured: true },
    { text: "Ver a embalagem do instrumental sendo aberta na minha frente me deixou muito tranquila.", name: "Patrícia", service: "Unhas encravadas" },
    { text: "Levei minha mãe, que tem diabetes. A paciência e o cuidado fizeram toda a diferença para ela.", name: "Rodrigo", service: "Pés sensíveis" },
    { text: "Agendei pelo site às onze da noite e a confirmação chegou na hora. Prático demais.", name: "Juliana", service: "Podologia preventiva" },
    { text: "Trabalho em pé o dia inteiro. Entendi o papel do calçado e mudei hábitos simples.", name: "Fernanda", service: "Orientação de calçados" },
    { text: "Ambiente lindo, pontual e muito profissional.", name: "Camila", service: "Calos e calosidades" }
  ],

  /* ======================= CONTATO ======================= */
  contact: {
    intro: "Prefere conversar antes? Fale pelo WhatsApp. Para marcar direto, use o agendamento on-line.",
    whatsappDisplay: "(11) 90000-0000",
    phoneDisplay: "(11) 3000-0000",
    email: "contato@beatriznascimento.exemplo",
    emailLink: false,
    addressLines: ["Rua Exemplo, 000 — sala 00", "Bairro, Cidade – UF"],
    addressNote: "Endereço fictício de demonstração",
    mapUrl: "",
    hours: [
      { days: "Segunda a sexta", time: "9h às 18h" },
      { days: "Sábado", time: "9h às 13h" },
      { days: "Domingos e feriados", time: "Fechado" }
    ],
    hoursNote: "Horários de exemplo. No modo real, a agenda on-line usa os horários cadastrados no painel.",
    isDemo: true
  },

  faq: [
    { q: "Como funciona o primeiro atendimento?", a: "Começamos com uma conversa sobre sua rotina e o que tem incomodado. Depois faço a avaliação e explico o que observei. Os cuidados do dia dependem do que a avaliação indicar." },
    { q: "Posso agendar pelo site?", a: "Sim. Escolha o serviço, o dia e um horário livre. Dependendo da regra da clínica, a confirmação é imediata ou após aprovação." },
    { q: "Como cancelo ou remarco?", a: "Pela Área do cliente, respeitando o prazo mínimo definido pela clínica. Fora do prazo, fale pelo WhatsApp." },
    { q: "Como me preparar?", a: "Venha com os pés limpos, sem esmalte se possível, e traga o calçado que mais usa. Se faz algum tratamento médico, traga as informações que tiver." },
    { q: "O atendimento substitui a consulta médica?", a: "Não. A podologia cuida da saúde dos pés e trabalha em conjunto com outros profissionais de saúde." }
  ],

  social: [{ label: "Instagram", handle: "@beatriznascimento.exemplo", url: "" }],

  /* ======================= PRIVACIDADE =======================
     MODELO de política. Precisa ser revisado por profissional jurídico antes
     de publicar. */
  privacy: {
    updated: "Modelo — revisar antes de publicar",
    controller: "Beatriz Nascimento | Podologia (dados fictícios de demonstração)",
    contactEmail: "privacidade@beatriznascimento.exemplo"
  }
};
