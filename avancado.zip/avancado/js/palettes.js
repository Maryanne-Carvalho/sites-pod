/* ==========================================================================
   PALETAS — Beatriz Nascimento | Podologia (Modelo Avançado)
   Arquivo próprio deste modelo; não é compartilhado com o Básico nem com o
   Elegance.

   Cada paleta define as 5 CORES EDITÁVEIS:
     primary    → cor principal (botões, links, marca)
     deep       → tom profundo (seções escuras, rodapé)
     accent     → destaque (detalhes, filetes, ícones)
     background → fundo das páginas
     text       → texto
   As demais (superfície, tons suaves, texto secundário e as cores de texto
   sobre botões e seções escuras) são CALCULADAS pelo motor de temas
   (js/theme-engine.js), sempre buscando contraste AA ou melhor.

   Para criar uma paleta: copie um bloco, troque id (minúsculas e hífens),
   nome e as 5 cores.
   ========================================================================== */
window.PS = window.PS || {};

window.PS.palettes = [
  { id: "ameixa-champagne", name: "Ameixa & Champagne", mood: "Assinatura da marca", radius: 6,
    colors: { primary: "#59364F", deep: "#382331", accent: "#C8AA78", background: "#F7F3EC", text: "#29262A" } },
  { id: "preto-dourado", name: "Preto & Dourado", mood: "Noturno e sofisticado", radius: 4,
    colors: { primary: "#2A2420", deep: "#14110F", accent: "#C9A24A", background: "#F8F5EE", text: "#1C1916" } },
  { id: "verde-esmeralda", name: "Verde-Esmeralda", mood: "Profundo e sereno", radius: 8,
    colors: { primary: "#1F5E4B", deep: "#12392E", accent: "#C9B27C", background: "#F4F6F1", text: "#1E2A25" } },
  { id: "azul-noite", name: "Azul-Noite", mood: "Técnico e confiável", radius: 6,
    colors: { primary: "#24375E", deep: "#141F38", accent: "#C2A36B", background: "#F4F5F8", text: "#1C2233" } },
  { id: "bordo-rose", name: "Bordô & Rosé", mood: "Elegante e acolhedor", radius: 10,
    colors: { primary: "#7A2E3D", deep: "#4A1A25", accent: "#E3B5AE", background: "#FBF4F2", text: "#2E1F22" } },
  { id: "chocolate-nude", name: "Chocolate & Nude", mood: "Quente e humano", radius: 12,
    colors: { primary: "#6B4636", deep: "#3E281F", accent: "#D9B79C", background: "#F8F2EC", text: "#2C221D" } },
  { id: "azul-petroleo", name: "Azul-Petróleo", mood: "Clínico e calmo", radius: 6,
    colors: { primary: "#1F5260", deep: "#12323B", accent: "#C9A86A", background: "#F2F6F6", text: "#1C2A2E" } },
  { id: "cinza-prata", name: "Cinza & Prata", mood: "Neutro e contemporâneo", radius: 4,
    colors: { primary: "#4A4E57", deep: "#2A2D33", accent: "#B8BCC4", background: "#F5F5F4", text: "#222428" } },
  { id: "terracota-premium", name: "Terracota Premium", mood: "Terroso e marcante", radius: 8,
    colors: { primary: "#9A4A2A", deep: "#5A2A18", accent: "#D9A66B", background: "#FAF4EE", text: "#2F221C" } }
];
