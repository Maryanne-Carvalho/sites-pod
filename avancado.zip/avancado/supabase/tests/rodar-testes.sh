#!/bin/bash
# =============================================================================
# RODA TODOS OS TESTES DO BANCO num PostgreSQL LOCAL (nunca no Supabase de produção!)
# Cria um banco descartável, aplica a imitação do Supabase + as migrações e
# executa: permissões/agenda (SQL), reservas simultâneas e comparação com o navegador.
#
# Requisitos: PostgreSQL 15+ com a extensão btree_gist, e o comando psql.
# Uso (Linux, como um usuário que pode criar bancos):
#   DB=welumen_test ./supabase/tests/rodar-testes.sh
# =============================================================================
set -e
cd "$(dirname "$0")/.."
DB=${DB:-welumen_test}
dropdb --if-exists "$DB" >/dev/null 2>&1 || true
createdb "$DB"
for f in tests/00_imitacao_supabase.sql migrations/001_tabelas.sql migrations/002_seguranca_rls.sql migrations/003_funcoes.sql migrations/004_correcoes_e_recursos.sql; do
  psql -q -v ON_ERROR_STOP=1 -d "$DB" -f "$f" >/dev/null
done
echo "== Migrações aplicadas em $DB"
echo "== Permissões, RLS e agenda"
psql -q -v ON_ERROR_STOP=1 -d "$DB" -f tests/10_testes_permissoes_e_agenda.sql
echo "== Migração 004 (horários atômicos, acessos, avisos, LGPD, cores, privilégios)"
psql -q -v ON_ERROR_STOP=1 -d "$DB" -f tests/11_testes_migracao_004.sql
echo "== Reservas simultâneas"
DB="$DB" bash tests/20_reserva_simultanea.sh
echo "== Motor do navegador x motor do banco"
DB="$DB" PSQL_DIRETO=1 node ../tests/30_comparar_navegador_e_banco.js
