// =============================================================================
// TESTE DE INTEGRAÇÃO COM UM SUPABASE REAL — PREPARADO, AINDA NÃO EXECUTADO
// -----------------------------------------------------------------------------
// Diferente dos testes em supabase/tests/10–20 (PostgreSQL LOCAL imitando o
// Supabase), este script fala com um PROJETO SUPABASE DE VERDADE pela internet,
// usando apenas a chave PÚBLICA (anon/publishable) — exatamente como o site.
//
// ⚠ USE SOMENTE UM PROJETO DE TESTE, NUNCA O DE PRODUÇÃO. O script cria
//   pacientes e agendamentos fictícios e altera horários da clínica de teste.
// ⚠ NÃO use a chave service_role nem sb_secret: o script se recusa a rodar.
//
// Preparação (uma vez, no projeto de TESTE):
//   1. Aplique 001 → 002 → 003 → 004 e o setup-clinica-e-admin.sql.
//   2. Em Authentication › Providers › Email, desative "Confirm email" (só no
//      projeto de teste) ou crie e confirme as contas abaixo manualmente.
//   3. Crie as contas: ADMIN (vinculada como owner no setup), CLIENTE_A e CLIENTE_B.
//   4. npm i @supabase/supabase-js@2.45.4
//
// Execução:
//   SUPABASE_URL=https://xxxx.supabase.co SUPABASE_ANON_KEY=eyJ... CLINIC_ID=uuid \
//   ADMIN_EMAIL=... ADMIN_SENHA=... CLIENTE_A_EMAIL=... CLIENTE_A_SENHA=... \
//   CLIENTE_B_EMAIL=... CLIENTE_B_SENHA=... CONFIRMO_PROJETO_DE_TESTE=sim \
//   node supabase/tests/90_integracao_supabase_real.mjs
//
// Cada linha diz PASSOU ou FALHOU. Ao final, o script cancela o que criou e
// restaura os horários originais da clínica de teste.
// =============================================================================
import { createClient } from "@supabase/supabase-js";

const E = process.env;
const req = ["SUPABASE_URL", "SUPABASE_ANON_KEY", "CLINIC_ID", "ADMIN_EMAIL", "ADMIN_SENHA", "CLIENTE_A_EMAIL", "CLIENTE_A_SENHA", "CLIENTE_B_EMAIL", "CLIENTE_B_SENHA"];
const faltando = req.filter(k => !E[k]);
if (faltando.length) { console.error("Faltam variáveis:", faltando.join(", ")); process.exit(2); }
if (E.CONFIRMO_PROJETO_DE_TESTE !== "sim") { console.error("Defina CONFIRMO_PROJETO_DE_TESTE=sim para confirmar que NÃO é produção."); process.exit(2); }
const papel = (() => { try { return JSON.parse(Buffer.from(E.SUPABASE_ANON_KEY.split(".")[1], "base64url").toString()).role; } catch { return null; } })();
if (/service_role|^sb_secret_/i.test(E.SUPABASE_ANON_KEY) || papel === "service_role") { console.error("Recusado: isto parece a chave secreta. Use a chave pública (anon)."); process.exit(2); }

const C = E.CLINIC_ID;
let falhas = 0, total = 0;
const ok = (c, n, x) => { total++; if (!c) falhas++; console.log((c ? "PASSOU" : "FALHOU") + " · " + n + (x ? "  (" + x + ")" : "")); };
const novo = () => createClient(E.SUPABASE_URL, E.SUPABASE_ANON_KEY, { auth: { persistSession: false, autoRefreshToken: false } });
const entrar = async (email, senha) => { const c = novo(); const r = await c.auth.signInWithPassword({ email, password: senha }); if (r.error) throw new Error("Login falhou para " + email + ": " + r.error.message); return c; };
const codigo = r => r.error ? (r.error.message || r.error.code) : null;
const criados = [];

try {
  /* ---------- 1. Visitante (anon) ---------- */
  const anon = novo();
  let r = await anon.from("services").select("id, name, duration_minutes").eq("clinic_id", C).eq("is_active", true);
  ok(!r.error && r.data.length > 0, "Visitante lê os serviços ativos", r.error && r.error.message);
  const svc = r.data[0];
  r = await anon.from("patients").select("id").limit(1);
  ok(!r.error && r.data.length === 0, "Visitante NÃO lê pacientes (RLS)");
  r = await anon.from("appointments").select("id").limit(1);
  ok(!r.error && r.data.length === 0, "Visitante NÃO lê agendamentos (RLS)");
  r = await anon.rpc("admin_set_status", { p_appointment: "00000000-0000-0000-0000-000000000000", p_status: "cancelled", p_reason: null });
  ok(!!r.error, "Visitante NÃO executa função administrativa", codigo(r));
  r = await anon.from("clinic_private_settings").select("*");
  ok(!!r.error || r.data.length === 0, "Visitante NÃO lê configurações internas");
  r = await anon.from("notification_outbox").select("*");
  ok(!!r.error || r.data.length === 0, "Visitante NÃO lê a fila de avisos");

  /* ---------- 2. Horários livres vindos do banco ---------- */
  const hoje = new Date(), ymd = d => d.toISOString().slice(0, 10);
  const de = ymd(new Date(hoje.getTime() + 3 * 86400000)), ate = ymd(new Date(hoje.getTime() + 30 * 86400000));
  r = await anon.rpc("get_available_slots", { p_clinic: C, p_service: svc.id, p_from: de, p_to: ate, p_ignore_appointment: null });
  ok(!r.error && r.data.length >= 3, "get_available_slots devolve horários livres", r.error ? r.error.message : r.data.length + " horários");
  const livres = r.data || [];

  /* ---------- 3. Clientes isolados ---------- */
  const A = await entrar(E.CLIENTE_A_EMAIL, E.CLIENTE_A_SENHA);
  const B = await entrar(E.CLIENTE_B_EMAIL, E.CLIENTE_B_SENHA);
  for (const [cli, nome] of [[A, "Cliente A (teste)"], [B, "Cliente B (teste)"]]) {
    const acc = await cli.rpc("my_access", { p_clinic: C });
    if (acc.data && acc.data.role === "none") await cli.rpc("register_my_patient", { p_clinic: C, p_full_name: nome, p_phone: "11999990000", p_accept_privacy: true });
  }
  ok((await A.rpc("my_access", { p_clinic: C })).data.role === "client", "Cliente A tem perfil de cliente (nunca admin)");
  r = await A.rpc("book_appointment", { p_clinic: C, p_service: svc.id, p_starts_at: livres[0].starts_at, p_patient: null });
  ok(!r.error, "Cliente A agenda um horário livre", codigo(r));
  if (r.data) criados.push(["A", r.data.id]);
  const idA = r.data && r.data.id;
  r = await B.from("appointments").select("id").eq("id", idA);
  ok(!r.error && r.data.length === 0, "Cliente B NÃO vê o agendamento de A");
  r = await B.rpc("cancel_my_appointment", { p_appointment: idA, p_reason: "invasão" });
  ok(!!r.error, "Cliente B NÃO cancela o agendamento de A", codigo(r));
  r = await A.from("patients").select("id");
  ok(!r.error && r.data.length === 1, "Cliente A vê apenas o próprio cadastro");
  r = await A.rpc("admin_save_schedule", { p_clinic: C, p_rules: [], p_breaks: [] });
  ok(!!r.error, "Cliente NÃO altera horários da clínica", codigo(r));
  r = await A.from("clinic_members").insert({ clinic_id: C, user_id: (await A.auth.getUser()).data.user.id, role: "owner" });
  ok(!!r.error, "Cliente NÃO se torna administradora inserindo na tabela", codigo(r));
  r = await A.rpc("export_my_data", { p_clinic: C });
  ok(!r.error && r.data && JSON.stringify(r.data).includes(idA), "Cliente exporta os próprios dados (LGPD)");

  /* ---------- 4. Reserva simultânea no mesmo horário ---------- */
  const alvo = livres[2].starts_at;
  const [ra, rb] = await Promise.all([
    A.rpc("book_appointment", { p_clinic: C, p_service: svc.id, p_starts_at: alvo, p_patient: null }),
    B.rpc("book_appointment", { p_clinic: C, p_service: svc.id, p_starts_at: alvo, p_patient: null })
  ]);
  for (const [q, x] of [["A", ra], ["B", rb]]) if (x.data) criados.push([q, x.data.id]);
  ok([ra, rb].filter(x => !x.error).length === 1 && [ra, rb].some(x => /SLOT_UNAVAILABLE/.test(codigo(x) || "")), "Duas reservas simultâneas: só uma entra", [codigo(ra), codigo(rb)].join(" / "));

  /* ---------- 5. Administradora ---------- */
  const ADM = await entrar(E.ADMIN_EMAIL, E.ADMIN_SENHA);
  ok(["owner", "admin"].includes((await ADM.rpc("my_access", { p_clinic: C })).data.role), "Administradora reconhecida pelo banco");
  r = await ADM.from("appointments").select("id").eq("id", idA);
  ok(!r.error && r.data.length === 1, "Administradora vê o agendamento do cliente");
  const antes = await ADM.from("availability_rules").select("weekday, start_time, end_time").eq("clinic_id", C);
  const antesP = await ADM.from("availability_breaks").select("weekday, start_time, end_time, label").eq("clinic_id", C);
  const hm = t => String(t).slice(0, 5);
  r = await ADM.rpc("admin_save_schedule", { p_clinic: C, p_rules: [{ weekday: 1, start: "08:00", end: "12:00" }, { weekday: 1, start: "11:00", end: "13:00" }], p_breaks: [] });
  ok(/SHIFT_OVERLAP/.test(codigo(r) || ""), "Banco recusa turnos sobrepostos", codigo(r));
  r = await ADM.rpc("admin_save_schedule", {
    p_clinic: C,
    p_rules: antes.data.map(x => ({ weekday: x.weekday, start: hm(x.start_time), end: hm(x.end_time) })),
    p_breaks: antesP.data.map(x => ({ weekday: x.weekday, start: hm(x.start_time), end: hm(x.end_time), label: x.label }))
  });
  ok(!r.error, "Gravação atômica de horários funciona (regravando os originais)", codigo(r));
  r = await ADM.rpc("list_admin_access", { p_clinic: C });
  ok(!r.error && r.data.members.length >= 1, "Lista de acessos administrativos", codigo(r));
  r = await ADM.from("clinic_settings").update({ branding: { paletteId: "ameixa-champagne", overrides: { primary: "red;}" } } }).eq("clinic_id", C);
  ok(!!r.error, "Banco recusa cor inválida na identidade visual", codigo(r));
} catch (e) {
  ok(false, "Execução interrompida", e.message);
} finally {
  /* ---------- Limpeza ---------- */
  try {
    const ADM = await entrar(E.ADMIN_EMAIL, E.ADMIN_SENHA);
    for (const [, id] of criados) await ADM.rpc("admin_set_status", { p_appointment: id, p_status: "cancelled", p_reason: "Teste de integração" });
    console.log("Limpeza: " + criados.length + " agendamento(s) de teste cancelado(s).");
  } catch (e) { console.log("Limpeza não concluída:", e.message); }
  console.log("\n" + (total - falhas) + " de " + total + " verificações passaram (Supabase REAL, projeto de teste).");
  process.exit(falhas ? 1 : 0);
}
