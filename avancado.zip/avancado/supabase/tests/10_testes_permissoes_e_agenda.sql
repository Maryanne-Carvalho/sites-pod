-- =============================================================================
-- TESTES AUTOMÁTICOS — permissões (RLS), isolamento entre clínicas e regras
-- de agenda. Rodam num PostgreSQL local que imita o Supabase (00_imitacao_supabase.sql).
-- Cada linha de resultado diz PASSOU ou FALHOU.
-- =============================================================================
set client_min_messages = warning;

-- ---------- Ferramentas de teste ----------
create schema if not exists t;
create table if not exists t.results (n serial primary key, ok boolean, name text, detail text);
create table if not exists t.vars (k text primary key, v text);
grant usage on schema t to anon, authenticated;
grant all on t.results, t.vars to anon, authenticated;
grant usage on sequence t.results_n_seq to anon, authenticated;

create or replace function t.ok(p_cond boolean, p_name text, p_detail text default null) returns void
language sql as $$ insert into t.results (ok, name, detail) values (coalesce(p_cond, false), p_name, p_detail) $$;

-- Executa um comando e espera que ele FALHE com a mensagem indicada
create or replace function t.throws(p_sql text, p_expect text, p_name text) returns void
language plpgsql as $$
begin
  execute p_sql;
  insert into t.results (ok, name, detail) values (false, p_name, 'não falhou');
exception when others then
  insert into t.results (ok, name, detail) values (sqlerrm ilike '%' || p_expect || '%', p_name, sqlerrm);
end $$;

-- Horário local da clínica daqui a N dias, na hora indicada
create or replace function t.slot(p_days int, p_hhmm text) returns timestamptz
language sql stable as $$
  select (((now() at time zone 'America/Sao_Paulo')::date + p_days) + p_hhmm::time) at time zone 'America/Sao_Paulo'
$$;
create or replace function t.day(p_days int) returns date
language sql stable as $$ select (now() at time zone 'America/Sao_Paulo')::date + p_days $$;
create or replace function t.set(p_k text, p_v text) returns void language sql as $$
  insert into t.vars values (p_k, p_v) on conflict (k) do update set v = excluded.v $$;
create or replace function t.get(p_k text) returns text language sql stable as $$ select v from t.vars where k = p_k $$;
grant execute on all functions in schema t to anon, authenticated;

-- ---------- Dados fictícios de teste (criados como dono do banco) ----------
insert into auth.users (id, email) values
  ('aaaaaaaa-0000-0000-0000-000000000001', 'admin.a@teste.local'),
  ('bbbbbbbb-0000-0000-0000-000000000001', 'admin.b@teste.local'),
  ('c1000000-0000-0000-0000-000000000001', 'cliente1@teste.local'),
  ('c2000000-0000-0000-0000-000000000002', 'cliente2@teste.local'),
  ('c3000000-0000-0000-0000-000000000003', 'cliente3@teste.local'),
  ('dddddddd-0000-0000-0000-000000000001', 'convidada@teste.local');

insert into public.clinics (id, slug, name, timezone) values
  ('11111111-1111-1111-1111-111111111111', 'clinica-a', 'Clínica A (teste)', 'America/Sao_Paulo'),
  ('22222222-2222-2222-2222-222222222222', 'clinica-b', 'Clínica B (teste)', 'America/Sao_Paulo');
insert into public.clinic_settings (clinic_id, slot_step_minutes, buffer_minutes, booking_min_notice_hours,
  booking_horizon_days, cancel_min_hours, reschedule_min_hours, client_cancel_mode, client_reschedule_mode)
values ('11111111-1111-1111-1111-111111111111', 30, 10, 2, 60, 24, 24, 'direct', 'approval'),
       ('22222222-2222-2222-2222-222222222222', 30, 0, 2, 60, 24, 24, 'direct', 'direct');
insert into public.clinic_private_settings (clinic_id) values
  ('11111111-1111-1111-1111-111111111111'), ('22222222-2222-2222-2222-222222222222');
insert into public.clinic_members (clinic_id, user_id, role) values
  ('11111111-1111-1111-1111-111111111111', 'aaaaaaaa-0000-0000-0000-000000000001', 'owner'),
  ('22222222-2222-2222-2222-222222222222', 'bbbbbbbb-0000-0000-0000-000000000001', 'owner');
insert into public.services (id, clinic_id, name, duration_minutes, price_cents) values
  ('5a000000-0000-0000-0000-000000000001', '11111111-1111-1111-1111-111111111111', 'Avaliação podológica', 50, 15000),
  ('5b000000-0000-0000-0000-000000000001', '22222222-2222-2222-2222-222222222222', 'Atendimento B', 30, null);
-- Clínica A atende todos os dias das 9h às 18h, com almoço das 12h às 13h
insert into public.availability_rules (clinic_id, weekday, start_time, end_time)
  select '11111111-1111-1111-1111-111111111111', d, '09:00', '18:00' from generate_series(0, 6) d;
insert into public.availability_breaks (clinic_id, weekday, start_time, end_time, label)
  select '11111111-1111-1111-1111-111111111111', d, '12:00', '13:00', 'Almoço' from generate_series(0, 6) d;
insert into public.availability_rules (clinic_id, weekday, start_time, end_time)
  select '22222222-2222-2222-2222-222222222222', d, '08:00', '12:00' from generate_series(0, 6) d;

-- =============================================================================
-- 1. VISITANTE SEM LOGIN (anon)
-- =============================================================================
set role anon;
select set_config('request.jwt.claims', '', false);

select t.ok((select count(*) from public.clinics) = 2, 'Visitante vê os dados públicos das clínicas');
select t.ok((select count(*) from public.services) = 2, 'Visitante vê os serviços ativos');
select t.throws('select * from public.patients', 'permission denied', 'Visitante NÃO consegue ler pacientes');
select t.throws('select * from public.appointments', 'permission denied', 'Visitante NÃO consegue ler agendamentos');
select t.throws('select * from public.schedule_exceptions', 'permission denied', 'Visitante NÃO vê motivos de bloqueio');
select t.ok(exists (select 1 from public.get_available_slots('11111111-1111-1111-1111-111111111111', '5a000000-0000-0000-0000-000000000001', t.day(7), t.day(7)) s where s.starts_at = t.slot(7, '10:00')),
  'Visitante consulta horários livres (10h disponível)');
select t.ok(not exists (select 1 from public.get_available_slots('11111111-1111-1111-1111-111111111111', '5a000000-0000-0000-0000-000000000001', t.day(7), t.day(7)) s where s.starts_at = t.slot(7, '11:30')),
  'Horário que invade o almoço não aparece (11h30 + 50 min)');
select t.throws($$select public.book_appointment('11111111-1111-1111-1111-111111111111', '5a000000-0000-0000-0000-000000000001', t.slot(7, '10:00'))$$,
  'permission denied', 'Visitante NÃO consegue agendar sem login');

-- =============================================================================
-- 2. CLIENTE 1 — cadastro e primeiro agendamento
-- =============================================================================
reset role;
set role authenticated;
select set_config('request.jwt.claims', '{"sub":"c1000000-0000-0000-0000-000000000001","role":"authenticated"}', false);

select t.throws($$select public.book_appointment('11111111-1111-1111-1111-111111111111', '5a000000-0000-0000-0000-000000000001', t.slot(7, '10:00'))$$,
  'PATIENT_PROFILE_REQUIRED', 'Cliente sem cadastro não agenda');
select t.throws($$select public.register_my_patient('11111111-1111-1111-1111-111111111111', 'Cliente Um', '11988887777', false)$$,
  'CONSENT_REQUIRED', 'Cadastro exige aceite da política de privacidade');
select t.set('p1', public.register_my_patient('11111111-1111-1111-1111-111111111111', '  Cliente   Um  ', '(11) 98888-7777', true)::text);
select t.ok((select full_name = 'Cliente Um' and phone = '11988887777' from public.patients where id = t.get('p1')::uuid),
  'Dados normalizados (espaços e telefone só com dígitos)');
select t.ok((public.my_access('11111111-1111-1111-1111-111111111111') ->> 'role') = 'client', 'Função identificada pelo banco: cliente');
select t.throws($$insert into public.clinic_members (clinic_id, user_id) values ('11111111-1111-1111-1111-111111111111', 'c1000000-0000-0000-0000-000000000001')$$,
  'permission denied', 'Cliente NÃO consegue se tornar administradora');
select t.throws($$update public.patients set user_id = null where id = t.get('p1')::uuid$$,
  'permission denied', 'Cliente NÃO altera campos protegidos do próprio cadastro');
update public.patients set full_name = 'Nome Trocado' where id = t.get('p1')::uuid;
select t.ok((select full_name from public.patients where id = t.get('p1')::uuid) = 'Cliente Um', 'Cliente não edita o cadastro direto na tabela (só pela função)');

select t.set('a1', (public.book_appointment('11111111-1111-1111-1111-111111111111', '5a000000-0000-0000-0000-000000000001', t.slot(7, '10:00')) ->> 'id'));
select t.ok((select status = 'confirmed' and source = 'online' from public.appointments where id = t.get('a1')::uuid),
  'Cliente agenda um horário livre (confirmado automaticamente)');
select t.throws($$insert into public.appointments (clinic_id, patient_id, service_id, starts_at, ends_at, occupied_until, source, service_name, duration_minutes)
  values ('11111111-1111-1111-1111-111111111111', t.get('p1')::uuid, '5a000000-0000-0000-0000-000000000001', t.slot(9, '10:00'), t.slot(9, '10:50'), t.slot(9, '11:00'), 'online', 'x', 50)$$,
  'permission denied', 'Cliente NÃO grava agendamento direto na tabela (pula validação)');

-- =============================================================================
-- 3. CLIENTE 2 — conflitos e privacidade
-- =============================================================================
select set_config('request.jwt.claims', '{"sub":"c2000000-0000-0000-0000-000000000002","role":"authenticated"}', false);
select t.set('p2', public.register_my_patient('11111111-1111-1111-1111-111111111111', 'Cliente Dois', '11977776666', true)::text);

select t.throws($$select public.book_appointment('11111111-1111-1111-1111-111111111111', '5a000000-0000-0000-0000-000000000001', t.slot(7, '10:00'))$$,
  'SLOT_UNAVAILABLE', 'Horário já reservado NÃO pode ser reservado de novo');
select t.throws($$select public.book_appointment('11111111-1111-1111-1111-111111111111', '5a000000-0000-0000-0000-000000000001', t.slot(7, '10:30'))$$,
  'SLOT_UNAVAILABLE', 'Horário que se sobrepõe (10h30, consulta anterior + intervalo) é recusado');
select t.throws($$select public.book_appointment('11111111-1111-1111-1111-111111111111', '5a000000-0000-0000-0000-000000000001', t.slot(7, '12:00'))$$,
  'SLOT_UNAVAILABLE', 'Horário de almoço é recusado');
select t.throws($$select public.book_appointment('11111111-1111-1111-1111-111111111111', '5a000000-0000-0000-0000-000000000001', t.slot(7, '11:10'))$$,
  'SLOT_UNAVAILABLE', 'Horário fora da grade (11h10) é recusado');
select t.throws($$select public.book_appointment('11111111-1111-1111-1111-111111111111', '5a000000-0000-0000-0000-000000000001', t.slot(7, '20:00'))$$,
  'SLOT_UNAVAILABLE', 'Horário fora do expediente é recusado');
select t.throws($$select public.book_appointment('11111111-1111-1111-1111-111111111111', '5a000000-0000-0000-0000-000000000001', t.slot(90, '10:00'))$$,
  'SLOT_UNAVAILABLE', 'Horário além do limite de dias à frente é recusado');
select t.set('a2', (public.book_appointment('11111111-1111-1111-1111-111111111111', '5a000000-0000-0000-0000-000000000001', t.slot(7, '11:00')) ->> 'id'));
select t.ok(t.get('a2') is not null, 'Cliente 2 agenda o próximo horário livre (11h)');
select t.ok(not exists (select 1 from public.get_available_slots('11111111-1111-1111-1111-111111111111', '5a000000-0000-0000-0000-000000000001', t.day(7), t.day(7)) s
                        where s.starts_at in (t.slot(7, '10:00'), t.slot(7, '10:30'), t.slot(7, '11:00'))),
  'Horários ocupados somem da consulta de disponibilidade');
select t.ok((select count(*) from public.appointments) = 1, 'Cliente 2 vê SOMENTE o próprio agendamento');
select t.ok((select count(*) from public.patients) = 1, 'Cliente 2 vê SOMENTE o próprio cadastro');
select t.throws($$select public.cancel_my_appointment(t.get('a1')::uuid)$$, 'NOT_FOUND', 'Cliente 2 NÃO cancela agendamento de outra pessoa');
select t.throws($$select public.reschedule_my_appointment(t.get('a1')::uuid, t.slot(7, '15:00'))$$, 'NOT_FOUND', 'Cliente 2 NÃO reagenda agendamento de outra pessoa');
select t.throws($$select public.admin_set_status(t.get('a2')::uuid, 'cancelled')$$, 'NOT_FOUND', 'Cliente NÃO usa funções administrativas');
select t.throws($$select public.anonymize_patient(t.get('p1')::uuid)$$, 'NOT_FOUND', 'Cliente NÃO apaga dados de outra pessoa');
select t.throws($$select public.create_admin_invite('11111111-1111-1111-1111-111111111111', 'x@y.com')$$, 'FORBIDDEN', 'Cliente NÃO cria convites de administradora');
select t.ok((public.export_my_data('11111111-1111-1111-1111-111111111111') -> 'cadastro' ->> 'full_name') = 'Cliente Dois',
  'Cliente baixa os próprios dados (direito de acesso)');

-- =============================================================================
-- 4. ADMINISTRADORA DA CLÍNICA A
-- =============================================================================
select set_config('request.jwt.claims', '{"sub":"aaaaaaaa-0000-0000-0000-000000000001","role":"authenticated"}', false);
select t.ok((public.my_access('11111111-1111-1111-1111-111111111111') ->> 'role') = 'admin', 'Função identificada pelo banco: administradora');
select t.ok((select count(*) from public.patients) = 2 and (select count(*) from public.appointments) = 2,
  'Administradora vê pacientes e agendamentos da própria clínica');

insert into public.patients (clinic_id, full_name, phone, created_via)
values ('11111111-1111-1111-1111-111111111111', 'Paciente Telefone', '1133334444', 'admin');
select t.set('p3', (select id::text from public.patients where full_name = 'Paciente Telefone'));
select t.ok(t.get('p3') is not null, 'Administradora cadastra paciente (agendamento por telefone)');

select t.throws($$select public.book_appointment('11111111-1111-1111-1111-111111111111', '5a000000-0000-0000-0000-000000000001', t.slot(7, '10:00'), t.get('p3')::uuid)$$,
  'SLOT_UNAVAILABLE', 'Agendamento MANUAL usa a mesma regra: horário ocupado é recusado');
select t.set('a3', (public.book_appointment('11111111-1111-1111-1111-111111111111', '5a000000-0000-0000-0000-000000000001', t.slot(7, '14:00'), t.get('p3')::uuid) ->> 'id'));
select t.ok((select source = 'manual' and status = 'confirmed' from public.appointments where id = t.get('a3')::uuid), 'Agendamento manual gravado');

insert into public.schedule_exceptions (clinic_id, starts_at, ends_at, kind, all_day, reason)
values ('11111111-1111-1111-1111-111111111111', t.slot(8, '00:00'), t.slot(9, '00:00'), 'holiday', true, 'Feriado de teste');
select t.ok(not exists (select 1 from public.get_available_slots('11111111-1111-1111-1111-111111111111', '5a000000-0000-0000-0000-000000000001', t.day(8), t.day(8))),
  'Dia inteiro bloqueado não tem horários livres');
select t.throws($$select public.book_appointment('11111111-1111-1111-1111-111111111111', '5a000000-0000-0000-0000-000000000001', t.slot(8, '10:00'), t.get('p3')::uuid)$$,
  'SLOT_UNAVAILABLE', 'Não é possível agendar em dia bloqueado');
insert into public.schedule_exceptions (clinic_id, starts_at, ends_at, kind, reason)
values ('11111111-1111-1111-1111-111111111111', t.slot(10, '15:00'), t.slot(10, '16:00'), 'block', 'Compromisso');
select t.ok(not exists (select 1 from public.get_available_slots('11111111-1111-1111-1111-111111111111', '5a000000-0000-0000-0000-000000000001', t.day(10), t.day(10)) s
                        where s.starts_at in (t.slot(10, '14:30'), t.slot(10, '15:00'), t.slot(10, '15:30')))
            and exists (select 1 from public.get_available_slots('11111111-1111-1111-1111-111111111111', '5a000000-0000-0000-0000-000000000001', t.day(10), t.day(10)) s
                        where s.starts_at = t.slot(10, '16:00')),
  'Bloqueio de um horário específico remove só os horários afetados');
select t.throws($$select public.admin_set_status(t.get('a3')::uuid, 'completed')$$, 'NOT_STARTED_YET', 'Não marca como concluído um atendimento futuro');

-- Isolamento: a clínica A não enxerga nem altera a clínica B
select t.ok((select count(*) from public.patients where clinic_id = '22222222-2222-2222-2222-222222222222') = 0, 'Administradora A não vê pacientes da clínica B');
update public.clinic_settings set buffer_minutes = 99 where clinic_id = '22222222-2222-2222-2222-222222222222';
reset role;
select t.ok((select buffer_minutes from public.clinic_settings where clinic_id = '22222222-2222-2222-2222-222222222222') = 0,
  'Administradora A NÃO altera configurações da clínica B');
set role authenticated;
select set_config('request.jwt.claims', '{"sub":"aaaaaaaa-0000-0000-0000-000000000001","role":"authenticated"}', false);
select t.throws($$insert into public.clinic_members (clinic_id, user_id) values ('22222222-2222-2222-2222-222222222222', 'aaaaaaaa-0000-0000-0000-000000000001')$$,
  'permission denied', 'Administradora A NÃO se adiciona à clínica B');
select t.throws($$insert into public.services (clinic_id, name, duration_minutes) values ('22222222-2222-2222-2222-222222222222', 'Invasor', 30)$$,
  'row-level security', 'Administradora A NÃO cria serviços na clínica B');

-- =============================================================================
-- 5. CANCELAMENTO E REAGENDAMENTO COM REGRAS
-- =============================================================================
select set_config('request.jwt.claims', '{"sub":"c1000000-0000-0000-0000-000000000001","role":"authenticated"}', false);
select t.ok(public.reschedule_my_appointment(t.get('a1')::uuid, t.slot(7, '15:00')) = 'requested',
  'Reagendamento com aprovação vira pedido "Aguardando confirmação"');
select t.ok((select starts_at = t.slot(7, '10:00') from public.appointments where id = t.get('a1')::uuid), 'Enquanto aguarda, o horário original continua');
select t.throws($$select public.reschedule_my_appointment(t.get('a1')::uuid, t.slot(7, '16:00'))$$, 'REQUEST_ALREADY_OPEN', 'Só um pedido aberto por agendamento');

select set_config('request.jwt.claims', '{"sub":"aaaaaaaa-0000-0000-0000-000000000001","role":"authenticated"}', false);
select public.admin_resolve_request((select id from public.appointment_requests where appointment_id = t.get('a1')::uuid and status = 'pending'), true, null);
select t.ok((select starts_at = t.slot(7, '15:00') from public.appointments where id = t.get('a1')::uuid), 'Administradora aprova e o horário muda');
select t.ok(exists (select 1 from public.get_available_slots('11111111-1111-1111-1111-111111111111', '5a000000-0000-0000-0000-000000000001', t.day(7), t.day(7)) s where s.starts_at = t.slot(7, '10:00')),
  'Horário antigo volta a ficar livre');

select set_config('request.jwt.claims', '{"sub":"c1000000-0000-0000-0000-000000000001","role":"authenticated"}', false);
select t.ok(public.cancel_my_appointment(t.get('a1')::uuid, 'Imprevisto') = 'cancelled', 'Cliente cancela dentro do prazo (cancelamento direto)');
select t.ok(exists (select 1 from public.get_available_slots('11111111-1111-1111-1111-111111111111', '5a000000-0000-0000-0000-000000000001', t.day(7), t.day(7)) s where s.starts_at = t.slot(7, '15:00')),
  'Horário cancelado fica livre novamente');

reset role;
update public.clinic_settings set cancel_min_hours = 720 where clinic_id = '11111111-1111-1111-1111-111111111111';
set role authenticated;
select set_config('request.jwt.claims', '{"sub":"c2000000-0000-0000-0000-000000000002","role":"authenticated"}', false);
select t.throws($$select public.cancel_my_appointment(t.get('a2')::uuid)$$, 'CANCEL_DEADLINE_PASSED', 'Fora do prazo mínimo, o cliente não cancela sozinho');
reset role;
update public.clinic_settings set cancel_min_hours = 24, client_cancel_mode = 'approval' where clinic_id = '11111111-1111-1111-1111-111111111111';
set role authenticated;
select set_config('request.jwt.claims', '{"sub":"c2000000-0000-0000-0000-000000000002","role":"authenticated"}', false);
select t.ok(public.cancel_my_appointment(t.get('a2')::uuid) = 'requested', 'Com regra de aprovação, o cancelamento vira pedido');
select t.ok((select count(*) from public.appointment_requests where status = 'pending') = 1, 'Cliente vê o próprio pedido pendente');

-- Limite de agendamentos ativos por cliente (evita reservas abusivas)
reset role;
update public.clinic_settings set max_active_bookings_per_client = 1 where clinic_id = '11111111-1111-1111-1111-111111111111';
set role authenticated;
select set_config('request.jwt.claims', '{"sub":"c2000000-0000-0000-0000-000000000002","role":"authenticated"}', false);
select t.throws($$select public.book_appointment('11111111-1111-1111-1111-111111111111', '5a000000-0000-0000-0000-000000000001', t.slot(11, '09:00'))$$,
  'TOO_MANY_ACTIVE_BOOKINGS', 'Respeita o limite de agendamentos ativos por cliente');

-- Modo "aguardando confirmação" para agendamentos on-line
reset role;
update public.clinic_settings set max_active_bookings_per_client = 3, online_booking_mode = 'approval' where clinic_id = '11111111-1111-1111-1111-111111111111';
set role authenticated;
select set_config('request.jwt.claims', '{"sub":"c1000000-0000-0000-0000-000000000001","role":"authenticated"}', false);
select t.ok((public.book_appointment('11111111-1111-1111-1111-111111111111', '5a000000-0000-0000-0000-000000000001', t.slot(11, '09:00')) ->> 'status') = 'pending',
  'Com aprovação ativada, o agendamento on-line fica "Aguardando confirmação"');
select t.throws($$select public.book_appointment('11111111-1111-1111-1111-111111111111', '5a000000-0000-0000-0000-000000000001', t.slot(11, '09:00'))$$,
  'SLOT_UNAVAILABLE', 'Horário aguardando confirmação também fica reservado');

-- =============================================================================
-- 6. CLÍNICA B (isolamento nos dois sentidos)
-- =============================================================================
select set_config('request.jwt.claims', '{"sub":"c3000000-0000-0000-0000-000000000003","role":"authenticated"}', false);
select public.register_my_patient('22222222-2222-2222-2222-222222222222', 'Cliente Três', '21999990000', true);
select t.set('a4', (public.book_appointment('22222222-2222-2222-2222-222222222222', '5b000000-0000-0000-0000-000000000001', t.slot(7, '10:00')) ->> 'id'));
select t.ok(t.get('a4') is not null, 'Clínicas diferentes podem ter agendamentos no mesmo horário');
select set_config('request.jwt.claims', '{"sub":"bbbbbbbb-0000-0000-0000-000000000001","role":"authenticated"}', false);
select t.ok((select count(*) from public.patients) = 1 and (select count(*) from public.appointments) = 1, 'Administradora B vê apenas a clínica B');
select t.throws($$select public.admin_set_status(t.get('a2')::uuid, 'cancelled')$$, 'NOT_FOUND', 'Administradora B NÃO altera agendamento da clínica A');

-- =============================================================================
-- 7. CONVITE PARA NOVA ADMINISTRADORA
-- =============================================================================
select set_config('request.jwt.claims', '{"sub":"dddddddd-0000-0000-0000-000000000001","role":"authenticated"}', false);
select t.ok((public.my_access('11111111-1111-1111-1111-111111111111') ->> 'role') = 'none', 'Conta sem vínculo não tem acesso administrativo');
select t.ok((select count(*) from public.patients) = 0 and (select count(*) from public.appointments) = 0, 'Conta sem vínculo não vê pacientes nem agendamentos');
select set_config('request.jwt.claims', '{"sub":"aaaaaaaa-0000-0000-0000-000000000001","role":"authenticated"}', false);
select t.set('invite', public.create_admin_invite('11111111-1111-1111-1111-111111111111', 'convidada@teste.local'));
select t.ok((select count(*) from public.clinic_invites where token_hash = t.get('invite')) = 0, 'O código do convite não fica salvo em texto puro');
select set_config('request.jwt.claims', '{"sub":"dddddddd-0000-0000-0000-000000000001","role":"authenticated"}', false);
select t.throws($$select public.accept_admin_invite('codigo-errado')$$, 'INVITE_INVALID', 'Convite com código errado é recusado');
select public.accept_admin_invite(t.get('invite'));
select t.ok((public.my_access('11111111-1111-1111-1111-111111111111') ->> 'role') = 'admin', 'Convite válido transforma a conta em administradora');
select t.throws($$select public.accept_admin_invite(t.get('invite'))$$, 'INVITE_INVALID', 'Convite só pode ser usado uma vez');

-- =============================================================================
-- 8. GARANTIA FINAL DO BANCO: sobreposição recusada mesmo sem passar pelas funções
-- =============================================================================
reset role;
select t.throws($$insert into public.appointments (clinic_id, patient_id, service_id, starts_at, ends_at, occupied_until, source, service_name, duration_minutes)
  values ('11111111-1111-1111-1111-111111111111', t.get('p3')::uuid, '5a000000-0000-0000-0000-000000000001', t.slot(7, '14:20'), t.slot(7, '15:10'), t.slot(7, '15:20'), 'manual', 'x', 50)$$,
  'sem_sobreposicao', 'A restrição do banco recusa sobreposição até para o dono do banco');

-- LGPD: anonimização
set role authenticated;
select set_config('request.jwt.claims', '{"sub":"aaaaaaaa-0000-0000-0000-000000000001","role":"authenticated"}', false);
select public.anonymize_patient(t.get('p3')::uuid);
select t.ok((select full_name = 'Paciente removido' and phone is null and archived_at is not null from public.patients where id = t.get('p3')::uuid),
  'Pedido de exclusão: paciente anonimizado, histórico preservado sem identificação');
select t.ok((select status = 'cancelled' from public.appointments where id = t.get('a3')::uuid), 'Horários futuros do paciente anonimizado são liberados');
select t.ok(not exists (select 1 from information_schema.columns where table_name = 'audit_log' and column_name in ('full_name', 'phone', 'email', 'details')),
  'Registro de ações não guarda nome, telefone ou e-mail');
reset role;

-- ---------- Resultado ----------
select case when ok then 'PASSOU' else 'FALHOU' end || ' · ' || name || coalesce('  [' || detail || ']', '') as resultado
from t.results order by n;
select count(*) filter (where ok) || ' de ' || count(*) || ' testes passaram' as resumo from t.results;
