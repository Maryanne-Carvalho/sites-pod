#!/bin/bash
# =============================================================================
# TESTE DE RESERVAS SIMULTÂNEAS (rodar depois de 10_testes_permissoes_e_agenda.sql)
# 8 clientes diferentes tentam reservar o MESMO horário ao mesmo tempo.
# Resultado esperado: exatamente 1 reserva aceita e 7 recusadas.
# Depois, o mesmo teste gravando direto na tabela (sem a função), para provar
# que a restrição do banco segura sozinha.
# Uso: DB=welumen_test ./20_reserva_simultanea.sh   (como usuário com acesso ao banco)
# =============================================================================
DB=${DB:-welumen_test}
PSQL="psql -q -t -A -d $DB"
CLINIC=11111111-1111-1111-1111-111111111111
SERVICE=5a000000-0000-0000-0000-000000000001
N=8

# Prepara 8 clientes fictícios na clínica A e libera o limite de reservas
$PSQL <<SQL
update public.clinic_settings set online_booking_mode = 'auto', max_active_bookings_per_client = 5 where clinic_id = '$CLINIC';
insert into auth.users (id, email)
  select ('e0000000-0000-0000-0000-00000000000' || i)::uuid, 'simultaneo' || i || '@teste.local' from generate_series(1, $N) i
  on conflict do nothing;
SQL
for i in $(seq 1 $N); do
  $PSQL >/dev/null <<SQL
set role authenticated;
select set_config('request.jwt.claims', '{"sub":"e0000000-0000-0000-0000-00000000000$i"}', false);
select public.register_my_patient('$CLINIC', 'Cliente Simultâneo $i', '1190000000$i', true);
SQL
done

SLOT=$($PSQL -c "select t.slot(12, '10:00')")
echo "Horário disputado: $SLOT"

# Dispara as 8 reservas ao mesmo tempo
TMP=$(mktemp -d)
for i in $(seq 1 $N); do
  (
    $PSQL 2>&1 <<SQL
set role authenticated;
select set_config('request.jwt.claims', '{"sub":"e0000000-0000-0000-0000-00000000000$i"}', false) \g /dev/null
select 'OK ' || (public.book_appointment('$CLINIC', '$SERVICE', '$SLOT'::timestamptz) ->> 'id');
SQL
  ) > "$TMP/r$i.txt" &
done
wait

OKS=$(grep -l "^OK " "$TMP"/r*.txt | wc -l)
FAILS=$(grep -l "SLOT_UNAVAILABLE" "$TMP"/r*.txt | wc -l)
echo "Reservas aceitas: $OKS · recusadas com SLOT_UNAVAILABLE: $FAILS"
if [ "$OKS" = "1" ] && [ "$FAILS" = "$((N-1))" ]; then
  echo "PASSOU · 8 reservas simultâneas para o mesmo horário → só 1 aceita"
else
  echo "FALHOU · reservas simultâneas"; cat "$TMP"/r*.txt
fi
COUNT=$($PSQL -c "select count(*) from public.appointments where clinic_id = '$CLINIC' and starts_at = '$SLOT'::timestamptz and status in ('pending','confirmed')")
[ "$COUNT" = "1" ] && echo "PASSOU · o banco tem exatamente 1 agendamento ativo nesse horário" || echo "FALHOU · existem $COUNT agendamentos ativos"

# Segunda prova: gravação direta concorrente (sem a função e sem a trava), só a restrição do banco
SLOT2=$($PSQL -c "select t.slot(13, '10:00')")
PAT=$($PSQL -c "select id from public.patients where full_name = 'Cliente Simultâneo 1'")
for i in 1 2; do
  (
    $PSQL -v ON_ERROR_STOP=1 2>&1 <<SQL
begin;
insert into public.appointments (clinic_id, patient_id, service_id, starts_at, ends_at, occupied_until, source, service_name, duration_minutes)
values ('$CLINIC', '$PAT', '$SERVICE', '$SLOT2'::timestamptz + interval '$((i*10)) minutes', '$SLOT2'::timestamptz + interval '60 minutes',
        '$SLOT2'::timestamptz + interval '70 minutes', 'manual', 'teste', 50);
select pg_sleep(1);
commit;
select 'OK';
SQL
  ) > "$TMP/d$i.txt" &
done
wait
DOKS=$(grep -l "^OK" "$TMP"/d*.txt | wc -l)
# O banco recusa de um destes dois jeitos (os dois são seguros):
#  • "sem_sobreposicao": a segunda gravação vê a primeira e é recusada;
#  • "deadlock detected": as duas chegam no mesmo instante, o banco percebe o choque
#    e cancela uma delas. (Pelas funções do sistema isso não acontece, porque elas
#    fazem fila antes de gravar e devolvem a mensagem amigável SLOT_UNAVAILABLE.)
DFAIL=$(grep -lE "sem_sobreposicao|deadlock detected" "$TMP"/d*.txt | wc -l)
if [ "$DOKS" = "1" ] && [ "$DFAIL" = "1" ]; then
  echo "PASSOU · 2 gravações diretas simultâneas e sobrepostas → a restrição do banco recusou 1"
else
  echo "FALHOU · gravação direta"; cat "$TMP"/d*.txt
fi
rm -rf "$TMP"
