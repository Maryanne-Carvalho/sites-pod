-- =============================================================================
-- TESTES DA MIGRAÇÃO 004 — rodam DEPOIS de 10_testes_permissoes_e_agenda.sql,
-- no mesmo banco local descartável (reaproveitam as clínicas e contas fictícias).
-- NUNCA rode em um banco de produção.
-- =============================================================================
set client_min_messages = warning;
reset role;
select t.set('inicio_004', (select coalesce(max(n), 0) from t.results)::text);

-- dados extras (como dono do banco)
insert into auth.users (id, email) values
  ('c4000000-0000-0000-0000-000000000004', 'cliente4@teste.local'),
  ('eeeeeeee-0000-0000-0000-000000000001', 'outra.admin@teste.local')
on conflict do nothing;

-- =============================================================================
-- A. Horários visíveis ao público só com clínica publicada
-- =============================================================================
update public.clinics set is_published = false where id = '22222222-2222-2222-2222-222222222222';
set role anon;
select set_config('request.jwt.claims', '', false);
select t.ok((select count(*) from public.availability_rules where clinic_id = '22222222-2222-2222-2222-222222222222') = 0,
  '004 · Visitante NÃO vê horários de clínica não publicada');
select t.ok((select count(*) from public.availability_rules where clinic_id = '11111111-1111-1111-1111-111111111111') > 0,
  '004 · Visitante continua vendo horários de clínica publicada');
set role authenticated;
select set_config('request.jwt.claims', '{"sub":"bbbbbbbb-0000-0000-0000-000000000001","role":"authenticated"}', false);
select t.ok((select count(*) from public.availability_rules where clinic_id = '22222222-2222-2222-2222-222222222222') > 0,
  '004 · Administradora vê os horários da própria clínica mesmo despublicada');
reset role;
update public.clinics set is_published = true where id = '22222222-2222-2222-2222-222222222222';

-- =============================================================================
-- B. Salvar horários de forma atômica, com vários turnos por dia
-- =============================================================================
set role authenticated;
select set_config('request.jwt.claims', '{"sub":"aaaaaaaa-0000-0000-0000-000000000001","role":"authenticated"}', false);
select t.set('dow13', extract(dow from t.day(13))::int::text);
select t.set('regras_antes', (select count(*) from public.availability_rules where clinic_id = '11111111-1111-1111-1111-111111111111')::text);

select t.throws(format($$select public.admin_save_schedule('11111111-1111-1111-1111-111111111111',
  '[{"weekday":%1$s,"start":"08:00","end":"12:00"},{"weekday":%1$s,"start":"11:00","end":"15:00"}]', '[]')$$, t.get('dow13')),
  'SHIFT_OVERLAP', '004 · Turnos sobrepostos no mesmo dia são recusados');
select t.throws(format($$select public.admin_save_schedule('11111111-1111-1111-1111-111111111111',
  '[{"weekday":%1$s,"start":"08:00","end":"12:00"}]', '[{"weekday":%1$s,"start":"12:30","end":"13:00"}]')$$, t.get('dow13')),
  'BREAK_OUTSIDE_SHIFT', '004 · Pausa fora de qualquer turno é recusada');
select t.throws(format($$select public.admin_save_schedule('11111111-1111-1111-1111-111111111111',
  '[{"weekday":%1$s,"start":"08:00","end":"12:00"}]', '[{"weekday":%1$s,"start":"09:00","end":"10:00"},{"weekday":%1$s,"start":"09:30","end":"10:30"}]')$$, t.get('dow13')),
  'BREAK_OVERLAP', '004 · Pausas sobrepostas são recusadas');
select t.throws($$select public.admin_save_schedule('11111111-1111-1111-1111-111111111111', '[{"weekday":9,"start":"08:00","end":"12:00"}]', '[]')$$,
  'INVALID_SCHEDULE', '004 · Dia da semana inválido é recusado');
select t.throws($$select public.admin_save_schedule('11111111-1111-1111-1111-111111111111', '[{"weekday":1,"start":"18:00","end":"08:00"}]', '[]')$$,
  'INVALID_SCHEDULE', '004 · Turno que termina antes de começar é recusado');
select t.throws($$select public.admin_save_schedule('11111111-1111-1111-1111-111111111111', '[{"weekday":1,"start":"xx","end":"08:00"}]', '[]')$$,
  'INVALID_SCHEDULE', '004 · Horário malformado é recusado');
select t.ok((select count(*) from public.availability_rules where clinic_id = '11111111-1111-1111-1111-111111111111')::text = t.get('regras_antes'),
  '004 · Tentativas recusadas não apagam os horários existentes (operação atômica)');

-- todos os dias: manhã 08–12 e tarde 14–19, com café 10:00–10:15 de manhã
select public.admin_save_schedule('11111111-1111-1111-1111-111111111111',
  (select jsonb_agg(x) from (
     select jsonb_build_object('weekday', d, 'start', '08:00', 'end', '12:00') x from generate_series(0, 6) d
     union all select jsonb_build_object('weekday', d, 'start', '14:00', 'end', '19:00') from generate_series(0, 6) d) q),
  (select jsonb_agg(jsonb_build_object('weekday', d, 'start', '10:00', 'end', '10:15', 'label', 'Café')) from generate_series(0, 6) d));
select t.ok((select count(*) from public.availability_rules where clinic_id = '11111111-1111-1111-1111-111111111111') = 14,
  '004 · Dois turnos por dia gravados (14 turnos na semana)');
select t.ok((select count(*) from public.availability_breaks where clinic_id = '11111111-1111-1111-1111-111111111111') = 7,
  '004 · Pausas gravadas junto com os turnos');
select t.ok(exists (select 1 from public.get_available_slots('11111111-1111-1111-1111-111111111111', '5a000000-0000-0000-0000-000000000001', t.day(13), t.day(13)) s where s.starts_at = t.slot(13, '14:00')),
  '004 · Turno da tarde gera horários livres (14:00)');
select t.ok(not exists (select 1 from public.get_available_slots('11111111-1111-1111-1111-111111111111', '5a000000-0000-0000-0000-000000000001', t.day(13), t.day(13)) s
                          where s.starts_at >= t.slot(13, '11:30') and s.starts_at < t.slot(13, '14:00')),
  '004 · Nenhum horário oferecido no intervalo entre turnos');
select t.ok(not exists (select 1 from public.get_available_slots('11111111-1111-1111-1111-111111111111', '5a000000-0000-0000-0000-000000000001', t.day(13), t.day(13)) s
                          where s.starts_at < t.slot(13, '10:15') and s.starts_at + interval '50 minutes' > t.slot(13, '10:00')),
  '004 · Pausa curta dentro do turno é respeitada');
select t.ok(not exists (select 1 from public.get_available_slots('11111111-1111-1111-1111-111111111111', '5a000000-0000-0000-0000-000000000001', t.day(13), t.day(13)) s
                          where s.starts_at + interval '50 minutes' > t.slot(13, '19:00')),
  '004 · Atendimento não ultrapassa o fim do turno da tarde');
select set_config('request.jwt.claims', '{"sub":"c4000000-0000-0000-0000-000000000004","role":"authenticated"}', false);
select public.register_my_patient('11111111-1111-1111-1111-111111111111', 'Cliente Quatro', '11988887777', true);
select t.throws($$select public.book_appointment('11111111-1111-1111-1111-111111111111', '5a000000-0000-0000-0000-000000000001', t.slot(13, '12:30'))$$,
  'SLOT_UNAVAILABLE', '004 · O banco recusa reserva no intervalo entre turnos');
select t.ok((public.book_appointment('11111111-1111-1111-1111-111111111111', '5a000000-0000-0000-0000-000000000001', t.slot(13, '17:00')) ->> 'id') is not null,
  '004 · O banco aceita reserva no turno da tarde');
-- volta ao horário original (9–18, almoço 12–13) para os testes seguintes
select set_config('request.jwt.claims', '{"sub":"aaaaaaaa-0000-0000-0000-000000000001","role":"authenticated"}', false);
select public.admin_save_schedule('11111111-1111-1111-1111-111111111111',
  (select jsonb_agg(jsonb_build_object('weekday', d, 'start', '09:00', 'end', '18:00')) from generate_series(0, 6) d),
  (select jsonb_agg(jsonb_build_object('weekday', d, 'start', '12:00', 'end', '13:00', 'label', 'Almoço')) from generate_series(0, 6) d));
select t.ok((select count(*) from public.availability_rules where clinic_id = '11111111-1111-1111-1111-111111111111') = 7
        and (select count(*) from public.availability_breaks where clinic_id = '11111111-1111-1111-1111-111111111111') = 7,
  '004 · Voltar para um turno por dia substitui tudo de uma vez');

select set_config('request.jwt.claims', '{"sub":"bbbbbbbb-0000-0000-0000-000000000001","role":"authenticated"}', false);
select t.throws($$select public.admin_save_schedule('11111111-1111-1111-1111-111111111111', '[]', '[]')$$,
  'FORBIDDEN', '004 · Administradora de outra clínica NÃO altera horários');
set role anon;
select set_config('request.jwt.claims', '', false);
select t.throws($$select public.admin_save_schedule('11111111-1111-1111-1111-111111111111', '[]', '[]')$$,
  'permission denied', '004 · Visitante não pode nem chamar a função de horários');

-- =============================================================================
-- C. Observações e pedidos presos à clínica do agendamento
-- =============================================================================
set role authenticated;
select set_config('request.jwt.claims', '{"sub":"bbbbbbbb-0000-0000-0000-000000000001","role":"authenticated"}', false);
select t.throws(format($$insert into public.appointment_notes (appointment_id, clinic_id, body) values (%L, '22222222-2222-2222-2222-222222222222', 'invasão')$$, t.get('a2')),
  'appointment_notes_same_clinic_fk', '004 · Administradora B NÃO grava observação em agendamento da clínica A');
reset role;
select t.throws(format($$insert into public.appointment_requests (appointment_id, clinic_id, type, status) values (%L, '22222222-2222-2222-2222-222222222222', 'cancel', 'rejected')$$, t.get('a2')),
  'appointment_requests_same_clinic_fk', '004 · Pedido não pode apontar para clínica diferente da do agendamento');

-- =============================================================================
-- D. Fila de avisos respeitando preferências
-- =============================================================================
update public.clinic_private_settings set notify_email = 'avisos@teste.local', notify_on_new_booking = true, notify_on_cancellation = true
 where clinic_id = '11111111-1111-1111-1111-111111111111';
set role authenticated;
select set_config('request.jwt.claims', '{"sub":"c4000000-0000-0000-0000-000000000004","role":"authenticated"}', false);
select t.set('a9', public.book_appointment('11111111-1111-1111-1111-111111111111', '5a000000-0000-0000-0000-000000000001', t.slot(13, '15:00')) ->> 'id');
select t.ok((select count(*) from public.notification_outbox) = 0, '004 · Cliente NÃO lê a fila de avisos');
reset role;
select t.ok((select count(*) from public.notification_outbox where appointment_id = t.get('a9')::uuid and kind = 'new_booking') = 1,
  '004 · Reserva on-line entra na fila de avisos');
select t.ok(not exists (select 1 from information_schema.columns where table_name = 'notification_outbox'
                        and column_name in ('email', 'phone', 'full_name', 'body', 'payload')),
  '004 · A fila de avisos não guarda nome, telefone ou e-mail do paciente');
set role authenticated;
select set_config('request.jwt.claims', '{"sub":"c4000000-0000-0000-0000-000000000004","role":"authenticated"}', false);
select public.cancel_my_appointment(t.get('a9')::uuid, 'teste');
reset role;
select t.ok((select count(*) from public.notification_outbox where appointment_id = t.get('a9')::uuid and kind in ('cancellation', 'request')) = 1,
  '004 · Cancelamento (ou pedido) do cliente entra na fila');
update public.clinic_private_settings set notify_on_new_booking = false where clinic_id = '11111111-1111-1111-1111-111111111111';
set role authenticated;
select set_config('request.jwt.claims', '{"sub":"c4000000-0000-0000-0000-000000000004","role":"authenticated"}', false);
select t.set('a10', public.book_appointment('11111111-1111-1111-1111-111111111111', '5a000000-0000-0000-0000-000000000001', t.slot(13, '16:00')) ->> 'id');
reset role;
select t.ok((select count(*) from public.notification_outbox where appointment_id = t.get('a10')::uuid) = 0,
  '004 · Com o aviso de novas reservas desligado, nada entra na fila');
set role authenticated;
select set_config('request.jwt.claims', '{"sub":"bbbbbbbb-0000-0000-0000-000000000001","role":"authenticated"}', false);
select t.ok((select count(*) from public.notification_outbox where clinic_id = '11111111-1111-1111-1111-111111111111') = 0,
  '004 · Administradora B NÃO vê a fila da clínica A');
select set_config('request.jwt.claims', '{"sub":"aaaaaaaa-0000-0000-0000-000000000001","role":"authenticated"}', false);
select t.ok((select count(*) from public.notification_outbox where clinic_id = '11111111-1111-1111-1111-111111111111') >= 2,
  '004 · Administradora A vê a situação da própria fila');
select t.throws($$insert into public.notification_outbox (clinic_id, kind) values ('11111111-1111-1111-1111-111111111111', 'new_booking')$$,
  'permission denied', '004 · Ninguém insere avisos falsos pela API');
select t.throws($$update public.notification_outbox set status = 'sent'$$,
  'permission denied', '004 · Ninguém marca aviso como "enviado" pela API');

select t.throws($$select * from public.claim_notifications(5)$$,
  'permission denied', '004 · Administradora NÃO pode "reservar" avisos (só a Edge Function, no servidor)');
select t.throws($$select public.finish_notification(gen_random_uuid(), true)$$,
  'permission denied', '004 · Administradora NÃO pode marcar aviso como enviado');
reset role;
grant usage on schema t to service_role; grant all on t.results, t.vars to service_role;
grant usage on sequence t.results_n_seq to service_role; grant execute on all functions in schema t to service_role;
select t.set('o1', (select id::text from public.notification_outbox order by created_at limit 1));
set role service_role;
select t.set('c1', (select count(*) from public.claim_notifications(10))::text);
select t.set('c2', (select count(*) from public.claim_notifications(10))::text);
select public.finish_notification(t.get('o1')::uuid, true);
reset role;
select t.ok(t.get('c1')::int >= 2 and t.get('c2')::int >= 1, '004 · Edge Function (service_role) reserva os avisos pendentes', t.get('c1') || '/' || t.get('c2'));
select t.ok((select max(attempts) from public.notification_outbox) = 2, '004 · Cada reserva conta uma tentativa');
select t.ok((select status = 'sent' and processed_at is not null from public.notification_outbox where id = t.get('o1')::uuid),
  '004 · Só a Edge Function marca "enviado", depois do envio');
set role authenticated;
select set_config('request.jwt.claims', '{"sub":"aaaaaaaa-0000-0000-0000-000000000001","role":"authenticated"}', false);

-- =============================================================================
-- E. Acesso administrativo
-- =============================================================================
select t.throws($$select public.create_admin_invite('11111111-1111-1111-1111-111111111111', 'nao-e-email')$$,
  'INVALID_EMAIL', '004 · Convite com e-mail inválido é recusado');
select t.throws($$select public.create_admin_invite('11111111-1111-1111-1111-111111111111', 'ADMIN.A@teste.local')$$,
  'ALREADY_MEMBER', '004 · Não convida quem já é administradora');
select t.set('inv1', public.create_admin_invite('11111111-1111-1111-1111-111111111111', 'outra.admin@teste.local'));
select t.set('inv2', public.create_admin_invite('11111111-1111-1111-1111-111111111111', 'outra.admin@teste.local'));
select t.ok(jsonb_array_length(public.list_admin_access('11111111-1111-1111-1111-111111111111') -> 'invites') = 1,
  '004 · Novo convite para o mesmo e-mail substitui o anterior');
select t.ok(jsonb_array_length(public.list_admin_access('11111111-1111-1111-1111-111111111111') -> 'members') = 2,
  '004 · Lista mostra as administradoras da clínica');
select set_config('request.jwt.claims', '{"sub":"eeeeeeee-0000-0000-0000-000000000001","role":"authenticated"}', false);
select t.throws($$select public.accept_admin_invite(t.get('inv1'))$$, 'INVITE_INVALID', '004 · Convite substituído não funciona mais');
select set_config('request.jwt.claims', '{"sub":"aaaaaaaa-0000-0000-0000-000000000001","role":"authenticated"}', false);
select public.revoke_admin_invite((public.list_admin_access('11111111-1111-1111-1111-111111111111') -> 'invites' -> 0 ->> 'id')::uuid);
select set_config('request.jwt.claims', '{"sub":"eeeeeeee-0000-0000-0000-000000000001","role":"authenticated"}', false);
select t.throws($$select public.accept_admin_invite(t.get('inv2'))$$, 'INVITE_INVALID', '004 · Convite revogado não funciona mais');
select t.throws($$select public.list_admin_access('11111111-1111-1111-1111-111111111111')$$, 'FORBIDDEN', '004 · Conta sem vínculo não lista acessos');
select t.throws($$insert into public.clinic_members (clinic_id, user_id, role) values ('11111111-1111-1111-1111-111111111111', 'eeeeeeee-0000-0000-0000-000000000001', 'owner')$$,
  'permission denied', '004 · Ninguém se torna administradora inserindo direto na tabela');
select t.throws($$update public.clinic_members set role = 'owner'$$,
  'permission denied', '004 · Ninguém se promove a proprietária pela API');
select set_config('request.jwt.claims', '{"sub":"bbbbbbbb-0000-0000-0000-000000000001","role":"authenticated"}', false);
select t.throws($$select public.list_admin_access('11111111-1111-1111-1111-111111111111')$$, 'FORBIDDEN', '004 · Administradora B NÃO lista acessos da clínica A');
select t.throws($$select public.remove_clinic_member('11111111-1111-1111-1111-111111111111', 'dddddddd-0000-0000-0000-000000000001')$$,
  'FORBIDDEN', '004 · Administradora B NÃO remove ninguém da clínica A');
-- convidada (admin comum) tenta remover a proprietária
select set_config('request.jwt.claims', '{"sub":"dddddddd-0000-0000-0000-000000000001","role":"authenticated"}', false);
select t.throws($$select public.remove_clinic_member('11111111-1111-1111-1111-111111111111', 'aaaaaaaa-0000-0000-0000-000000000001')$$,
  'FORBIDDEN', '004 · Administradora comum NÃO remove a proprietária');
select set_config('request.jwt.claims', '{"sub":"aaaaaaaa-0000-0000-0000-000000000001","role":"authenticated"}', false);
select t.throws($$select public.remove_clinic_member('11111111-1111-1111-1111-111111111111', 'aaaaaaaa-0000-0000-0000-000000000001')$$,
  'CANNOT_REMOVE_SELF', '004 · Proprietária não remove a si mesma');
select public.remove_clinic_member('11111111-1111-1111-1111-111111111111', 'dddddddd-0000-0000-0000-000000000001');
select set_config('request.jwt.claims', '{"sub":"dddddddd-0000-0000-0000-000000000001","role":"authenticated"}', false);
select t.ok((public.my_access('11111111-1111-1111-1111-111111111111') ->> 'role') = 'none', '004 · Administradora removida perde o acesso na hora');
select t.ok((select count(*) from public.patients) = 0, '004 · Administradora removida não vê mais pacientes');

-- =============================================================================
-- F. Anonimização completa
-- =============================================================================
reset role;
insert into public.patients (id, clinic_id, full_name, phone, email, created_via)
values ('9a000000-0000-0000-0000-000000000009', '11111111-1111-1111-1111-111111111111', 'Paciente Nove', '11977776666', 'nove@teste.local', 'admin');
insert into public.appointments (id, clinic_id, patient_id, service_id, starts_at, ends_at, occupied_until, status, source, service_name, duration_minutes, cancel_reason)
values ('9b000000-0000-0000-0000-000000000009', '11111111-1111-1111-1111-111111111111', '9a000000-0000-0000-0000-000000000009', '5a000000-0000-0000-0000-000000000001',
        t.slot(20, '08:00'), t.slot(20, '08:50'), t.slot(20, '09:00'), 'confirmed', 'manual', 'Avaliação podológica', 50, null),
       ('9c000000-0000-0000-0000-000000000009', '11111111-1111-1111-1111-111111111111', '9a000000-0000-0000-0000-000000000009', '5a000000-0000-0000-0000-000000000001',
        t.slot(-20, '08:00'), t.slot(-20, '08:50'), t.slot(-20, '09:00'), 'cancelled', 'manual', 'Avaliação podológica', 50, 'Telefone novo 11 95555-0000');
insert into public.appointment_notes (appointment_id, clinic_id, body) values ('9b000000-0000-0000-0000-000000000009', '11111111-1111-1111-1111-111111111111', 'Prefere fim de tarde');
insert into public.appointment_requests (clinic_id, appointment_id, type, reason) values ('11111111-1111-1111-1111-111111111111', '9b000000-0000-0000-0000-000000000009', 'cancel', 'Viagem com a família');
set role authenticated;
select set_config('request.jwt.claims', '{"sub":"aaaaaaaa-0000-0000-0000-000000000001","role":"authenticated"}', false);
select public.anonymize_patient('9a000000-0000-0000-0000-000000000009');
reset role;
select t.ok(not exists (select 1 from public.appointment_notes where appointment_id = '9b000000-0000-0000-0000-000000000009'),
  '004 · Anonimização apaga observações dos atendimentos do paciente');
select t.ok((select status = 'withdrawn' and reason is null from public.appointment_requests where appointment_id = '9b000000-0000-0000-0000-000000000009'),
  '004 · Anonimização encerra pedidos pendentes e apaga o texto do motivo');
select t.ok((select cancel_reason is null from public.appointments where id = '9c000000-0000-0000-0000-000000000009'),
  '004 · Anonimização apaga motivos livres de cancelamentos antigos');
select t.ok((select count(*) from public.appointments where patient_id = '9a000000-0000-0000-0000-000000000009') = 2,
  '004 · Histórico da agenda é mantido (sem identificação)');

-- =============================================================================
-- G. Identidade visual validada no banco
-- =============================================================================
set role authenticated;
select set_config('request.jwt.claims', '{"sub":"aaaaaaaa-0000-0000-0000-000000000001","role":"authenticated"}', false);
select t.throws($$update public.clinic_settings set branding = '{"paletteId":"ameixa-champagne","overrides":{"primary":"red;}body{display:none"}}' where clinic_id = '11111111-1111-1111-1111-111111111111'$$,
  'INVALID_BRANDING', '004 · Cor fora do formato #RRGGBB é recusada (sem injeção de CSS)');
select t.throws($$update public.clinic_settings set branding = '{"paletteId":"ameixa-champagne","overrides":{"fundoQualquer":"#ffffff"}}' where clinic_id = '11111111-1111-1111-1111-111111111111'$$,
  'INVALID_BRANDING', '004 · Chave de cor desconhecida é recusada');
update public.clinic_settings set branding = '{"paletteId":"verde-esmeralda","overrides":{"accent":"#C8AA78"}}' where clinic_id = '11111111-1111-1111-1111-111111111111';
select t.ok((select branding ->> 'paletteId' = 'verde-esmeralda' from public.clinic_settings where clinic_id = '11111111-1111-1111-1111-111111111111'),
  '004 · Paleta e cor personalizada válidas são salvas por clínica');
set role anon;
select set_config('request.jwt.claims', '', false);
select t.ok((select branding ->> 'paletteId' from public.clinic_settings where clinic_id = '11111111-1111-1111-1111-111111111111') = 'verde-esmeralda',
  '004 · Site público lê a identidade visual salva da clínica');
select t.ok((select branding ->> 'paletteId' from public.clinic_settings where clinic_id = '22222222-2222-2222-2222-222222222222') <> 'verde-esmeralda',
  '004 · A cor de uma clínica não vaza para outra');
reset role;
select t.ok((select column_default like '%ameixa-champagne%' from information_schema.columns where table_name = 'clinic_settings' and column_name = 'branding'),
  '004 · Paleta padrão de clínicas novas é Ameixa & Champagne');

-- =============================================================================
-- H. Varredura geral de privilégios
-- =============================================================================
select t.ok(not exists (
  select 1 from pg_proc p join pg_namespace n on n.oid = p.pronamespace
   where n.nspname in ('public', 'app') and p.prosecdef
     and not exists (select 1 from unnest(coalesce(p.proconfig, '{}')) c where c like 'search_path=%')),
  '004 · Toda função SECURITY DEFINER fixa o search_path');
select t.ok((select array_agg(p.proname::text order by p.proname) from pg_proc p join pg_namespace n on n.oid = p.pronamespace
              where n.nspname = 'public' and has_function_privilege('anon', p.oid, 'execute'))
            = array['get_available_slots', 'my_access'],
  '004 · Visitante só executa get_available_slots e my_access',
  (select string_agg(p.proname, ',') from pg_proc p join pg_namespace n on n.oid = p.pronamespace
    where n.nspname = 'public' and has_function_privilege('anon', p.oid, 'execute')));
select t.ok(not exists (select 1 from pg_proc p join pg_namespace n on n.oid = p.pronamespace
              where n.nspname = 'app' and has_function_privilege('authenticated', p.oid, 'execute')
                and p.proname not in ('is_clinic_admin', 'is_own_patient')),
  '004 · Funções internas (app.*) não podem ser chamadas pela API');
select t.ok(not exists (select 1 from pg_tables where schemaname = 'public' and not rowsecurity),
  '004 · Toda tabela pública tem RLS ligado');
select t.ok(not exists (select 1 from information_schema.role_table_grants
              where table_schema = 'public' and grantee = 'anon' and privilege_type in ('INSERT', 'UPDATE', 'DELETE')),
  '004 · Visitante não tem permissão de escrita em nenhuma tabela');

-- ---------- Resultado (somente os testes da 004) ----------
select case when ok then 'PASSOU' else 'FALHOU' end || ' · ' || name || coalesce('  [' || detail || ']', '') as resultado
from t.results where n > t.get('inicio_004')::int order by n;
select count(*) filter (where ok) || ' de ' || count(*) || ' testes da migração 004 passaram' as resumo
from t.results where n > t.get('inicio_004')::int;
select count(*) filter (where ok) || ' de ' || count(*) || ' testes de banco passaram (total 10 + 11)' as resumo_geral from t.results;
