-- =============================================================================
-- 004 — CORREÇÕES DE SEGURANÇA E NOVOS RECURSOS DO PAINEL
-- Modelo Avançado · Beatriz Nascimento | Podologia (template We Lúmen)
--
-- Aplica-se DEPOIS de 001, 002 e 003. Pode ser executada:
--   • em um projeto novo (001 → 002 → 003 → 004 → setup-clinica-e-admin.sql);
--   • em um banco que já tem 001–003 aplicadas (rode só esta).
-- É idempotente: pode ser executada mais de uma vez sem duplicar nada.
-- Nenhuma restrição existente é removida ou enfraquecida.
--
-- O que muda:
--   1. Observações e pedidos ficam presos à MESMA clínica do agendamento
--      (chave estrangeira composta).
--   2. Horários de atendimento/pausas só ficam visíveis ao público quando a
--      clínica está publicada (antes: qualquer pessoa via qualquer clínica).
--   3. Salvar horários vira uma operação ATÔMICA no banco, com vários turnos e
--      pausas por dia e validação de sobreposição (admin_save_schedule).
--   4. Anonimização (LGPD) também apaga observações dos atendimentos, textos
--      livres de motivos e encerra pedidos pendentes.
--   5. Gestão de acesso administrativo: listar, revogar convite, remover
--      administradora (só a proprietária), validação de e-mail do convite.
--   6. Fila de avisos por e-mail (notification_outbox) preenchida pelo banco,
--      respeitando as preferências. O ENVIO é feito por uma Edge Function
--      separada (modelo em supabase/functions/enviar-avisos) — NÃO TESTADA
--      contra um Supabase real. Sem ela, os avisos ficam "na fila".
--   7. Identidade visual: paleta padrão "ameixa-champagne" e validação das
--      cores salvas (somente #RRGGBB, somente as 5 chaves previstas).
-- =============================================================================

-- ---------------------------------------------------------------------------
-- 1. OBSERVAÇÕES E PEDIDOS SEMPRE DA MESMA CLÍNICA DO AGENDAMENTO
-- ---------------------------------------------------------------------------
do $$ begin
  if not exists (select 1 from pg_constraint where conname = 'appointments_id_clinic_key') then
    alter table public.appointments add constraint appointments_id_clinic_key unique (id, clinic_id);
  end if;
end $$;

-- Corrige eventuais linhas antigas inconsistentes antes de validar
-- (a clínica correta é sempre a do agendamento).
update public.appointment_notes n set clinic_id = a.clinic_id
  from public.appointments a where a.id = n.appointment_id and n.clinic_id <> a.clinic_id;
update public.appointment_requests r set clinic_id = a.clinic_id
  from public.appointments a where a.id = r.appointment_id and r.clinic_id <> a.clinic_id;

do $$ begin
  if not exists (select 1 from pg_constraint where conname = 'appointment_notes_same_clinic_fk') then
    alter table public.appointment_notes add constraint appointment_notes_same_clinic_fk
      foreign key (appointment_id, clinic_id) references public.appointments(id, clinic_id)
      on delete cascade not valid;
    alter table public.appointment_notes validate constraint appointment_notes_same_clinic_fk;
  end if;
  if not exists (select 1 from pg_constraint where conname = 'appointment_requests_same_clinic_fk') then
    alter table public.appointment_requests add constraint appointment_requests_same_clinic_fk
      foreign key (appointment_id, clinic_id) references public.appointments(id, clinic_id)
      on delete cascade not valid;
    alter table public.appointment_requests validate constraint appointment_requests_same_clinic_fk;
  end if;
end $$;

-- ---------------------------------------------------------------------------
-- 2. HORÁRIOS VISÍVEIS AO PÚBLICO SOMENTE PARA CLÍNICA PUBLICADA
-- ---------------------------------------------------------------------------
drop policy if exists rules_select on public.availability_rules;
create policy rules_select on public.availability_rules for select
  using (exists (select 1 from public.clinics c where c.id = clinic_id and (c.is_published or app.is_clinic_admin(c.id))));

drop policy if exists breaks_select on public.availability_breaks;
create policy breaks_select on public.availability_breaks for select
  using (exists (select 1 from public.clinics c where c.id = clinic_id and (c.is_published or app.is_clinic_admin(c.id))));

-- ---------------------------------------------------------------------------
-- 3. SALVAR HORÁRIOS DE FORMA ATÔMICA (vários turnos e pausas por dia)
-- p_rules:  [{"weekday":1,"start":"08:00","end":"12:00"}, {"weekday":1,"start":"14:00","end":"19:00"}]
-- p_breaks: [{"weekday":1,"start":"10:00","end":"10:15","label":"Café"}]
-- Regras: turnos do mesmo dia não se sobrepõem; cada pausa fica inteira dentro
-- de um turno; pausas não se sobrepõem; no máximo 6 turnos e 6 pausas por dia.
-- Ou grava tudo, ou não grava nada.
-- ---------------------------------------------------------------------------
create or replace function public.admin_save_schedule(p_clinic uuid, p_rules jsonb, p_breaks jsonb)
returns jsonb language plpgsql security definer set search_path = '' as $$
declare
  v_bad int;
begin
  if not app.is_clinic_admin(p_clinic) then perform app.fail('FORBIDDEN'); end if;
  if jsonb_typeof(coalesce(p_rules, 'null')) <> 'array' or jsonb_typeof(coalesce(p_breaks, 'null')) <> 'array' then
    perform app.fail('INVALID_SCHEDULE');
  end if;
  if jsonb_array_length(p_rules) > 42 or jsonb_array_length(p_breaks) > 42 then perform app.fail('INVALID_SCHEDULE'); end if;

  create temp table if not exists pg_temp.sched_r (weekday smallint, s time, e time) on commit drop;
  create temp table if not exists pg_temp.sched_b (weekday smallint, s time, e time, label text) on commit drop;
  truncate pg_temp.sched_r; truncate pg_temp.sched_b;

  begin
    insert into pg_temp.sched_r
      select (x->>'weekday')::smallint, (x->>'start')::time, (x->>'end')::time from jsonb_array_elements(p_rules) x;
    insert into pg_temp.sched_b
      select (x->>'weekday')::smallint, (x->>'start')::time, (x->>'end')::time,
             nullif(left(btrim(coalesce(x->>'label', '')), 60), '')
        from jsonb_array_elements(p_breaks) x;
  exception when others then
    perform app.fail('INVALID_SCHEDULE');
  end;

  -- campos obrigatórios, dia válido, fim depois do início
  select count(*) into v_bad from pg_temp.sched_r
   where weekday is null or s is null or e is null or weekday not between 0 and 6 or e <= s;
  if v_bad > 0 then perform app.fail('INVALID_SCHEDULE'); end if;
  select count(*) into v_bad from pg_temp.sched_b
   where weekday is null or s is null or e is null or weekday not between 0 and 6 or e <= s;
  if v_bad > 0 then perform app.fail('INVALID_SCHEDULE'); end if;

  -- limites por dia
  if exists (select 1 from pg_temp.sched_r group by weekday having count(*) > 6)
     or exists (select 1 from pg_temp.sched_b group by weekday having count(*) > 6) then
    perform app.fail('INVALID_SCHEDULE');
  end if;

  -- turnos sobrepostos no mesmo dia
  if exists (select 1 from pg_temp.sched_r a join pg_temp.sched_r b
               on a.weekday = b.weekday and a.ctid < b.ctid and a.s < b.e and b.s < a.e) then
    perform app.fail('SHIFT_OVERLAP');
  end if;
  -- pausas sobrepostas no mesmo dia
  if exists (select 1 from pg_temp.sched_b a join pg_temp.sched_b b
               on a.weekday = b.weekday and a.ctid < b.ctid and a.s < b.e and b.s < a.e) then
    perform app.fail('BREAK_OVERLAP');
  end if;
  -- toda pausa precisa caber inteira dentro de um turno do mesmo dia
  if exists (select 1 from pg_temp.sched_b b
              where not exists (select 1 from pg_temp.sched_r r
                                 where r.weekday = b.weekday and b.s >= r.s and b.e <= r.e)) then
    perform app.fail('BREAK_OUTSIDE_SHIFT');
  end if;

  delete from public.availability_breaks where clinic_id = p_clinic;
  delete from public.availability_rules  where clinic_id = p_clinic;
  insert into public.availability_rules (clinic_id, weekday, start_time, end_time)
    select p_clinic, weekday, s, e from pg_temp.sched_r order by weekday, s;
  insert into public.availability_breaks (clinic_id, weekday, start_time, end_time, label)
    select p_clinic, weekday, s, e, label from pg_temp.sched_b order by weekday, s;

  perform app.log(p_clinic, 'schedule.save', 'clinic', p_clinic);
  return jsonb_build_object('rules', (select count(*) from pg_temp.sched_r),
                            'breaks', (select count(*) from pg_temp.sched_b));
end $$;

-- ---------------------------------------------------------------------------
-- 4. ANONIMIZAÇÃO MAIS COMPLETA (LGPD)
-- Mantém o histórico de agenda (horário, serviço, status) sem identificação.
-- ---------------------------------------------------------------------------
create or replace function public.anonymize_patient(p_patient uuid)
returns void language plpgsql security definer set search_path = '' as $$
declare v_clinic uuid;
begin
  select clinic_id into v_clinic from public.patients where id = p_patient;
  if v_clinic is null or not app.is_clinic_admin(v_clinic) then perform app.fail('NOT_FOUND'); end if;

  -- pedidos em aberto são encerrados; textos livres apagados
  update public.appointment_requests r
     set status = case when r.status = 'pending' then 'withdrawn'::public.request_status else r.status end,
         resolved_at = coalesce(r.resolved_at, now()),
         reason = null, resolution_note = null
   where r.appointment_id in (select id from public.appointments where patient_id = p_patient);

  update public.appointments set status = 'cancelled', cancelled_at = now(), cancelled_by = 'admin',
         cancel_reason = 'Cadastro removido a pedido do titular'
   where patient_id = p_patient and status in ('pending', 'confirmed') and starts_at > now();
  -- motivos escritos pelo cliente/equipe podem conter dados pessoais
  update public.appointments set cancel_reason = null
   where patient_id = p_patient and cancel_reason is distinct from 'Cadastro removido a pedido do titular';

  delete from public.appointment_notes where appointment_id in (select id from public.appointments where patient_id = p_patient);
  delete from public.patient_notes where patient_id = p_patient;
  update public.patients set full_name = 'Paciente removido', phone = null, email = null,
         user_id = null, archived_at = coalesce(archived_at, now()) where id = p_patient;
  perform app.log(v_clinic, 'patient.anonymize', 'patient', p_patient);
end $$;

-- ---------------------------------------------------------------------------
-- 5. ACESSO ADMINISTRATIVO: convites revogáveis, lista e remoção
-- ---------------------------------------------------------------------------
alter table public.clinic_invites add column if not exists revoked_at timestamptz;

create or replace function public.create_admin_invite(p_clinic uuid, p_email text)
returns text language plpgsql security definer set search_path = '' as $$
declare
  v_token text;
  v_email text := lower(btrim(coalesce(p_email, '')));
begin
  if not app.is_clinic_admin(p_clinic) then perform app.fail('FORBIDDEN'); end if;
  if v_email !~* '^[^@\s]+@[^@\s]+\.[^@\s]+$' or length(v_email) > 254 then perform app.fail('INVALID_EMAIL'); end if;
  if exists (select 1 from public.clinic_members m join auth.users u on u.id = m.user_id
              where m.clinic_id = p_clinic and lower(u.email) = v_email) then
    perform app.fail('ALREADY_MEMBER');
  end if;
  if (select count(*) from public.clinic_invites where clinic_id = p_clinic and accepted_at is null
        and revoked_at is null and expires_at > now()) >= 20 then
    perform app.fail('TOO_MANY_INVITES');
  end if;
  -- um convite válido por e-mail: o anterior é revogado
  update public.clinic_invites set revoked_at = now()
   where clinic_id = p_clinic and email = v_email and accepted_at is null and revoked_at is null;
  v_token := replace(gen_random_uuid()::text, '-', '') || replace(gen_random_uuid()::text, '-', '');
  insert into public.clinic_invites (clinic_id, email, role, token_hash, expires_at, created_by)
  values (p_clinic, v_email, 'admin', encode(sha256(convert_to(v_token, 'UTF8')), 'hex'),
          now() + interval '7 days', auth.uid());
  perform app.log(p_clinic, 'invite.create', 'clinic', p_clinic);
  return v_token;
end $$;

create or replace function public.accept_admin_invite(p_token text)
returns uuid language plpgsql security definer set search_path = '' as $$
declare
  v_inv public.clinic_invites%rowtype;
  v_email text;
begin
  if auth.uid() is null then perform app.fail('AUTH_REQUIRED'); end if;
  select * into v_inv from public.clinic_invites
   where token_hash = encode(sha256(convert_to(coalesce(p_token, ''), 'UTF8')), 'hex')
     and accepted_at is null and revoked_at is null and expires_at > now()
   for update;
  if not found then perform app.fail('INVITE_INVALID'); end if;
  select lower(email) into v_email from auth.users where id = auth.uid();
  if v_email is distinct from v_inv.email then perform app.fail('INVITE_INVALID'); end if;
  -- o convite só concede 'admin'; nunca rebaixa nem promove uma proprietária
  insert into public.clinic_members (clinic_id, user_id, role) values (v_inv.clinic_id, auth.uid(), 'admin')
  on conflict do nothing;
  update public.clinic_invites set accepted_at = now() where id = v_inv.id;
  perform app.log(v_inv.clinic_id, 'invite.accept', 'clinic', v_inv.clinic_id);
  return v_inv.clinic_id;
end $$;

create or replace function public.list_admin_access(p_clinic uuid)
returns jsonb language plpgsql stable security definer set search_path = '' as $$
begin
  if not app.is_clinic_admin(p_clinic) then perform app.fail('FORBIDDEN'); end if;
  return jsonb_build_object(
    'members', coalesce((select jsonb_agg(jsonb_build_object(
        'user_id', m.user_id, 'email', u.email, 'role', m.role, 'created_at', m.created_at,
        'is_me', m.user_id = auth.uid()) order by m.role, m.created_at)
      from public.clinic_members m join auth.users u on u.id = m.user_id
      where m.clinic_id = p_clinic), '[]'::jsonb),
    'invites', coalesce((select jsonb_agg(jsonb_build_object(
        'id', i.id, 'email', i.email, 'created_at', i.created_at, 'expires_at', i.expires_at) order by i.created_at desc)
      from public.clinic_invites i
      where i.clinic_id = p_clinic and i.accepted_at is null and i.revoked_at is null and i.expires_at > now()), '[]'::jsonb));
end $$;

create or replace function public.revoke_admin_invite(p_invite uuid)
returns void language plpgsql security definer set search_path = '' as $$
declare v_clinic uuid;
begin
  select clinic_id into v_clinic from public.clinic_invites where id = p_invite and accepted_at is null and revoked_at is null;
  if v_clinic is null or not app.is_clinic_admin(v_clinic) then perform app.fail('NOT_FOUND'); end if;
  update public.clinic_invites set revoked_at = now() where id = p_invite;
  perform app.log(v_clinic, 'invite.revoke', 'clinic', v_clinic);
end $$;

-- Somente a PROPRIETÁRIA remove administradoras. Ninguém remove a si mesma
-- nem remove uma proprietária pela API (isso exige o painel do Supabase).
create or replace function public.remove_clinic_member(p_clinic uuid, p_user uuid)
returns void language plpgsql security definer set search_path = '' as $$
declare v_role public.member_role;
begin
  if not exists (select 1 from public.clinic_members where clinic_id = p_clinic and user_id = auth.uid() and role = 'owner') then
    perform app.fail('FORBIDDEN');
  end if;
  if p_user = auth.uid() then perform app.fail('CANNOT_REMOVE_SELF'); end if;
  select role into v_role from public.clinic_members where clinic_id = p_clinic and user_id = p_user;
  if v_role is null then perform app.fail('NOT_FOUND'); end if;
  if v_role = 'owner' then perform app.fail('CANNOT_REMOVE_OWNER'); end if;
  delete from public.clinic_members where clinic_id = p_clinic and user_id = p_user;
  perform app.log(p_clinic, 'member.remove', 'clinic', p_clinic);
end $$;

-- ---------------------------------------------------------------------------
-- 6. FILA DE AVISOS POR E-MAIL (sem dados pessoais na fila)
-- A fila guarda só: clínica, tipo, agendamento e situação do envio.
-- Quem envia é a Edge Function (chave secreta só no servidor do Supabase).
-- ---------------------------------------------------------------------------
create table if not exists public.notification_outbox (
  id             uuid primary key default gen_random_uuid(),
  clinic_id      uuid not null references public.clinics(id) on delete cascade,
  kind           text not null check (kind in ('new_booking', 'cancellation', 'request')),
  appointment_id uuid references public.appointments(id) on delete set null,
  status         text not null default 'pending' check (status in ('pending', 'sent', 'failed', 'skipped')),
  attempts       int  not null default 0 check (attempts between 0 and 20),
  last_error     text check (last_error is null or length(last_error) <= 300),
  created_at     timestamptz not null default now(),
  processed_at   timestamptz
);
create index if not exists notification_outbox_pending_idx on public.notification_outbox(status, created_at);
create index if not exists notification_outbox_clinic_idx on public.notification_outbox(clinic_id, created_at desc);

alter table public.notification_outbox enable row level security;
revoke all on public.notification_outbox from public, anon, authenticated;
grant select on public.notification_outbox to authenticated;
drop policy if exists outbox_select on public.notification_outbox;
create policy outbox_select on public.notification_outbox for select to authenticated
  using (app.is_clinic_admin(clinic_id));
-- (sem insert/update/delete pela API: só o banco e a Edge Function gravam)

create or replace function app.enqueue_notification(p_clinic uuid, p_kind text, p_appointment uuid)
returns void language plpgsql security definer set search_path = '' as $$
declare v public.clinic_private_settings%rowtype;
begin
  select * into v from public.clinic_private_settings where clinic_id = p_clinic;
  if not found or v.notify_email is null then return; end if;
  if p_kind = 'new_booking'  and not v.notify_on_new_booking  then return; end if;
  if p_kind = 'cancellation' and not v.notify_on_cancellation then return; end if;
  insert into public.notification_outbox (clinic_id, kind, appointment_id) values (p_clinic, p_kind, p_appointment);
end $$;

create or replace function app.trg_appointment_notify()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  if tg_op = 'INSERT' and new.source = 'online' then
    perform app.enqueue_notification(new.clinic_id, 'new_booking', new.id);
  elsif tg_op = 'UPDATE' and new.status = 'cancelled' and old.status <> 'cancelled' and new.cancelled_by = 'client' then
    perform app.enqueue_notification(new.clinic_id, 'cancellation', new.id);
  end if;
  return null;
end $$;

drop trigger if exists appointments_notify on public.appointments;
create trigger appointments_notify after insert or update of status on public.appointments
  for each row execute function app.trg_appointment_notify();

create or replace function app.trg_request_notify()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  -- pedidos de cancelamento/remarcação seguem a preferência de "cancelamentos"
  perform app.enqueue_notification(new.clinic_id, 'request', new.appointment_id);
  return null;
end $$;
-- 'request' respeita apenas o e-mail configurado (não há chave própria)

drop trigger if exists requests_notify on public.appointment_requests;
create trigger requests_notify after insert on public.appointment_requests
  for each row execute function app.trg_request_notify();

-- Funções usadas SOMENTE pela Edge Function (papel service_role, no servidor).
-- "Reserva" até p_limit avisos pendentes sem que duas execuções peguem o mesmo.
create or replace function public.claim_notifications(p_limit int default 20)
returns table (id uuid, clinic_id uuid, kind text, appointment_id uuid, attempts int)
language sql security definer set search_path = '' as $$
  update public.notification_outbox o
     set attempts = o.attempts + 1
   where o.id in (select x.id from public.notification_outbox x
                   where x.status = 'pending' and x.attempts < 5
                   order by x.created_at
                   limit greatest(1, least(coalesce(p_limit, 20), 100))
                   for update skip locked)
  returning o.id, o.clinic_id, o.kind, o.appointment_id, o.attempts;
$$;

create or replace function public.finish_notification(p_id uuid, p_ok boolean, p_error text default null)
returns void language sql security definer set search_path = '' as $$
  update public.notification_outbox
     set status = case when p_ok then 'sent' when attempts >= 5 then 'failed' else 'pending' end,
         last_error = case when p_ok then null else left(coalesce(p_error, 'erro'), 300) end,
         processed_at = now()
   where id = p_id;
$$;

-- ---------------------------------------------------------------------------
-- 7. IDENTIDADE VISUAL: padrão novo + validação das cores salvas
-- ---------------------------------------------------------------------------
alter table public.clinic_settings alter column branding
  set default '{"paletteId": "ameixa-champagne", "overrides": {}}'::jsonb;

create or replace function app.validate_branding()
returns trigger language plpgsql set search_path = '' as $$
declare k text; v jsonb;
begin
  if new.branding is null or jsonb_typeof(new.branding) <> 'object' then raise exception 'INVALID_BRANDING'; end if;
  if (new.branding ->> 'paletteId') is not null and (new.branding ->> 'paletteId') !~ '^[a-z0-9-]{1,40}$' then
    raise exception 'INVALID_BRANDING';
  end if;
  if exists (select 1 from jsonb_object_keys(new.branding) x where x not in ('paletteId', 'overrides')) then
    raise exception 'INVALID_BRANDING';
  end if;
  if new.branding ? 'overrides' then
    if jsonb_typeof(new.branding -> 'overrides') <> 'object' then raise exception 'INVALID_BRANDING'; end if;
    for k, v in select * from jsonb_each(new.branding -> 'overrides') loop
      if k not in ('primary', 'deep', 'accent', 'background', 'text') then raise exception 'INVALID_BRANDING'; end if;
      if jsonb_typeof(v) <> 'string' or (v #>> '{}') !~ '^#[0-9a-fA-F]{6}$' then raise exception 'INVALID_BRANDING'; end if;
    end loop;
  end if;
  return new;
end $$;

drop trigger if exists clinic_settings_branding_check on public.clinic_settings;
create trigger clinic_settings_branding_check before insert or update of branding on public.clinic_settings
  for each row execute function app.validate_branding();

-- ---------------------------------------------------------------------------
-- PERMISSÕES DE EXECUÇÃO (fechar tudo e liberar só o necessário)
-- ---------------------------------------------------------------------------
revoke all on function public.admin_save_schedule(uuid, jsonb, jsonb) from public, anon, authenticated;
revoke all on function public.anonymize_patient(uuid) from public, anon, authenticated;
revoke all on function public.create_admin_invite(uuid, text) from public, anon, authenticated;
revoke all on function public.accept_admin_invite(text) from public, anon, authenticated;
revoke all on function public.list_admin_access(uuid) from public, anon, authenticated;
revoke all on function public.revoke_admin_invite(uuid) from public, anon, authenticated;
revoke all on function public.remove_clinic_member(uuid, uuid) from public, anon, authenticated;
revoke all on function app.enqueue_notification(uuid, text, uuid) from public, anon, authenticated;
revoke all on function app.trg_appointment_notify() from public, anon, authenticated;
revoke all on function app.trg_request_notify() from public, anon, authenticated;
revoke all on function app.validate_branding() from public, anon, authenticated;
revoke all on function public.claim_notifications(int) from public, anon, authenticated;
revoke all on function public.finish_notification(uuid, boolean, text) from public, anon, authenticated;
grant execute on function public.claim_notifications(int) to service_role;
grant execute on function public.finish_notification(uuid, boolean, text) to service_role;

-- Funções internas (inclusive as de gatilho) não ficam expostas à API;
-- só os dois auxiliares usados pelas políticas de RLS continuam liberados.
revoke all on all functions in schema app from public, anon, authenticated;
grant execute on function app.is_clinic_admin(uuid) to anon, authenticated;
grant execute on function app.is_own_patient(uuid) to anon, authenticated;

grant execute on function public.admin_save_schedule(uuid, jsonb, jsonb) to authenticated;
grant execute on function public.anonymize_patient(uuid) to authenticated;
grant execute on function public.create_admin_invite(uuid, text) to authenticated;
grant execute on function public.accept_admin_invite(text) to authenticated;
grant execute on function public.list_admin_access(uuid) to authenticated;
grant execute on function public.revoke_admin_invite(uuid) to authenticated;
grant execute on function public.remove_clinic_member(uuid, uuid) to authenticated;
