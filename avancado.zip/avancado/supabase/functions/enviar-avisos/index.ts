// =============================================================================
// EDGE FUNCTION "enviar-avisos" — MODELO, NÃO TESTADO EM UM SUPABASE REAL
// -----------------------------------------------------------------------------
// Lê a fila public.notification_outbox (preenchida pelo banco, migração 004) e
// envia um e-mail curto para o endereço configurado pela clínica, usando o
// provedor Resend (https://resend.com). Roda NO SERVIDOR do Supabase:
//   • SUPABASE_URL e SUPABASE_SERVICE_ROLE_KEY são fornecidas automaticamente
//     pelo Supabase às Edge Functions — NUNCA copie a service_role para o site;
//   • RESEND_API_KEY e AVISOS_REMETENTE você cadastra como "secrets":
//       supabase secrets set RESEND_API_KEY=... AVISOS_REMETENTE="Clínica <avisos@seudominio.com>"
//   • publique:  supabase functions deploy enviar-avisos --no-verify-jwt
//   • agende (ex.: a cada 5 minutos) pelo painel do Supabase (Cron) ou por um
//     agendador externo chamando a URL da função com o cabeçalho
//     Authorization: Bearer <AVISOS_CHAVE_AGENDADOR> (outro secret seu).
// O e-mail NÃO contém telefone, e-mail do paciente nem dados de saúde: apenas
// o primeiro nome, o serviço e o horário. Veja docs/NOTIFICACOES.md.
// =============================================================================
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.4";

const URL_SB = Deno.env.get("SUPABASE_URL")!;
const SERVICE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const RESEND = Deno.env.get("RESEND_API_KEY") ?? "";
const REMETENTE = Deno.env.get("AVISOS_REMETENTE") ?? "";
const CHAVE = Deno.env.get("AVISOS_CHAVE_AGENDADOR") ?? "";

const TITULO: Record<string, string> = {
  new_booking: "Novo agendamento pelo site",
  cancellation: "Cancelamento feito pelo cliente",
  request: "Novo pedido de cancelamento/remarcação",
};

function quando(iso: string, tz: string) {
  return new Intl.DateTimeFormat("pt-BR", { timeZone: tz, dateStyle: "full", timeStyle: "short" }).format(new Date(iso));
}

Deno.serve(async (req) => {
  // Só o agendador (com a chave secreta) pode disparar o processamento
  if (!CHAVE || req.headers.get("authorization") !== `Bearer ${CHAVE}`) {
    return new Response("Não autorizado", { status: 401 });
  }
  if (!RESEND || !REMETENTE) return new Response("Provedor de e-mail não configurado", { status: 503 });

  const sb = createClient(URL_SB, SERVICE, { auth: { persistSession: false } });
  const { data: itens, error } = await sb.rpc("claim_notifications", { p_limit: 20 });
  if (error) return new Response("Erro ao ler a fila", { status: 500 });

  let enviados = 0;
  for (const it of itens ?? []) {
    try {
      const [{ data: priv }, { data: cli }, { data: ag }] = await Promise.all([
        sb.from("clinic_private_settings").select("notify_email").eq("clinic_id", it.clinic_id).single(),
        sb.from("clinics").select("name, timezone").eq("id", it.clinic_id).single(),
        it.appointment_id
          ? sb.from("appointments").select("starts_at, service_name, patients(full_name)").eq("id", it.appointment_id).single()
          : Promise.resolve({ data: null }),
      ]);
      if (!priv?.notify_email) { await sb.rpc("finish_notification", { p_id: it.id, p_ok: false, p_error: "Sem e-mail de aviso configurado" }); continue; }
      const nome = (ag?.patients?.full_name ?? "").split(" ")[0] || "Paciente";
      const texto = [
        TITULO[it.kind] ?? "Aviso do sistema",
        ag ? `${nome} · ${ag.service_name} · ${quando(ag.starts_at, cli?.timezone ?? "America/Sao_Paulo")}` : "",
        "Abra o painel para ver os detalhes.",
      ].filter(Boolean).join("\n");
      const r = await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: { "Authorization": `Bearer ${RESEND}`, "Content-Type": "application/json" },
        body: JSON.stringify({ from: REMETENTE, to: [priv.notify_email], subject: `${TITULO[it.kind] ?? "Aviso"} — ${cli?.name ?? ""}`, text: texto }),
      });
      if (!r.ok) throw new Error("Provedor respondeu " + r.status);
      await sb.rpc("finish_notification", { p_id: it.id, p_ok: true });
      enviados++;
    } catch (e) {
      await sb.rpc("finish_notification", { p_id: it.id, p_ok: false, p_error: String((e as Error).message).slice(0, 280) });
    }
  }
  return new Response(JSON.stringify({ processados: (itens ?? []).length, enviados }), { headers: { "Content-Type": "application/json" } });
});
