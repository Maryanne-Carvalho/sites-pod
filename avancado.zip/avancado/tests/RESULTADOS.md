# Resultados dos testes — Modelo Avançado · Beatriz Nascimento | Podologia

Executados em 11–12/11/2026, no ambiente de produção do modelo (Linux, PostgreSQL 16, Node 22, Google Chrome via Playwright). **Todos os números abaixo vêm de execuções reais.** Nada aqui foi executado contra um Supabase real.

## Resumo

| # | Suíte | Onde roda | O que prova | Resultado |
|---|---|---|---|---|
| 10 | `supabase/tests/10_testes_permissoes_e_agenda.sql` | PostgreSQL local (imitação do Supabase) | RLS, permissões, isolamento de clínicas e pacientes, regras de agenda, cancelar, remarcar, pedidos, convites, anonimização | **72 / 72** |
| 11 | `supabase/tests/11_testes_migracao_004.sql` (novo) | PostgreSQL local | horários atômicos com vários turnos, FKs da mesma clínica, horários só de clínica publicada, fila de avisos, acesso administrativo, anonimização ampliada, cores validadas, varredura de privilégios | **67 / 67** |
| 20 | `supabase/tests/20_reserva_simultanea.sh` | PostgreSQL local, conexões paralelas | 8 reservas simultâneas no mesmo horário → só 1 aceita; 2 gravações diretas sobrepostas → a restrição recusa 1 | **2 / 2** |
| 30 | `tests/30_comparar_navegador_e_banco.js` | Node + PostgreSQL local | o motor de horários do navegador e o do banco geram os mesmos horários | **5 / 5 cenários** |
| 40 | `tests/40_dados_demo_sem_conflito.js` | Node | dados fictícios não criam sobreposição | **passou** |
| 45 | `tests/45_funcoes_puras.js` (novo) | Node | CSV seguro, validação de horários, motor de temas (9 paletas, 400 combinações aleatórias) | **18 / 18** |
| 50 | `tests/50_navegador_completo.js` | Chrome, modo demonstração | percurso completo: agendamento, regras de horário, portal, pedidos, painel, relatórios, CSV, identidade visual por clínica, Ateliê, celular | **70 / 70** |
| 60 | `tests/60_responsivo_e_acessibilidade.js` (novo) | Chrome, modo demonstração | 11 larguras (320–1920 px) × 37 telas sem rolagem lateral, menus, janelas, Ateliê, acessibilidade básica em 34 páginas, foco, zero erros de JS | **62 / 62** |
| 90 | `supabase/tests/90_integracao_supabase_real.mjs` (novo) | **Supabase real (projeto de teste)** | o mesmo, de ponta a ponta, pela internet | **NÃO EXECUTADO** (sem acesso a projeto real) |

**Total executado: 296 verificações + 5 cenários + 1 suíte de dados — todas passaram.** A suíte 90 não entra nessa conta.

## O que mudou em relação à versão recebida

- A versão recebida declarava 54/54 no teste 50, mas na auditoria ele **falhava**: a data escolhida caía no “feriado de exemplo” dos dados fictícios. Corrigido no teste (escolhe uma segunda-feira sem bloqueios; usa horários que continuam livres). O sistema não tinha defeito.
- A seção de cores do teste 50 foi reescrita para os novos requisitos com mais verificações (9 → 24). O teste de “salvar horários” ficou mais exigente (confere turnos e pausas gravados).
- O teste 45 encontrou um defeito real: com algumas cores principais de tom médio, o texto do botão ficava em ~4,4:1. Corrigido no motor de temas (agora sempre ≥ 4,5:1).
- O teste 60 encontrou rolagem lateral em 320, 414, 768 e 1024 px (cabeçalho, portal, tabelas, calendário, editor de horários). Tudo corrigido e reexecutado.
- Nenhum teste foi removido nem enfraquecido.

## Como rodar

```bash
# Banco (precisa de PostgreSQL 16 com btree_gist; cria um banco descartável)
DB=welumen_test ./supabase/tests/rodar-testes.sh

# Navegador (Node 22 + Playwright + Chrome)
node tests/45_funcoes_puras.js
node tests/50_navegador_completo.js
node tests/60_responsivo_e_acessibilidade.js     # ~10 minutos

# Supabase real — SOMENTE em projeto de teste (instruções no arquivo)
node supabase/tests/90_integracao_supabase_real.mjs
```

## Limites do que foi provado

- **PostgreSQL local ≠ Supabase real.** A imitação reproduz os papéis e o `auth.uid()`, mas não o Supabase Auth, o PostgREST real nem as configurações do projeto.
- **Teste de interface ≠ teste de segurança.** As suítes 45/50/60 rodam no modo demonstração, que não tem segurança. Segurança é provada pelas suítes 10, 11 e 20 (no banco local).
- **Acessibilidade:** verificação automática, sem leitor de tela.
