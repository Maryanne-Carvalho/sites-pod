/* ==========================================================================
   TESTE COMPLETO NO NAVEGADOR (modo demonstração)
   Como rodar (precisa de Node e Playwright):
     npm i -D playwright && npx playwright install chromium
     node tests/50_navegador_completo.js
   Cada linha impressa diz PASSOU ou FALHOU. O processo termina com erro se
   alguma verificação falhar.
   ========================================================================== */
const { chromium } = require("playwright");
const path = require("path");
const BASE = "file://" + path.resolve(__dirname, "..") + "/";
let falhas = 0, total = 0;
function ok(cond, nome, extra) { total++; if (!cond) falhas++; console.log((cond ? "PASSOU" : "FALHOU") + " · " + nome + (extra ? "  (" + extra + ")" : "")); }

(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 1360, height: 900 }, acceptDownloads: true });
  await ctx.route(/unsplash|fonts\.|jsdelivr/, r => r.abort()); // sem internet: imagens/fontes externas ignoradas
  const p = await ctx.newPage();
  const erros = [];
  p.on("pageerror", e => erros.push(p.url().split("/").slice(-2).join("/") + ": " + e.message));
  p.on("console", m => { if (m.type() === "error" && !/net::ERR|Failed to load/.test(m.text())) erros.push("console: " + m.text()); });
  const ir = async (u, t = 900) => { await p.goto(BASE + u); await p.waitForTimeout(t); };
  const api = (fn, ...args) => p.evaluate(([src, a]) => { const f = eval("(" + src + ")"); return Promise.resolve(f(window.PS.api, ...a)).then(v => ({ v }), e => ({ erro: e.code || e.message })); }, [fn.toString(), args]);
  const entrar = async (area, quem) => {
    await ir(area + "/entrar.html");
    await p.evaluate(() => window.PS.api.sair && window.PS.api.sair());
    await ir(area + "/entrar.html");
    const c = quem === "admin" ? ["podologa.demo@exemplo.com", "demonstracao"] : ["cliente.demo@exemplo.com", "demonstracao"];
    await p.fill("#email", c[0]); await p.fill("#senha", c[1]); await p.click("[data-enviar]"); await p.waitForTimeout(1300);
  };

  /* ---------- 1. Rotas protegidas e perfis ---------- */
  await ir("demonstracao.html");
  await api(a => a.demo.restaurar());
  await ir("admin/index.html");
  ok(p.url().includes("admin/entrar.html"), "Painel sem login redireciona para o login da podóloga");
  await ir("cliente/index.html");
  ok(p.url().includes("cliente/entrar.html"), "Área do cliente sem login redireciona para o login do cliente");

  await entrar("cliente", "cliente");
  ok(p.url().includes("cliente/index.html"), "Cliente entra e cai em Meus agendamentos", p.url().split("/").slice(-2).join("/"));
  await ir("admin/index.html", 1200);
  ok(!p.url().includes("admin/index.html"), "Cliente logado NÃO abre o painel administrativo", p.url().split("/").slice(-2).join("/"));
  let r = await api(a => a.agendamentos(new Date(0).toISOString(), new Date().toISOString()));
  ok(r.erro === "FORBIDDEN" || r.erro === "NOT_ADMIN", "Cliente chamando a função de admin direto é recusado pelo 'servidor'", r.erro);
  r = await api(a => a.pacientes(""));
  ok(!!r.erro, "Cliente não lista pacientes", r.erro);

  await ir("cliente/entrar.html"); await p.evaluate(() => window.PS.api.sair());
  r = await api(a => a.entrar("podologa.demo@exemplo.com", "demonstracao", "client"));
  ok(r.erro === "USE_ADMIN_LOGIN", "Podóloga no login de cliente é orientada a usar o acesso administrativo", r.erro);
  r = await api(a => a.entrar("cliente.demo@exemplo.com", "demonstracao", "admin"));
  ok(r.erro === "NOT_ADMIN", "Cliente no login administrativo é recusada", r.erro);
  r = await api(a => a.entrar("cliente.demo@exemplo.com", "errada", "client"));
  ok(r.erro === "INVALID_LOGIN", "Senha errada dá mensagem genérica", r.erro);
  r = await api(a => a.cadastrarCliente({ nome: "Teste Admin", telefone: "11987650099", email: "virar.admin@exemplo.com", senha: "senha-forte-1", aceite: true, role: "admin", perfil: "admin" }));
  await api(a => a.entrar("virar.admin@exemplo.com", "senha-forte-1", "client"));
  r = await api(a => a.sessao());
  ok(r.v && r.v.role === "client", "Cadastro com 'role: admin' no formulário continua cliente", r.v && r.v.role);

  /* ---------- 2. Painel: horários, bloqueios, agendamento manual ---------- */
  await entrar("admin", "admin");
  ok(p.url().includes("admin/index.html"), "Podóloga entra no painel");
  const svc = (await api(a => a.servicos())).v.filter(s => s.isActive).sort((a, b) => a.durationMinutes - b.durationMinutes)[0];
  const tz = (await api(a => a.clinica())).v.timezone;
  // Próxima segunda-feira daqui a pelo menos 7 dias SEM bloqueios/feriados de exemplo
  // nela e nos dois dias seguintes (o teste usa seg, ter e qua). Antes, o teste
  // escolhia uma data fixa relativa a hoje e falhava quando caía no "feriado de
  // exemplo" dos dados fictícios — defeito do teste, não do sistema.
  const dia = await p.evaluate(async tz => {
    const T = window.PS.tempo;
    let d = T.addDays(T.todayIn(tz), 7);
    for (let tent = 0; tent < 30; tent++) {
      while (T.weekdayOf(d) !== 1) d = T.addDays(d, 1);
      const ini = T.zonedToDate(d, "00:00", tz).toISOString(), fim = T.zonedToDate(T.addDays(d, 3), "00:00", tz).toISOString();
      const bl = await window.PS.api.bloqueios(ini, fim);
      if (!bl.length) return d;
      d = T.addDays(d, 1);
    }
    return d;
  }, tz);
  const regras = [1, 2, 3, 4, 5].map(w => ({ weekday: w, start: "09:00", end: "18:00" }));
  const pausas = [1, 2, 3, 4, 5].map(w => ({ weekday: w, start: "12:00", end: "13:00" }));
  r = await api((a, rg, pz) => a.salvarHorarios(rg, pz), regras, pausas);
  ok(r.v && r.v.rules === 5 && r.v.breaks === 5, "Salvar horários (seg–sex 9h–18h, almoço 12h–13h) — gravação atômica", JSON.stringify(r.v || r.erro));
  r = await api((a, re) => a.salvarRegras(re), { bufferMinutes: 10, slotStepMinutes: 30, clientCancelMode: "approval", clientRescheduleMode: "approval", cancelMinHours: 24, rescheduleMinHours: 24, onlineBookingMode: "auto", maxActiveBookingsPerClient: 5 });
  ok(r.v === true, "Salvar regras (intervalo 10 min, cancelamento/remarcação com aprovação)");
  r = await api((a, s, d) => a.horariosLivres(s, d, d), svc.id, dia);
  let livres = r.v || [];
  const hm = iso => p.evaluate(([i, tz]) => window.PS.tempo.format.time(i, tz), [iso, tz]);
  const horas = await Promise.all(livres.map(s => hm(s.startsAt)));
  ok(livres.length > 0 && !horas.some(h => h >= "12:00" && h < "13:00"), "Nenhum horário livre dentro do almoço", horas.length + " livres");
  ok(!horas.some(h => h < "09:00"), "Nenhum horário antes da abertura");
  ok(new Date(livres[livres.length - 1].endsAt) <= new Date(await p.evaluate(([d, tz]) => window.PS.tempo.zonedToDate(d, "18:00", tz).toISOString(), [dia, tz])), "Último horário termina até 18h");

  const alvo = livres[0];
  const fimAlvo = new Date(new Date(alvo.startsAt).getTime() + 30 * 60000).toISOString();
  r = await api((a, b) => a.adicionarBloqueio(b), { startsAt: alvo.startsAt, endsAt: fimAlvo, kind: "block", reason: "Teste" });
  const idBloq = r.v && r.v.id;
  livres = (await api((a, s, d) => a.horariosLivres(s, d, d), svc.id, dia)).v;
  ok(!livres.some(s => s.startsAt === alvo.startsAt), "Bloqueio de horário some da lista de livres");
  await api((a, id) => a.removerBloqueio(id), idBloq);
  livres = (await api((a, s, d) => a.horariosLivres(s, d, d), svc.id, dia)).v;
  ok(livres.some(s => s.startsAt === alvo.startsAt), "Remover o bloqueio devolve o horário");

  const dia2 = await p.evaluate(d => window.PS.tempo.addDays(d, 1), dia);
  const ini2 = await p.evaluate(([d, tz]) => window.PS.tempo.zonedToDate(d, "00:00", tz).toISOString(), [dia2, tz]);
  const fim2 = await p.evaluate(([d, tz]) => window.PS.tempo.zonedToDate(window.PS.tempo.addDays(d, 1), "00:00", tz).toISOString(), [dia2, tz]);
  r = await api((a, b) => a.adicionarBloqueio(b), { startsAt: ini2, endsAt: fim2, kind: "holiday", allDay: true, reason: "Feriado de teste" });
  const liv2 = (await api((a, s, d) => a.horariosLivres(s, d, d), svc.id, dia2)).v;
  ok(liv2.length === 0, "Dia inteiro bloqueado (feriado) não tem horários", "agendamentos já existentes no dia: " + (r.v && r.v.agendamentosNoPeriodo));
  await api((a, id) => a.removerBloqueio(id), r.v && r.v.id);

  r = await api((a, nome) => a.salvarPaciente({ fullName: nome, phone: "11987651234", email: "" }), "Paciente Teste Automático");
  const pid = r.v;
  ok(!!pid, "Cadastrar paciente pelo painel");
  r = await api((a, s, i, pp) => a.agendar(s, i, pp), svc.id, alvo.startsAt, pid);
  ok(r.v && r.v.status === "confirmed", "Agendamento manual em horário livre é aceito e já confirmado");
  r = await api((a, s, i, pp) => a.agendar(s, i, pp), svc.id, alvo.startsAt, pid);
  ok(r.erro === "SLOT_UNAVAILABLE", "Mesmo horário de novo é recusado", r.erro);
  const meio = new Date(new Date(alvo.startsAt).getTime() + 10 * 60000).toISOString();
  r = await api((a, s, i, pp) => a.agendar(s, i, pp), svc.id, meio, pid);
  ok(r.erro === "SLOT_UNAVAILABLE", "Horário que encavala com outro atendimento é recusado", r.erro);
  livres = (await api((a, s, d) => a.horariosLivres(s, d, d), svc.id, dia)).v;
  const prox = livres.filter(s => s.startsAt > alvo.startsAt)[0];
  const minimo = new Date(new Date(alvo.startsAt).getTime() + (svc.durationMinutes + 10) * 60000);
  ok(prox && new Date(prox.startsAt) >= minimo, "Próximo livre respeita duração + intervalo de 10 min", prox && (await hm(prox.startsAt)));

  /* ---------- 3. Reserva dupla simultânea ---------- */
  r = await api(a => a.demo.testarReservaDupla());
  const aceitos = r.v ? r.v.resultados.filter(x => x.ok).length : -1;
  ok(aceitos === 1 && r.v.resultados.some(x => x.code === "SLOT_UNAVAILABLE"), "Duas reservas ao mesmo tempo no mesmo horário: só 1 entra", JSON.stringify(r.v && r.v.resultados.map(x => x.ok ? "aceita" : x.code)));
  await ir("demonstracao.html");
  await p.click("[data-dupla]"); await p.waitForTimeout(1200);
  const txtDupla = await p.textContent("[data-dupla-res]");
  ok(/recusad|não|indispon/i.test(txtDupla), "Botão 'testar reserva dupla' da central mostra a recusa", txtDupla.trim().slice(0, 90));

  /* ---------- 4. Cliente: agendar, pedir cancelamento e remarcação ---------- */
  await entrar("cliente", "cliente");
  const dia3 = await p.evaluate(d => window.PS.tempo.addDays(d, 2), dia);
  let l3 = (await api((a, s, d) => a.horariosLivres(s, d, d), svc.id, dia3)).v;
  r = await api((a, s, i) => a.agendar(s, i), svc.id, l3[0].startsAt);
  const aCli = r.v && r.v.id;
  ok(r.v && r.v.status === "confirmed", "Cliente agenda on-line (confirmação automática, o padrão)");
  r = await api((a, s, i) => a.agendar(s, i), svc.id, l3[0].startsAt);
  ok(r.erro === "SLOT_UNAVAILABLE", "Cliente não consegue o mesmo horário duas vezes", r.erro);
  r = await api((a, id) => a.cancelarMeu(id, "Teste"), aCli);
  ok(r.v === "requested", "Com regra 'aprovação', cancelamento vira pedido", r.v || r.erro);
  r = await api((a, id) => a.cancelarMeu(id, "Teste"), aCli);
  ok(r.erro === "REQUEST_ALREADY_OPEN", "Não abre dois pedidos para o mesmo agendamento", r.erro);
  await ir("cliente/index.html", 1200);
  ok(/aguardando/i.test(await p.textContent("main")), "Meus agendamentos mostra o pedido aguardando resposta");

  // Usa horários que continuam livres (os dados fictícios mudam conforme a data de hoje)
  l3 = (await api((a, s, d) => a.horariosLivres(s, d, d), svc.id, dia3)).v;
  ok(l3.length >= 2, "Ainda há horários livres no dia para testar a remarcação", l3.length + " livres");
  r = await api((a, s, i) => a.agendar(s, i), svc.id, l3[0].startsAt);
  const aCli2 = r.v && r.v.id;
  const alvoReag = l3[l3.length - 1].startsAt;
  r = await api((a, id, i) => a.reagendarMeu(id, i), aCli2, alvoReag);
  ok(r.v === "requested", "Remarcação vira pedido", r.v || r.erro);

  await entrar("admin", "admin");
  const pend = (await api(a => a.pedidosPendentes())).v;
  const qCancel = pend.find(q => q.appointment && q.appointment.id === aCli && q.type === "cancel");
  const qResch = pend.find(q => q.appointment && q.appointment.id === aCli2 && q.type === "reschedule");
  ok(qCancel && qResch, "Podóloga vê os dois pedidos pendentes");
  await api((a, id) => a.responderPedido(id, true), qCancel.id);
  await api((a, id) => a.responderPedido(id, true), qResch.id);
  const jan = await p.evaluate(([d, tz]) => [window.PS.tempo.zonedToDate(d, "00:00", tz).toISOString(), window.PS.tempo.zonedToDate(window.PS.tempo.addDays(d, 1), "00:00", tz).toISOString()], [dia3, tz]);
  const lista3 = (await api((a, d1, d2) => a.agendamentos(d1, d2), jan[0], jan[1])).v;
  ok(lista3.find(x => x.id === aCli).status === "cancelled", "Aprovar cancelamento cancela o agendamento");
  ok(lista3.find(x => x.id === aCli2).startsAt === alvoReag, "Aprovar remarcação move para o novo horário");
  r = await api((a, id) => a.mudarStatus(id, "completed"), aCli2);
  ok(r.erro === "NOT_STARTED_YET", "Não dá para marcar como concluído um atendimento futuro", r.erro);

  /* Pela tela: aprovar um pedido do seed na Visão geral */
  await ir("admin/index.html", 1300);
  const botoesAprovar = await p.$$("text=Aprovar");
  ok(botoesAprovar.length >= 1, "Visão geral mostra botões Aprovar/Recusar", botoesAprovar.length + " pedido(s)");

  /* ---------- 5. Pacientes ---------- */
  r = await api((a, id) => a.adicionarAnotacao(id, "Prefere horários pela manhã"), pid);
  let pac = (await api((a, id) => a.paciente(id), pid)).v;
  ok(pac.notes.length === 1, "Adicionar anotação administrativa");
  r = await api((a, id) => a.anonimizarPaciente(id), pid);
  pac = (await api((a, id) => a.paciente(id), pid)).v;
  ok(pac.archived && !/Teste Automático/.test(pac.fullName) && !pac.phone && pac.notes.length === 0, "Anonimizar remove nome, telefone e anotações", pac.fullName);
  ok(pac.appointments.every(x => x.status === "cancelled" || new Date(x.startsAt) < new Date()), "Anonimizar cancela horários futuros");
  await ir("admin/pacientes.html", 1000);
  await p.fill("[data-q]", "Carla"); await p.waitForTimeout(600);
  ok((await p.$$("[data-lista] [data-id]")).length === 1, "Busca de pacientes por nome");

  /* ---------- 6. Relatórios e exportação ---------- */
  await ir("admin/relatorios.html", 1400);
  const [down] = await Promise.all([p.waitForEvent("download"), p.click("[data-csv]")]);
  const csv = require("fs").readFileSync(await down.path(), "utf8");
  ok(/^﻿"Data";"Horário";"Paciente"/.test(csv) && csv.split("\r\n").length > 5, "Exportar CSV no painel", csv.split("\r\n").length - 1 + " linhas");
  await entrar("cliente", "cliente");
  await ir("admin/relatorios.html", 1200);
  ok(!p.url().includes("admin/relatorios.html"), "Relatórios (e exportação) inacessíveis para cliente");

  /* ---------- 7. Identidade visual (9 paletas, 5 cores, por clínica) ---------- */
  await entrar("admin", "admin");
  await ir("admin/configuracoes.html?aba=cores", 1100);
  const pals = await p.$$eval("[data-pal]", b => b.map(x => x.getAttribute("data-pal")));
  const esperadas = ["ameixa-champagne", "preto-dourado", "verde-esmeralda", "azul-noite", "bordo-rose", "chocolate-nude", "azul-petroleo", "cinza-prata", "terracota-premium"];
  ok(pals.length === 9 && esperadas.every(x => pals.includes(x)), "9 paletas pedidas disponíveis no painel", pals.join(", "));
  const corPrev = k => p.evaluate(k => document.querySelector("[data-prev]").style.getPropertyValue(k).trim().toLowerCase(), k || "--color-primary");
  const corPainel = () => p.evaluate(() => getComputedStyle(document.body).getPropertyValue("--color-primary").trim().toLowerCase());
  const painelAntes = await corPainel();
  const vistos = new Set(); const contrastesRuins = [];
  for (const id of pals) {
    await p.click('[data-pal="' + id + '"]'); await p.waitForTimeout(120);
    vistos.add(await corPrev());
    const ruins = await p.$$eval("[data-checks] li.bad", l => l.map(x => x.textContent));
    if (ruins.length) contrastesRuins.push(id + ": " + ruins.join(" | "));
  }
  ok(vistos.size === 9, "Cada paleta muda a prévia na hora (9 cores principais diferentes)");
  ok(contrastesRuins.length === 0, "Todas as 9 paletas passam no contraste AA (texto, botão, links, seções escuras, destaque)", contrastesRuins.join("; "));
  ok((await corPainel()) === painelAntes && painelAntes === "#4e3046", "Trocar a paleta NÃO altera a identidade do painel", painelAntes);
  await p.click('[data-pal="verde-esmeralda"]'); await p.waitForTimeout(120);
  const hex = async (k, v) => { await p.fill("#hx-" + k, v); await p.waitForTimeout(120); };
  await hex("primary", "#1F5F8B");
  ok((await corPrev()) === "#1f5f8b", "Cor principal digitada em HEX aplicada na prévia");
  await hex("accent", "zz12");
  ok((await p.getAttribute("#hx-accent", "aria-invalid")) === "true", "HEX inválido é sinalizado e não aplicado");
  await p.$eval("#hx-accent", el => el.blur());
  await hex("background", "#FFFDF8"); await hex("text", "#1A1A1A"); await hex("deep", "#0E2A22");
  ok((await corPrev("--color-background")) === "#fffdf8" && (await corPrev("--color-deep")) === "#0e2a22", "As 5 cores manuais são editáveis (fundo e profunda conferidos)");
  await p.click('[data-reset="deep"]'); await p.waitForTimeout(120);
  ok((await corPrev("--color-deep")) === "#12392e", "Restaurar UMA cor volta ao valor da paleta", await corPrev("--color-deep"));
  await hex("primary", "#F4E9A8");
  const botao = await p.$$eval("[data-checks] li", l => l.map(x => x.textContent).find(t => /Botão/.test(t)) || "");
  ok(/AA/.test(botao) && !/abaixo/.test(botao), "Com cor principal muito clara, o texto do botão é recalculado e continua AA", botao);
  await hex("primary", "#1F5F8B");
  ok(!(await p.$eval("[data-salvar]", b => b.disabled)), "Botão salvar liberado quando o contraste é suficiente");
  await p.click("[data-salvar]"); await p.waitForTimeout(700);
  ok(/Identidade salva/i.test(await p.textContent("[data-msg]")), "Salvar identidade da clínica", (await p.textContent("[data-msg]")).trim());
  const salvo = (await api(a => a.clinica())).v.settings.branding;
  ok(salvo.paletteId === "verde-esmeralda" && salvo.overrides.primary === "#1f5f8b" && salvo.overrides.background === "#fffdf8", "Identidade gravada na clínica (paleta + cores manuais)", JSON.stringify(salvo));
  const raiz = () => p.evaluate(() => getComputedStyle(document.documentElement).getPropertyValue("--color-primary").trim().toLowerCase());
  await ir("index.html", 900); const corSite = await raiz();
  await ir("cliente/entrar.html", 900); const corCli = await raiz();
  await ir("admin/agenda.html", 900); const corAdm = await corPainel();
  ok(corSite === "#1f5f8b" && corCli === "#1f5f8b", "Identidade salva aparece no site e no portal do cliente", corSite + " / " + corCli);
  ok(corAdm === "#4e3046", "Painel continua com a identidade própria", corAdm);
  const chave = await p.evaluate(() => Object.keys(localStorage).filter(k => /cores/.test(k)));
  ok(chave.length === 1 && chave[0] === "avancado-demo:beatriz-nascimento:cores", "Cores da demonstração numa chave exclusiva do Avançado", chave.join(","));
  await ir("admin/configuracoes.html?aba=cores", 1000);
  await p.click("[data-original]"); await p.waitForTimeout(150);
  await p.click("[data-salvar]"); await p.waitForTimeout(700);
  const pad = (await api(a => a.clinica())).v.settings.branding;
  ok(pad.paletteId === "ameixa-champagne" && Object.keys(pad.overrides).length === 0, "Restaurar Ameixa & Champagne e salvar volta à identidade original", JSON.stringify(pad));

  /* Ateliê de cores no site (demonstração) */
  await ir("index.html", 900);
  await p.click("[data-atl-open]"); await p.waitForTimeout(200);
  ok(await p.isVisible("[data-atl]"), "Ateliê de cores abre no site");
  ok((await p.$$("[data-atl] .atl-pal")).length === 9 && (await p.$$("[data-atl] [data-hex]")).length === 5, "Ateliê tem 9 paletas e 5 cores com HEX editável");
  await p.click('[data-atl] [data-palette="bordo-rose"]'); await p.waitForTimeout(150);
  ok((await raiz()) === "#7a2e3d", "Paleta do ateliê aplicada na hora no site", await raiz());
  await p.fill("#atl-hex-accent", "#D4AF37"); await p.waitForTimeout(150);
  ok((await p.evaluate(() => window.PS.theme.getState().colors.accent)) === "#d4af37", "HEX digitado no ateliê aplicado na hora");
  await p.click('[data-atl] [data-reset="accent"]'); await p.waitForTimeout(150);
  ok((await p.evaluate(() => window.PS.theme.getState().customized)) === false, "Restaurar a cor no ateliê remove o ajuste");
  await ir("sobre.html", 800);
  ok((await raiz()) === "#7a2e3d", "Escolha do ateliê persiste ao trocar de página");
  await p.click("[data-atl-open]"); await p.click("[data-atl-restore]"); await p.waitForTimeout(150);
  ok((await raiz()) === "#59364f", "Restaurar identidade original no ateliê", await raiz());
  await ir("admin/index.html", 900);
  ok((await p.$$("[data-atl-open]")).length === 0, "Ateliê não aparece dentro do painel administrativo");

  /* ---------- 8. Celular 390px: sem rolagem lateral ---------- */
  const mob = await browser.newContext({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true });
  await mob.route(/unsplash|fonts\.|jsdelivr/, r => r.abort());
  const m = await mob.newPage();
  m.on("pageerror", e => erros.push("mobile " + m.url().split("/").slice(-2).join("/") + ": " + e.message));
  const largura = async u => { await m.goto(BASE + u); await m.waitForTimeout(900); return m.evaluate(() => document.documentElement.scrollWidth); };
  await m.goto(BASE + "admin/entrar.html"); await m.waitForTimeout(700);
  await m.fill("#email", "podologa.demo@exemplo.com"); await m.fill("#senha", "demonstracao"); await m.click("[data-enviar]"); await m.waitForTimeout(1300);
  const paginas = ["index.html", "sobre.html", "clinica.html", "servicos.html", "avaliacoes.html", "contato.html", "agendar.html", "demonstracao.html", "privacidade.html",
    "cliente/entrar.html", "cliente/cadastro.html", "cliente/recuperar-senha.html",
    "admin/index.html", "admin/agenda.html", "admin/agenda.html?aba=horarios", "admin/agenda.html?aba=bloqueios", "admin/novo-agendamento.html", "admin/pacientes.html", "admin/relatorios.html",
    "admin/configuracoes.html", "admin/configuracoes.html?aba=servicos", "admin/configuracoes.html?aba=horarios", "admin/configuracoes.html?aba=regras",
    "admin/configuracoes.html?aba=confirmacao", "admin/configuracoes.html?aba=cancelamento", "admin/configuracoes.html?aba=remarcacao",
    "admin/configuracoes.html?aba=notificacoes", "admin/configuracoes.html?aba=cores", "admin/configuracoes.html?aba=acesso",
    "cliente/index.html", "cliente/meus-dados.html"];
  const largas = [];
  for (const u of paginas) { const w = await largura(u); if (w > 391) largas.push(u + "=" + w); }
  await m.goto(BASE + "admin/agenda.html"); await m.waitForTimeout(900);
  for (const v of ["Semana", "Mês"]) { await m.click("text=" + v).catch(() => {}); await m.waitForTimeout(500); const w = await m.evaluate(() => document.documentElement.scrollWidth); if (w > 391) largas.push("agenda " + v + "=" + w); }
  ok(largas.length === 0, "Celular (390px): nenhuma página com rolagem lateral", largas.join(", ") || paginas.length + 2 + " telas");
  await m.screenshot({ path: path.join(__dirname, "capturas", "celular-agenda-mes.png"), fullPage: false }).catch(() => {});
  await mob.close();

  /* ---------- 9. Sem erros de JavaScript ---------- */
  ok(erros.length === 0, "Nenhum erro de JavaScript em todo o percurso", erros.slice(0, 5).join(" | "));

  console.log("\n" + (total - falhas) + " de " + total + " verificações passaram.");
  await browser.close();
  process.exit(falhas ? 1 : 0);
})().catch(e => { console.error("ERRO NO TESTE:", e); process.exit(2); });
