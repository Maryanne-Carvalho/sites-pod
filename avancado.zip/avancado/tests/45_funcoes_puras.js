/* ==========================================================================
   TESTES DE FUNÇÕES PURAS (Node, sem navegador)
   • Célula de CSV segura contra injeção de fórmulas
   • Validação local dos horários (espelho de admin_save_schedule)
   • Motor de temas: 9 paletas, contraste AA, 5 cores editáveis, URL de tema
   Uso: node tests/45_funcoes_puras.js
   ========================================================================== */
const fs = require("fs"), path = require("path"), vm = require("vm");
const R = path.resolve(__dirname, "..");
let falhas = 0, total = 0;
function ok(c, n, x) { total++; if (!c) falhas++; console.log((c ? "PASSOU" : "FALHOU") + " · " + n + (x ? "  (" + x + ")" : "")); }

// Ambiente mínimo de navegador
const store = {};
const el = () => ({ style: { setProperty() {} }, classList: { add() {}, remove() {}, toggle() {}, contains() { return false; } }, setAttribute() {}, getAttribute() { return null; }, addEventListener() {}, appendChild() {}, insertAdjacentHTML() {}, querySelector() { return null; } });
const ctx = {
  console, setTimeout, clearTimeout, Promise, Intl, URLSearchParams,
  localStorage: { getItem: k => store[k] || null, setItem: (k, v) => { store[k] = String(v); }, removeItem: k => { delete store[k]; } },
  location: { search: "", pathname: "/index.html", protocol: "file:" },
  navigator: { onLine: true },
  CustomEvent: function (t, o) { this.type = t; this.detail = o && o.detail; },
  document: { readyState: "complete", documentElement: el(), body: Object.assign(el(), { getAttribute: () => null }), querySelector: () => null, querySelectorAll: () => [], addEventListener() {}, dispatchEvent() {}, createElement: el },
  addEventListener() {}
};
ctx.window = ctx; ctx.globalThis = ctx;
vm.createContext(ctx);
const load = f => vm.runInContext(fs.readFileSync(path.join(R, f), "utf8"), ctx, { filename: f });
["sistema/js/config.js", "js/content.js", "js/palettes.js", "js/color-utils.js", "js/theme-engine.js", "sistema/js/tempo.js", "sistema/js/ui.js", "sistema/js/admin-horarios.js"].forEach(load);
const PS = ctx.PS;

/* ---------- CSV ---------- */
const cel = PS.sys.csvCelula;
const perigosos = ["=1+1", "+SOMA(A1)", "-2+3", "@cmd", "\t=1", "\r=1", "  =HYPERLINK(\"x\")", "=cmd|' /C calc'!A0"];
ok(perigosos.every(v => cel(v).startsWith("\"'")), "CSV: conteúdo que vira fórmula recebe apóstrofo (" + perigosos.length + " casos, inclusive TAB, CR e espaços)");
ok(cel('Ana "Bia"') === '"Ana ""Bia"""', "CSV: aspas internas duplicadas e célula sempre entre aspas");
ok(cel("Maria") === '"Maria"' && cel(null) === '""' && cel(50) === '"50"', "CSV: texto comum, vazio e número sem alteração");

/* ---------- Horários ---------- */
const v = PS.admin.validarHorarios;
const T = (w, s, e) => ({ weekday: w, start: s, end: e });
ok(v([T(1, "08:00", "12:00"), T(1, "14:00", "19:00")], [T(1, "10:00", "10:15")]) === null, "Horários: dois turnos com pausa dentro é aceito");
ok(/sobrepondo/.test(v([T(1, "08:00", "12:00"), T(1, "11:00", "15:00")], []) || ""), "Horários: turnos sobrepostos recusados");
ok(/dentro de um turno/.test(v([T(1, "08:00", "12:00"), T(1, "14:00", "19:00")], [T(1, "12:30", "13:00")]) || ""), "Horários: pausa no intervalo entre turnos recusada");
ok(/sobrepondo/.test(v([T(2, "08:00", "18:00")], [T(2, "12:00", "13:00"), T(2, "12:30", "13:30")]) || ""), "Horários: pausas sobrepostas recusadas");
ok(/terminar depois/.test(v([T(3, "18:00", "09:00")], []) || ""), "Horários: fim antes do início recusado");
ok(/máximo 6/.test(v([0, 1, 2, 3, 4, 5, 6].map(i => T(4, "0" + i + ":00", "0" + i + ":30")), []) || ""), "Horários: mais de 6 turnos no dia recusado");
ok(v([T(5, "08:00", "12:00"), T(5, "12:00", "16:00")], []) === null, "Horários: turnos encostados (12:00 fim / 12:00 início) são aceitos");

/* ---------- Motor de temas ---------- */
const th = PS.theme;
th.init();
ok(PS.palettes.length === 9, "Tema: 9 paletas", PS.palettes.map(p => p.id).join(","));
ok(th.getState().palette.id === "ameixa-champagne", "Tema: paleta padrão Ameixa & Champagne");
ok(JSON.stringify(th.editable) === JSON.stringify(["primary", "deep", "accent", "background", "text"]), "Tema: 5 cores editáveis");
const ruins = [];
PS.palettes.forEach(p => th.compute(p, {}).checks.forEach(c => { if (c.ratio < 4.5) ruins.push(p.id + ":" + c.id + "=" + c.ratio.toFixed(2)); }));
ok(ruins.length === 0, "Tema: todas as paletas com contraste ≥ 4,5:1 em todos os pares verificados", ruins.join(" "));
// Fuzz: cores manuais aleatórias — texto do botão e texto sobre fundo continuam legíveis
let seed = 7; const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
const hex = () => "#" + [0, 0, 0].map(() => Math.floor(rnd() * 256).toString(16).padStart(2, "0")).join("");
let piores = [];
for (let i = 0; i < 400; i++) {
  const p = PS.palettes[i % 9];
  const r = th.compute(p, { primary: hex(), accent: hex() });
  r.checks.filter(c => c.id === "text" || c.id === "button").forEach(c => { if (c.ratio < 4.5) piores.push(c.id + " " + c.ratio.toFixed(2)); });
}
ok(piores.length === 0, "Tema: 400 combinações aleatórias de principal/destaque mantêm texto e botão ≥ 4,5:1", piores.slice(0, 5).join("; "));
th.setPalette("verde-esmeralda"); th.setOverride("background", "#ffffff"); th.setOverride("text", "#111111");
const q = th.toQuery();
ok(/^verde-esmeralda\./.test(q) && /bffffff/.test(q) && /t111111/.test(q), "Tema: cores manuais (fundo/texto) vão para o endereço quando o armazenamento falha", q);
th.resetColor("background");
ok(!("background" in th.getState().overrides), "Tema: restaurar uma única cor");
th.setBranding({ paletteId: "paleta-que-nao-existe", overrides: { primary: "red;}" } });
ok(th.getState().palette.id === "ameixa-champagne" && Object.keys(th.getState().overrides).length === 0, "Tema: paleta desconhecida e cor inválida vindas do banco são ignoradas com segurança");

console.log("\n" + (total - falhas) + " de " + total + " verificações passaram.");
process.exit(falhas ? 1 : 0);
