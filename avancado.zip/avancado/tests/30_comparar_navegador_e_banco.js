/* ==========================================================================
   TESTE: o cálculo de horários do navegador (sistema/js/disponibilidade.js)
   dá EXATAMENTE o mesmo resultado que a função do banco (app.compute_slots)?
   Roda vários cenários (grades, durações, intervalos, turnos, fusos, pausas,
   bloqueios e agendamentos) e compara as duas listas horário a horário.
   Uso: node tests/30_comparar_navegador_e_banco.js   (com o banco de teste criado)
   ========================================================================== */
const { execFileSync } = require("child_process");
const path = require("path");
global.window = globalThis;
require(path.join(__dirname, "../sistema/js/tempo.js"));
const D = require(path.join(__dirname, "../sistema/js/disponibilidade.js"));

const DB = process.env.DB || "welumen_test";
const CLINIC = "11111111-1111-1111-1111-111111111111";
function sql(q) {
  // A consulta vai pela entrada padrão (sem problemas de aspas)
  // PSQL_DIRETO=1: chama o psql do próprio usuário; sem isso, usa "su postgres" (como no ambiente de testes original)
  const cmd = process.env.PSQL_DIRETO ? ["psql", ["-q", "-t", "-A", "-v", "ON_ERROR_STOP=1", "-d", DB]] : ["su", ["postgres", "-c", `psql -q -t -A -v ON_ERROR_STOP=1 -d ${DB}`]];
  return execFileSync(cmd[0], cmd[1], { input: q + ";\n", encoding: "utf8" }).trim();
}
function json(q) { const r = sql(`select coalesce(json_agg(x), '[]') from (${q}) x`); return JSON.parse(r || "[]"); }

const scenarios = [
  { name: "grade 30 min, serviço 50 min, intervalo 10", step: 30, dur: 50, buf: 10, tz: "America/Sao_Paulo", notice: 2 },
  { name: "grade 15 min, serviço 40 min, sem intervalo", step: 15, dur: 40, buf: 0, tz: "America/Sao_Paulo", notice: 0 },
  { name: "grade 20 min, serviço 90 min, intervalo 15", step: 20, dur: 90, buf: 15, tz: "America/Sao_Paulo", notice: 24 },
  { name: "grade 45 min, serviço 30 min, fuso de Manaus", step: 45, dur: 30, buf: 5, tz: "America/Manaus", notice: 2 },
  { name: "dois turnos no mesmo dia, fuso de Lisboa (tem horário de verão)", step: 30, dur: 60, buf: 10, tz: "Europe/Lisbon", notice: 1, splitShift: true }
];

let pass = 0, fail = 0;
for (const sc of scenarios) {
  sql(`update public.clinics set timezone = '${sc.tz}' where id = '${CLINIC}'`);
  sql(`update public.clinic_settings set slot_step_minutes = ${sc.step}, buffer_minutes = ${sc.buf}, booking_min_notice_hours = ${sc.notice}, booking_horizon_days = 60 where clinic_id = '${CLINIC}'`);
  sql(`insert into public.services (id, clinic_id, name, duration_minutes) values ('5a000000-0000-0000-0000-0000000000ff', '${CLINIC}', 'Serviço de comparação', ${sc.dur})
       on conflict (id) do update set duration_minutes = excluded.duration_minutes`);
  if (sc.splitShift) {
    sql(`insert into public.availability_rules (clinic_id, weekday, start_time, end_time) select '${CLINIC}', d, '19:00', '21:30' from generate_series(0,6) d`);
  }

  const from = sql(`select ((now() at time zone '${sc.tz}')::date)::text`);
  const to = sql(`select ((now() at time zone '${sc.tz}')::date + 20)::text`);
  const fromDb = sql(`select coalesce(string_agg(to_char(starts_at at time zone 'UTC', 'YYYY-MM-DD"T"HH24:MI'), ',' order by starts_at), '')
                      from app.compute_slots('${CLINIC}', '5a000000-0000-0000-0000-0000000000ff', '${from}', '${to}', null, true)`).split(",").filter(Boolean);

  const rules = json(`select weekday, to_char(start_time, 'HH24:MI') as start, to_char(end_time, 'HH24:MI') as "end" from public.availability_rules where clinic_id = '${CLINIC}'`);
  const breaks = json(`select weekday, to_char(start_time, 'HH24:MI') as start, to_char(end_time, 'HH24:MI') as "end" from public.availability_breaks where clinic_id = '${CLINIC}'`);
  const exceptions = json(`select starts_at as "startsAt", ends_at as "endsAt" from public.schedule_exceptions where clinic_id = '${CLINIC}'`);
  const appointments = json(`select id, starts_at as "startsAt", occupied_until as "occupiedUntil", status from public.appointments where clinic_id = '${CLINIC}'`);
  const nowIso = sql(`select now()`);

  const fromJs = D.calcular({
    fromYmd: from, toYmd: to, tz: sc.tz, rules, breaks, exceptions, appointments,
    durationMin: sc.dur, bufferMin: sc.buf, stepMin: sc.step, minNoticeHours: sc.notice, horizonDays: 60,
    enforceWindow: true, now: new Date(nowIso)
  }).map(s => s.startsAt.slice(0, 16));

  const a = new Set(fromDb), b = new Set(fromJs);
  const onlyDb = fromDb.filter(x => !b.has(x)), onlyJs = fromJs.filter(x => !a.has(x));
  if (onlyDb.length === 0 && onlyJs.length === 0 && fromDb.length > 0) {
    pass++; console.log(`PASSOU · ${sc.name}: ${fromDb.length} horários idênticos no navegador e no banco`);
  } else {
    fail++; console.log(`FALHOU · ${sc.name}: banco=${fromDb.length} navegador=${fromJs.length} só no banco=${onlyDb.slice(0, 5)} só no navegador=${onlyJs.slice(0, 5)}`);
  }
  if (sc.splitShift) sql(`delete from public.availability_rules where clinic_id = '${CLINIC}' and start_time = '19:00'`);
}
// Restaura o cenário padrão do teste
sql(`update public.clinics set timezone = 'America/Sao_Paulo' where id = '${CLINIC}'`);
sql(`delete from public.services where id = '5a000000-0000-0000-0000-0000000000ff'`);
console.log(`${pass} de ${pass + fail} cenários iguais`);
process.exit(fail ? 1 : 0);
