/* ==========================================================================
   TESTE RESPONSIVO + ACESSIBILIDADE BÁSICA (modo demonstração, navegador)
   Larguras: 320, 360, 375, 390, 414, 600, 768, 1024, 1280, 1440 e 1920 px.
   Em cada largura, visita o site, as telas de acesso, o portal do cliente e
   o painel (todas as abas e vistas) e confere:
     • nenhuma rolagem lateral (scrollWidth ≤ largura);
     • nenhum erro de JavaScript;
     • menu do celular abre e fecha (site e painel);
     • janela de agendamento do painel e Ateliê de cores cabem na tela;
     • alvos de toque principais com pelo menos 40 px no celular.
   Acessibilidade (uma vez por página, em 1280 px): idioma, um único <h1>,
   <main>, link "pular para o conteúdo", campos com rótulo, botões com nome
   acessível, imagens com alt e foco visível no primeiro link.
   ⚠ Isto NÃO substitui uma auditoria com leitor de tela nem testes de
   segurança: é uma verificação automática de regressão.
   Uso: node tests/60_responsivo_e_acessibilidade.js
   ========================================================================== */
const { chromium } = require("playwright");
const path = require("path");
const BASE = "file://" + path.resolve(__dirname, "..") + "/";
const LARGURAS = [320, 360, 375, 390, 414, 600, 768, 1024, 1280, 1440, 1920];
let falhas = 0, total = 0;
function ok(cond, nome, extra) { total++; if (!cond) falhas++; console.log((cond ? "PASSOU" : "FALHOU") + " · " + nome + (extra ? "  (" + extra + ")" : "")); }

const PUBLICAS = ["index.html", "sobre.html", "clinica.html", "servicos.html", "avaliacoes.html", "contato.html", "privacidade.html", "agendar.html", "demonstracao.html"];
const ACESSO = ["cliente/entrar.html", "cliente/cadastro.html", "cliente/recuperar-senha.html", "cliente/nova-senha.html", "admin/entrar.html", "admin/aceitar-convite.html"];
const PORTAL = ["cliente/index.html", "cliente/meus-dados.html"];
const PAINEL = ["admin/index.html", "admin/agenda.html", "admin/agenda.html?aba=horarios", "admin/agenda.html?aba=bloqueios", "admin/novo-agendamento.html",
  "admin/pacientes.html", "admin/relatorios.html",
  ...["clinica", "servicos", "horarios", "regras", "confirmacao", "cancelamento", "remarcacao", "notificacoes", "cores", "acesso"].map(a => "admin/configuracoes.html?aba=" + a)];

(async () => {
  const browser = await chromium.launch();
  const erros = [];
  const novo = async (w) => {
    const ctx = await browser.newContext({ viewport: { width: w, height: w < 700 ? 800 : 900 }, isMobile: w < 700, hasTouch: w < 700 });
    await ctx.route(/^https?:/, r => r.abort());
    const p = await ctx.newPage();
    p.on("pageerror", e => erros.push(w + "px " + p.url().split("/").slice(-2).join("/") + ": " + e.message));
    return { ctx, p };
  };
  const entrar = async (p, area) => {
    await p.goto(BASE + area + "/entrar.html"); await p.waitForTimeout(500);
    await p.evaluate(() => window.PS.api.sair());
    await p.goto(BASE + area + "/entrar.html"); await p.waitForTimeout(500);
    await p.fill("#email", area === "admin" ? "podologa.demo@exemplo.com" : "cliente.demo@exemplo.com");
    await p.fill("#senha", "demonstracao"); await p.click("[data-enviar]"); await p.waitForTimeout(1100);
  };
  const largura = async (p, u, w) => {
    await p.goto(BASE + u); await p.waitForTimeout(650);
    return p.evaluate(() => document.documentElement.scrollWidth);
  };

  // dados limpos
  { const { ctx, p } = await novo(1280); await p.goto(BASE + "demonstracao.html"); await p.waitForTimeout(600); await p.evaluate(() => window.PS.api.demo.restaurar()); await ctx.close(); }

  for (const w of LARGURAS) {
    const { ctx, p } = await novo(w);
    const largas = [];
    for (const u of PUBLICAS.concat(ACESSO)) { const sw = await largura(p, u, w); if (sw > w + 1) largas.push(u + "=" + sw); }
    // menu do site
    await p.goto(BASE + "index.html"); await p.waitForTimeout(500);
    if (w <= 960) {
      await p.click("[data-menu-toggle]"); await p.waitForTimeout(350);
      const aberto = await p.isVisible("[data-menu] a[href='sobre.html']");
      await p.keyboard.press("Escape"); await p.waitForTimeout(350);
      const fechado = (await p.getAttribute("[data-menu-toggle]", "aria-expanded")) === "false";
      ok(aberto && fechado, w + "px · menu do site abre e fecha (Esc)");
      const alvo = await p.$eval("[data-menu-toggle]", b => Math.min(b.getBoundingClientRect().width, b.getBoundingClientRect().height));
      ok(alvo >= 40, w + "px · botão do menu com alvo de toque ≥ 40px", Math.round(alvo) + "px");
    } else {
      ok(await p.isVisible(".top__nav a[href='sobre.html']"), w + "px · menu do site visível no desktop");
    }
    // Ateliê cabe na tela
    await p.click("[data-atl-open]"); await p.waitForTimeout(250);
    const atl = await p.$eval("[data-atl]", el => { const r = el.getBoundingClientRect(); return { l: r.left, r: r.right, t: r.top, b: r.bottom, vw: innerWidth, vh: innerHeight }; });
    ok(atl.l >= 0 && atl.r <= atl.vw + 0.5 && atl.t >= 0 && atl.b <= atl.vh + 0.5, w + "px · Ateliê de cores cabe na tela", JSON.stringify(atl));

    // portal do cliente
    await entrar(p, "cliente");
    for (const u of PORTAL) { const sw = await largura(p, u, w); if (sw > w + 1) largas.push(u + "=" + sw); }
    // painel
    await entrar(p, "admin");
    for (const u of PAINEL) { const sw = await largura(p, u, w); if (sw > w + 1) largas.push(u + "=" + sw); }
    await p.goto(BASE + "admin/agenda.html"); await p.waitForTimeout(800);
    for (const v of ["semana", "mes", "dia"]) {
      await p.click('[data-vista="' + v + '"]').catch(() => {}); await p.waitForTimeout(450);
      const sw = await p.evaluate(() => document.documentElement.scrollWidth);
      if (sw > w + 1) largas.push("agenda " + v + "=" + sw);
    }
    ok(largas.length === 0, w + "px · sem rolagem lateral em " + (PUBLICAS.length + ACESSO.length + PORTAL.length + PAINEL.length + 3) + " telas", largas.join(", "));

    // janela de detalhes de um agendamento (modal) cabe na tela
    await p.goto(BASE + "admin/index.html"); await p.waitForTimeout(900);
    const item = await p.$("button.ag-item");
    if (item) {
      await item.click(); await p.waitForTimeout(400);
      const dlg = await p.$eval("dialog[open]", d => { const r = d.getBoundingClientRect(); return { l: r.left, r: r.right, vw: innerWidth, h: r.height, vh: innerHeight }; }).catch(() => null);
      ok(dlg && dlg.l >= 0 && dlg.r <= dlg.vw + 0.5 && dlg.h <= dlg.vh + 0.5, w + "px · janela do agendamento cabe na tela", JSON.stringify(dlg));
      await p.keyboard.press("Escape");
    } else ok(false, w + "px · havia agendamento na visão geral para abrir a janela");
    // menu lateral do painel no celular/tablet
    if (w < 1000) {
      await p.click("[data-side-toggle]"); await p.waitForTimeout(300);
      const aberto = await p.isVisible("[data-side] a[href='agenda.html']");
      await p.keyboard.press("Escape"); await p.waitForTimeout(300);
      ok(aberto && (await p.getAttribute("[data-side-toggle]", "aria-expanded")) === "false", w + "px · menu do painel abre e fecha (Esc)");
    }
    await ctx.close();
  }

  /* ---------- Acessibilidade básica (1280 px) ---------- */
  const { ctx, p } = await novo(1280);
  const problemas = [];
  const checar = async (u) => {
    await p.goto(BASE + u); await p.waitForTimeout(800);
    const r = await p.evaluate(() => {
      const out = [];
      if (document.documentElement.lang !== "pt-BR") out.push("lang");
      const h1 = document.querySelectorAll("h1").length; if (h1 !== 1) out.push(h1 + " h1");
      if (!document.querySelector("main")) out.push("sem main");
      if (!document.querySelector("a.skip-link[href='#conteudo']") || !document.getElementById("conteudo")) out.push("sem link pular");
      document.querySelectorAll("input:not([type=hidden]):not([type=radio]):not([type=checkbox]), select, textarea").forEach(i => {
        const temRotulo = (i.id && document.querySelector('label[for="' + i.id + '"]')) || i.closest("label") || i.getAttribute("aria-label") || i.getAttribute("aria-labelledby");
        if (!temRotulo) out.push("campo sem rótulo: " + (i.id || i.name || i.type));
      });
      document.querySelectorAll("button, a[href]").forEach(b => {
        if (b.offsetParent === null) return;
        const nome = (b.getAttribute("aria-label") || b.textContent || b.getAttribute("title") || "").trim();
        if (!nome) out.push("botão/link sem nome: " + b.outerHTML.slice(0, 60));
      });
      document.querySelectorAll("img").forEach(i => { if (!i.hasAttribute("alt")) out.push("img sem alt"); });
      return out;
    });
    if (r.length) problemas.push(u + ": " + r.join("; "));
  };
  for (const u of PUBLICAS.concat(ACESSO)) await checar(u);
  await entrar(p, "cliente"); for (const u of PORTAL) await checar(u);
  await entrar(p, "admin"); for (const u of PAINEL) await checar(u);
  ok(problemas.length === 0, "Acessibilidade básica em " + (PUBLICAS.length + ACESSO.length + PORTAL.length + PAINEL.length) + " páginas (idioma, h1, main, pular conteúdo, rótulos, nomes, alt)", problemas.join(" || "));
  // foco visível
  await p.goto(BASE + "index.html"); await p.waitForTimeout(500);
  await p.keyboard.press("Tab");
  const foco = await p.evaluate(() => { const a = document.activeElement; const s = getComputedStyle(a); return a.className + " " + s.outlineStyle + " " + s.outlineWidth; });
  ok(/skip-link/.test(foco), "Primeiro Tab leva ao link “Pular para o conteúdo”", foco);
  await p.keyboard.press("Tab"); await p.keyboard.press("Tab");
  const foco2 = await p.evaluate(() => { const s = getComputedStyle(document.activeElement); return s.outlineStyle !== "none" && parseFloat(s.outlineWidth) >= 1; });
  ok(foco2, "Foco do teclado visível nos links do cabeçalho");
  await ctx.close();

  ok(erros.length === 0, "Nenhum erro de JavaScript em todas as larguras", erros.slice(0, 5).join(" | "));
  await browser.close();
  console.log("\n" + (total - falhas) + " de " + total + " verificações passaram.");
  process.exit(falhas ? 1 : 0);
})().catch(e => { console.error("ERRO NO TESTE:", e); process.exit(1); });
