/* TESTE: os dados fictícios da demonstração não têm dois atendimentos no mesmo horário */
global.window = globalThis;
const path = require("path");
require(path.join(__dirname, "../sistema/js/tempo.js"));
require(path.join(__dirname, "../sistema/js/disponibilidade.js"));
require(path.join(__dirname, "../sistema/js/dados-demo.js"));
const db = window.PS.demoSeed.criar({ podologa: "x", cliente: "y" });
const ativos = db.appointments.filter(a => a.status !== "cancelled").sort((a, b) => a.startsAt < b.startsAt ? -1 : 1);
let conflitos = 0;
for (let i = 1; i < ativos.length; i++) if (ativos[i].startsAt < ativos[i - 1].occupiedUntil) conflitos++;
console.log((conflitos ? "FALHOU" : "PASSOU") + " · " + ativos.length + " atendimentos fictícios não cancelados, " + conflitos + " sobreposições");
const semDomingo = db.appointments.every(a => window.PS.tempo.partsIn(new Date(a.startsAt), db.clinic.timezone).weekday !== 0);
console.log((semDomingo ? "PASSOU" : "FALHOU") + " · nenhum atendimento fictício em dia sem expediente (domingo)");
process.exit(conflitos || !semDomingo ? 1 : 0);
