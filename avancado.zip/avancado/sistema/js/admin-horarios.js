/* ==========================================================================
   PAINEL · EDITOR DE HORÁRIOS (vários turnos e pausas por dia)
   Usado em Agenda › Horários e em Configurações › Horários.
   Regras (iguais às do banco, função admin_save_schedule da migração 004):
     • até 6 turnos e 6 pausas por dia; fim sempre depois do início;
     • turnos do mesmo dia não se sobrepõem; pausas também não;
     • cada pausa precisa caber inteira dentro de um turno do mesmo dia.
   A tela confere antes de enviar, mas quem decide é o servidor: a gravação
   é atômica (ou grava tudo, ou nada).
   ========================================================================== */
(function () {
  "use strict";
  var PS = window.PS, S = PS.sys, T = PS.tempo;
  PS.admin = PS.admin || {};

  function linhaTurno(t) {
    return '<div class="shift" data-turno><label><span class="sr-only">Início do turno</span><input class="input" type="time" step="300" data-ini value="' + S.esc(t.start || "") + '" required></label>' +
      '<span aria-hidden="true">–</span><label><span class="sr-only">Fim do turno</span><input class="input" type="time" step="300" data-fim value="' + S.esc(t.end || "") + '" required></label>' +
      '<button type="button" class="btn btn--ghost btn--xs" data-remover aria-label="Remover turno"><svg class="icon" aria-hidden="true"><use href="#i-trash"/></svg></button></div>';
  }
  function linhaPausa(p) {
    return '<div class="shift shift--pausa" data-pausa><label><span class="sr-only">Nome da pausa</span><input class="input" type="text" maxlength="60" data-rotulo placeholder="Ex.: Almoço" value="' + S.esc(p.label || "") + '"></label>' +
      '<label><span class="sr-only">Início da pausa</span><input class="input" type="time" step="300" data-ini value="' + S.esc(p.start || "") + '" required></label>' +
      '<span aria-hidden="true">–</span><label><span class="sr-only">Fim da pausa</span><input class="input" type="time" step="300" data-fim value="' + S.esc(p.end || "") + '" required></label>' +
      '<button type="button" class="btn btn--ghost btn--xs" data-remover aria-label="Remover pausa"><svg class="icon" aria-hidden="true"><use href="#i-trash"/></svg></button></div>';
  }
  function dia(wd, turnos, pausas) {
    var on = turnos.length > 0;
    return '<fieldset class="dayed' + (on ? "" : " is-off") + '" data-wd="' + wd + '"><legend class="sr-only">' + T.WEEKDAYS[wd] + "</legend>" +
      '<div class="dayed__head"><label class="check"><input type="checkbox" data-atende' + (on ? " checked" : "") + '><span><strong>' + T.WEEKDAYS[wd] + "</strong></span></label>" +
        '<span class="small muted" data-resumo></span>' +
        '<button type="button" class="btn btn--ghost btn--xs" data-copiar title="Copiar este dia para todos os outros dias marcados"><svg class="icon" aria-hidden="true"><use href="#i-copy"/></svg>Copiar para os dias marcados</button></div>' +
      '<div class="dayed__body">' +
        '<div class="dayed__col"><p class="dayed__t">Turnos</p><div data-turnos>' + turnos.map(linhaTurno).join("") + "</div>" +
          '<button type="button" class="btn btn--ghost btn--xs" data-add-turno><svg class="icon" aria-hidden="true"><use href="#i-plus"/></svg>Adicionar turno</button></div>' +
        '<div class="dayed__col"><p class="dayed__t">Pausas <span class="muted">(opcional)</span></p><div data-pausas>' + pausas.map(linhaPausa).join("") + "</div>" +
          '<button type="button" class="btn btn--ghost btn--xs" data-add-pausa><svg class="icon" aria-hidden="true"><use href="#i-plus"/></svg>Adicionar pausa</button></div>' +
      "</div></fieldset>";
  }
  function num(id, label, val, min, max, hint) {
    return '<div class="field"><label class="field__label" for="' + id + '">' + label + '</label><input class="input" type="number" inputmode="numeric" id="' + id + '" min="' + min + '" max="' + max + '" value="' + S.esc(val) + '" required>' +
      (hint ? '<p class="field__hint">' + hint + "</p>" : "") + "</div>";
  }

  /* Validação local (espelho do banco). Devolve mensagem ou null. */
  function validar(regras, pausas) {
    function sobrepoe(l) { for (var i = 0; i < l.length; i++) for (var j = i + 1; j < l.length; j++) if (l[i].start < l[j].end && l[j].start < l[i].end) return true; return false; }
    for (var wd = 0; wd < 7; wd++) {
      var r = regras.filter(function (x) { return x.weekday === wd; }), p = pausas.filter(function (x) { return x.weekday === wd; });
      var nome = T.WEEKDAYS[wd];
      if (r.length > 6 || p.length > 6) return nome + ": no máximo 6 turnos e 6 pausas por dia.";
      if (r.concat(p).some(function (x) { return !x.start || !x.end || x.end <= x.start; })) return nome + ": cada horário precisa terminar depois de começar.";
      if (sobrepoe(r)) return nome + ": dois turnos estão se sobrepondo.";
      if (sobrepoe(p)) return nome + ": duas pausas estão se sobrepondo.";
      if (p.some(function (b) { return !r.some(function (t) { return b.start >= t.start && b.end <= t.end; }); })) return nome + ": cada pausa precisa ficar dentro de um turno.";
    }
    return null;
  }
  PS.admin.validarHorarios = validar;

  PS.admin.editorHorarios = function (alvo, opts) {
    var h = opts.horarios, sets = opts.clinica.settings, tz = opts.clinica.timezone;
    var html = "";
    for (var wd = 0; wd < 7; wd++) {
      var ord = function (a, b) { return a.start < b.start ? -1 : 1; };
      html += dia(wd, h.rules.filter(function (x) { return +x.weekday === wd; }).sort(ord), h.breaks.filter(function (x) { return +x.weekday === wd; }).sort(ord));
    }
    alvo.innerHTML =
      '<form class="stack" data-form-horarios novalidate>' +
        '<section class="panel"><div class="panel__head"><h2>Dias, turnos e pausas</h2></div>' +
          '<p class="muted small" style="margin-bottom:1rem">Cada dia pode ter vários turnos (ex.: 8h–12h e 14h–19h) e várias pausas dentro deles. Horários no fuso da clínica: ' + S.esc(tz) + ".</p>" +
          '<div class="week-editor">' + html + "</div></section>" +
        '<section class="panel"><h2 style="margin-bottom:1rem">Como os horários são oferecidos</h2><div class="form-grid">' +
          num("slotStepMinutes", "Grade de horários (minutos)", sets.slotStepMinutes, 5, 120, "De quanto em quanto tempo os horários começam. Ex.: 30 → 9h00, 9h30…") +
          num("bufferMinutes", "Intervalo entre consultas (minutos)", sets.bufferMinutes, 0, 120, "Tempo livre depois de cada atendimento, para higienizar a sala.") +
          num("bookingMinNoticeHours", "Antecedência mínima (horas)", sets.bookingMinNoticeHours, 0, 720, "O cliente não vê horários mais próximos que isso.") +
          num("bookingHorizonDays", "Agendamento disponível até (dias à frente)", sets.bookingHorizonDays, 1, 365, "") +
        '</div><p class="small muted" style="margin-top:1rem">A duração de cada atendimento é definida por serviço, em <a href="configuracoes.html?aba=servicos">Configurações › Serviços</a>. Feriados, férias e folgas ficam em <a href="agenda.html?aba=bloqueios">Agenda › Bloqueios</a>.</p></section>' +
        '<p class="alert" data-msg hidden role="alert"></p>' +
        '<div class="form-actions form-actions--sticky"><button class="btn btn--primary" type="submit" data-salvar>Salvar horários</button><span class="small muted">Agendamentos já marcados não são alterados.</span></div>' +
      "</form>";

    function resumo(fs) {
      var t = S.$all("[data-turno]", fs).map(function (r) { return S.$("[data-ini]", r).value + "–" + S.$("[data-fim]", r).value; });
      S.$("[data-resumo]", fs).textContent = S.$("[data-atende]", fs).checked ? (t.length ? t.join(" · ") : "sem turnos") : "fechado";
    }
    S.$all(".dayed", alvo).forEach(resumo);

    alvo.addEventListener("click", function (e) {
      var fs = e.target.closest(".dayed"); if (!fs) return;
      if (e.target.closest("[data-add-turno]")) {
        var ult = S.$all("[data-turno]", fs).pop();
        var ini = ult ? S.$("[data-fim]", ult).value || "13:00" : "09:00";
        var hIni = parseInt(ini.slice(0, 2), 10) + (ult ? 1 : 0);
        var novoIni = (hIni > 22 ? 22 : hIni).toString().padStart(2, "0") + ":00";
        var novoFim = Math.min(hIni + 4, 23).toString().padStart(2, "0") + ":00";
        S.$("[data-turnos]", fs).insertAdjacentHTML("beforeend", linhaTurno({ start: novoIni, end: novoFim }));
        S.$("[data-atende]", fs).checked = true; fs.classList.remove("is-off");
        S.$all("[data-turno]", fs).pop().querySelector("input").focus();
      } else if (e.target.closest("[data-add-pausa]")) {
        S.$("[data-pausas]", fs).insertAdjacentHTML("beforeend", linhaPausa({ label: "", start: "12:00", end: "13:00" }));
        S.$all("[data-pausa]", fs).pop().querySelector("input").focus();
      } else if (e.target.closest("[data-remover]")) {
        var linha = e.target.closest("[data-turno],[data-pausa]");
        var prox = linha.nextElementSibling || linha.previousElementSibling;
        linha.remove();
        (prox ? prox.querySelector("input") : S.$("[data-add-turno]", fs)).focus();
      } else if (e.target.closest("[data-copiar]")) {
        // copia lendo os valores digitados (innerHTML não leva o que foi editado)
        var tv = S.$all("[data-turno]", fs).map(function (r) { return { start: S.$("[data-ini]", r).value, end: S.$("[data-fim]", r).value }; });
        var pv = S.$all("[data-pausa]", fs).map(function (r) { return { label: S.$("[data-rotulo]", r).value, start: S.$("[data-ini]", r).value, end: S.$("[data-fim]", r).value }; });
        var n = 0;
        S.$all(".dayed", alvo).forEach(function (o) {
          if (o === fs || !S.$("[data-atende]", o).checked) return;
          S.$("[data-turnos]", o).innerHTML = tv.map(linhaTurno).join("");
          S.$("[data-pausas]", o).innerHTML = pv.map(linhaPausa).join("");
          resumo(o); n++;
        });
        S.toast(n ? "Copiado para " + n + " dia(s). Revise e salve." : "Marque os outros dias de atendimento antes de copiar.");
      }
      resumo(fs);
    });
    alvo.addEventListener("change", function (e) {
      var fs = e.target.closest(".dayed"); if (!fs) return;
      if (e.target.matches("[data-atende]")) {
        fs.classList.toggle("is-off", !e.target.checked);
        if (e.target.checked && !S.$("[data-turno]", fs)) S.$("[data-turnos]", fs).innerHTML = linhaTurno({ start: "09:00", end: "18:00" });
      }
      resumo(fs);
    });

    S.$("[data-form-horarios]", alvo).addEventListener("submit", function (e) {
      e.preventDefault();
      var msg = S.$("[data-msg]", alvo), regras = [], pausas = [];
      S.$all(".dayed", alvo).forEach(function (fs) {
        if (!S.$("[data-atende]", fs).checked) return;
        var wd = +fs.getAttribute("data-wd");
        S.$all("[data-turno]", fs).forEach(function (r) { regras.push({ weekday: wd, start: S.$("[data-ini]", r).value, end: S.$("[data-fim]", r).value }); });
        S.$all("[data-pausa]", fs).forEach(function (r) { pausas.push({ weekday: wd, start: S.$("[data-ini]", r).value, end: S.$("[data-fim]", r).value, label: S.$("[data-rotulo]", r).value.trim() || null }); });
      });
      if (!regras.length) return S.alerta(msg, "Marque pelo menos um dia com um turno de atendimento.");
      var erro = validar(regras, pausas);
      if (erro) return S.alerta(msg, erro);
      var conf = {};
      ["slotStepMinutes", "bufferMinutes", "bookingMinNoticeHours", "bookingHorizonDays"].forEach(function (k) { conf[k] = S.$("#" + k, alvo).value; });
      var btn = S.$("[data-salvar]", alvo);
      S.ocupado(btn, true, "Salvando…"); S.alerta(msg, null);
      PS.api.salvarHorarios(regras, pausas).then(function () { return PS.api.salvarRegras(conf); })
        .then(function () { return Promise.all([PS.api.horariosDeAtendimento(), PS.api.clinica()]); })
        .then(function (r) {
          S.ocupado(btn, false);
          S.alerta(msg, "Horários salvos: " + regras.length + " turno(s) e " + pausas.length + " pausa(s). A nova disponibilidade já vale para o site e para o agendamento manual.", "ok");
          if (opts.aoSalvar) opts.aoSalvar(r[0], r[1]);
        })
        .catch(function (err) { S.ocupado(btn, false); S.alerta(msg, S.mensagem(err)); });
    });
  };
})();
