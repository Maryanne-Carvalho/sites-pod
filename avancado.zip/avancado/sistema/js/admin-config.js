/* ==========================================================================
   PAINEL · CONFIGURAÇÕES DA CLÍNICA
   Clínica · Serviços · Horários · Regras · Confirmação · Cancelamento ·
   Remarcação · Notificações · Identidade visual · Acesso administrativo
   Tudo pertence à clínica da administradora conectada (no modo real, o banco
   só aceita alterações da própria clínica).
   ========================================================================== */
(function () {
  "use strict";
  var PS = window.PS, S = PS.sys, T = PS.tempo;
  var params = new URLSearchParams(location.search);
  var aba = params.get("aba") || "clinica";
  var clinica, alvo = S.$("[data-aba-conteudo]");

  PS.admin.iniciar().then(function (ctx) { clinica = ctx.clinica; abas(); })
    .catch(function (e) { alvo.innerHTML = '<div class="alert alert--error">' + S.esc(S.mensagem(e)) + "</div>"; });

  function abas() {
    S.$all("[data-aba]").forEach(function (b) {
      b.setAttribute("aria-selected", b.getAttribute("data-aba") === aba ? "true" : "false");
      b.setAttribute("tabindex", b.getAttribute("data-aba") === aba ? "0" : "-1");
      b.onclick = function () { aba = b.getAttribute("data-aba"); history.replaceState(null, "", "?aba=" + aba); abas(); };
    });
    ({ clinica: telaClinica, servicos: telaServicos, horarios: telaHorarios, regras: telaRegras, confirmacao: telaConfirmacao,
       cancelamento: telaCancelamento, remarcacao: telaRemarcacao, notificacoes: telaNotificacoes, cores: telaCores, acesso: telaAcesso }[aba] || telaClinica)();
  }
  function recarregarClinica() { return PS.api.clinica().then(function (c) { clinica = c; PS.admin.ctx.clinica = c; }); }
  function campo(id, label, val, tipo, extra, hint) {
    return '<div class="field"><label class="field__label" for="' + id + '">' + label + '</label><input class="input" id="' + id + '" type="' + (tipo || "text") + '" value="' + S.esc(val == null ? "" : val) + '" ' + (extra || "") + ">" +
      (hint ? '<p class="field__hint">' + hint + "</p>" : "") + '<p class="field__error" hidden></p></div>';
  }
  function salvarCom(form, fn, okMsg) {
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      var btn = S.$("[type=submit]", form), msg = S.$("[data-msg]", form);
      S.ocupado(btn, true, "Salvando…"); S.alerta(msg, null);
      Promise.resolve().then(fn).then(recarregarClinica).then(function () { S.ocupado(btn, false); S.alerta(msg, okMsg || "Alterações salvas.", "ok"); })
        .catch(function (err) { S.ocupado(btn, false); S.alerta(msg, S.mensagem(err)); });
    });
  }

  /* ---------------- Clínica ---------------- */
  function telaClinica() {
    var c = clinica;
    alvo.innerHTML = '<form class="panel form" data-f novalidate><h2>Dados da clínica</h2>' +
      (PS.api.modo === "demo" ? '<p class="small muted">Demonstração: dados fictícios.</p>' : "") +
      '<div class="form-grid">' +
        campo("c-nome", "Nome da clínica", c.name, "text", 'maxlength="120" required') +
        campo("c-prof", "Nome da profissional", c.professionalName, "text", 'maxlength="120"') +
        campo("c-tel", "Telefone", c.phone ? S.telefone(c.phone) : "", "tel", 'inputmode="tel"', "Com DDD.") +
        campo("c-wa", "WhatsApp", c.whatsapp || "", "tel", 'inputmode="tel"', "55 + DDD + número, só dígitos. Ex.: 5511900000000") +
        campo("c-email", "E-mail de contato", c.email, "email") +
        '<div class="field"><span class="field__label">Fuso horário</span><p>' + S.esc(c.timezone) + '</p><p class="field__hint">Definido na configuração inicial (supabase/setup-clinica-e-admin.sql).</p></div>' +
        '<div class="span-2">' + campo("c-end1", "Endereço", c.addressLine1, "text", 'maxlength="160"') + "</div>" +
        '<div class="span-2">' + campo("c-end2", "Bairro, cidade e estado", c.addressLine2, "text", 'maxlength="160"') + "</div>" +
      '</div><p class="alert" data-msg hidden></p><div class="form-actions"><button class="btn btn--primary" type="submit">Salvar dados da clínica</button></div></form>';
    salvarCom(S.$("[data-f]", alvo), function () {
      return PS.api.salvarClinica({ name: S.$("#c-nome").value, professionalName: S.$("#c-prof").value, phone: S.$("#c-tel").value, whatsapp: S.$("#c-wa").value,
        email: S.$("#c-email").value.trim(), addressLine1: S.$("#c-end1").value, addressLine2: S.$("#c-end2").value });
    }, "Dados da clínica salvos.");
  }

  /* ---------------- Serviços ---------------- */
  function telaServicos() {
    alvo.innerHTML = '<section class="panel"><div class="panel__head"><h2>Serviços oferecidos</h2><button type="button" class="btn btn--primary btn--sm" data-novo><svg class="icon" aria-hidden="true"><use href="#i-plus"/></svg>Novo serviço</button></div>' +
      '<p class="small muted" style="margin-bottom:1rem">A duração define quanto tempo cada atendimento ocupa na agenda. Serviços desativados somem do agendamento on-line, mas o histórico continua.</p>' +
      '<div data-lista><p class="loading"><span class="spinner"></span>Carregando…</p></div></section>';
    function listar() {
      PS.api.servicos(true).then(function (l) {
        S.$("[data-lista]", alvo).innerHTML = '<table class="table table--cards"><thead><tr><th>Serviço</th><th class="num">Duração</th><th class="num">Preço</th><th>Situação</th><th><span class="sr-only">Ações</span></th></tr></thead><tbody>' +
          l.map(function (s) {
            return '<tr><td data-th="Serviço"><strong>' + S.esc(s.name) + '</strong></td><td data-th="Duração" class="num">' + s.durationMinutes + ' min</td><td data-th="Preço" class="num">' + S.reais(s.priceCents) +
              "</td><td>" + (s.isActive ? '<span class="st st--confirmed">Ativo</span>' : '<span class="st st--cancelled">Desativado</span>') + '</td><td><button type="button" class="btn btn--ghost btn--xs" data-editar="' + S.esc(s.id) + '">Editar</button></td></tr>';
          }).join("") + "</tbody></table>";
        alvo._l = l;
      }).catch(function (e) { S.$("[data-lista]", alvo).innerHTML = '<div class="alert alert--error">' + S.esc(S.mensagem(e)) + "</div>"; });
    }
    listar();
    alvo.onclick = function (e) {
      var ed = e.target.closest("[data-editar]");
      if (ed) return editar((alvo._l || []).filter(function (s) { return s.id === ed.getAttribute("data-editar"); })[0]);
      if (e.target.closest("[data-novo]")) editar(null);
    };
    function editar(s) {
      s = s || { name: "", durationMinutes: 50, priceCents: null, isActive: true, description: "" };
      var d = S.janela(s.id ? "Editar serviço" : "Novo serviço", '<form class="form" data-f novalidate>' +
        campo("s-nome", "Nome", s.name, "text", 'maxlength="80"') +
        '<div class="form-grid">' + campo("s-dur", "Duração (minutos)", s.durationMinutes, "number", 'min="10" max="480" step="5"') +
        campo("s-preco", "Preço (R$, opcional)", s.priceCents != null ? (s.priceCents / 100).toFixed(2).replace(".", ",") : "", "text", 'inputmode="decimal" placeholder="Ex.: 150,00"', "Deixe vazio para não exibir.") + "</div>" +
        '<div class="field"><label class="field__label" for="s-desc">Descrição curta</label><textarea class="input" id="s-desc" rows="2" maxlength="600">' + S.esc(s.description || "") + "</textarea></div>" +
        '<label class="check"><input type="checkbox" id="s-ativo"' + (s.isActive ? " checked" : "") + "><span>Disponível para agendamento</span></label>" +
        '<p class="alert" data-erro hidden></p><div class="sys-dialog__actions"><button class="btn btn--primary" type="submit">Salvar serviço</button></div></form>');
      S.$("[data-f]", d).addEventListener("submit", function (e) {
        e.preventDefault();
        var preco = S.$("#s-preco", d).value.trim().replace(/\./g, "").replace(",", ".");
        var centavos = preco === "" ? null : Math.round(parseFloat(preco) * 100);
        if (preco !== "" && (isNaN(centavos) || centavos < 0)) return S.alerta(S.$("[data-erro]", d), "Preço inválido. Use o formato 150,00.");
        PS.api.salvarServico({ id: s.id, name: S.$("#s-nome", d).value, durationMinutes: S.$("#s-dur", d).value, priceCents: centavos, isActive: S.$("#s-ativo", d).checked, description: S.$("#s-desc", d).value.trim() })
          .then(function () { d.close(); S.toast("Serviço salvo."); listar(); })
          .catch(function (err) { S.alerta(S.$("[data-erro]", d), S.mensagem(err)); });
      });
    }
  }

  function radio(nome, valor, rotulo, atual, desc) {
    return '<label class="check check--card"><input type="radio" name="' + nome + '" value="' + valor + '"' + (atual === valor ? " checked" : "") + "><span><strong>" + rotulo + "</strong>" + (desc ? '<small class="muted">' + desc + "</small>" : "") + "</span></label>";
  }
  function val(f, n) { var x = S.$('input[name="' + n + '"]:checked', f); return x && x.value; }
  function formSimples(titulo, corpo, botao) {
    return '<form class="panel form" data-f novalidate><h2>' + titulo + "</h2>" + corpo +
      '<p class="alert" data-msg hidden role="status"></p><div class="form-actions"><button class="btn btn--primary" type="submit">' + botao + "</button></div></form>";
  }

  /* ---------------- Horários ---------------- */
  function telaHorarios() {
    alvo.innerHTML = '<p class="loading"><span class="spinner"></span>Carregando horários…</p>';
    PS.api.horariosDeAtendimento().then(function (h) {
      PS.admin.editorHorarios(alvo, { horarios: h, clinica: clinica, aoSalvar: function (h2, c) { clinica = c; PS.admin.ctx.clinica = c; } });
    }).catch(function (e) { PS.admin.erroComTentativa(alvo, e, telaHorarios); });
  }

  /* ---------------- Regras gerais ---------------- */
  function telaRegras() {
    var s = clinica.settings;
    alvo.innerHTML = formSimples("Regras gerais do agendamento on-line",
      '<div class="form-grid">' + campo("r-max", "Máximo de agendamentos futuros por cliente", s.maxActiveBookingsPerClient, "number", 'min="1" max="20"', "Evita que uma pessoa reserve muitos horários.") + "</div>" +
      '<div class="field"><label class="field__label" for="r-texto">Texto da política (aparece no resumo do agendamento)</label><textarea class="input" id="r-texto" rows="4" maxlength="1000">' + S.esc(s.policyText || "") + '</textarea><p class="field__hint">Até 1.000 caracteres. Não inclua dados de pacientes.</p></div>' +
      '<p class="small muted">Grade, intervalo entre consultas, antecedência mínima e limite de dias ficam em <button type="button" class="linklike" data-ir="horarios">Horários</button>.</p>',
      "Salvar regras");
    S.$("[data-ir]", alvo).onclick = function () { aba = "horarios"; history.replaceState(null, "", "?aba=horarios"); abas(); };
    salvarCom(S.$("[data-f]", alvo), function () {
      return PS.api.salvarRegras({ maxActiveBookingsPerClient: S.$("#r-max").value, policyText: S.$("#r-texto").value });
    }, "Regras salvas. Valem para os próximos pedidos.");
  }

  /* ---------------- Confirmação ---------------- */
  function telaConfirmacao() {
    var s = clinica.settings;
    alvo.innerHTML = formSimples("Confirmação dos agendamentos on-line",
      '<fieldset class="field fieldset"><legend class="field__label">Quando o cliente agenda pelo site</legend>' +
        radio("modo", "auto", "Confirmar na hora", s.onlineBookingMode, "O horário fica confirmado assim que o cliente conclui.") +
        radio("modo", "approval", "Aguardar minha aprovação", s.onlineBookingMode, "O horário fica reservado como “Aguardando confirmação” e aparece na Visão geral para você confirmar ou recusar.") + "</fieldset>" +
      '<p class="small muted">Em ambos os casos o horário é reservado no banco no momento do pedido, então ninguém mais consegue marcá-lo.</p>',
      "Salvar confirmação");
    var f = S.$("[data-f]", alvo);
    salvarCom(f, function () { return PS.api.salvarRegras({ onlineBookingMode: val(f, "modo") }); }, "Regra de confirmação salva.");
  }

  /* ---------------- Cancelamento ---------------- */
  function telaCancelamento() {
    var s = clinica.settings;
    alvo.innerHTML = formSimples("Cancelamento pelo cliente",
      '<div class="form-grid">' + campo("r-canc", "Cancelar pelo site até (horas antes)", s.cancelMinHours, "number", 'min="0" max="720"', "Depois desse prazo, o cliente precisa falar com a clínica.") + "</div>" +
      '<fieldset class="field fieldset"><legend class="field__label">Como funciona</legend>' +
        radio("canc", "direct", "O cliente cancela direto", s.clientCancelMode, "O horário é liberado na hora.") +
        radio("canc", "approval", "Precisa da minha aprovação", s.clientCancelMode, "Vira um pedido; o horário só é liberado quando você aprovar.") + "</fieldset>",
      "Salvar cancelamento");
    var f = S.$("[data-f]", alvo);
    salvarCom(f, function () { return PS.api.salvarRegras({ cancelMinHours: S.$("#r-canc").value, clientCancelMode: val(f, "canc") }); }, "Regra de cancelamento salva.");
  }

  /* ---------------- Remarcação ---------------- */
  function telaRemarcacao() {
    var s = clinica.settings;
    alvo.innerHTML = formSimples("Remarcação pelo cliente",
      '<div class="form-grid">' + campo("r-reag", "Remarcar pelo site até (horas antes)", s.rescheduleMinHours, "number", 'min="0" max="720"') + "</div>" +
      '<fieldset class="field fieldset"><legend class="field__label">Como funciona</legend>' +
        radio("reag", "direct", "O cliente troca direto para outro horário livre", s.clientRescheduleMode, "O banco confere se o novo horário está livre no momento da troca.") +
        radio("reag", "approval", "Precisa da minha aprovação", s.clientRescheduleMode, "Vira um pedido; o horário atual continua reservado até a sua resposta.") + "</fieldset>",
      "Salvar remarcação");
    var f = S.$("[data-f]", alvo);
    salvarCom(f, function () { return PS.api.salvarRegras({ rescheduleMinHours: S.$("#r-reag").value, clientRescheduleMode: val(f, "reag") }); }, "Regra de remarcação salva.");
  }

  /* ---------------- Notificações (preferências + fila real) ---------------- */
  var TIPO = { new_booking: "Novo agendamento on-line", cancellation: "Cancelamento do cliente", request: "Pedido do cliente" };
  var SIT = { pending: ["Na fila", "st--pending"], sent: ["Enviado", "st--confirmed"], failed: ["Falhou", "st--cancelled"], skipped: ["Ignorado", "st--cancelled"] };
  function telaNotificacoes() {
    alvo.innerHTML = '<p class="loading"><span class="spinner"></span>Carregando…</p>';
    Promise.all([PS.api.notificacoes(), PS.api.filaDeAvisos().catch(function (e) { return { erro: e }; })]).then(function (r) {
      var n = r[0], fila = r[1];
      var demo = PS.api.modo === "demo";
      alvo.innerHTML = '<div class="stack">' + formSimples("Preferências de aviso por e-mail",
        campo("n-email", "E-mail que recebe os avisos da clínica", n.notifyEmail, "email", 'maxlength="254"', "Sem e-mail, nenhum aviso é gerado.") +
        '<label class="check"><input type="checkbox" id="n-novo"' + (n.notifyOnNewBooking ? " checked" : "") + "><span>Novo agendamento feito pelo site</span></label>" +
        '<label class="check"><input type="checkbox" id="n-canc"' + (n.notifyOnCancellation ? " checked" : "") + "><span>Cancelamento feito pelo cliente</span></label>" +
        '<p class="small muted">Pedidos de cancelamento ou remarcação geram aviso sempre que houver e-mail configurado.</p>' +
        '<label class="check check--disabled"><input type="checkbox" id="n-resumo"' + (n.notifyDailySummary ? " checked" : "") + '><span>Resumo diário da agenda <span class="tag">não incluído nesta versão</span></span></label>',
        "Salvar preferências") +
        '<section class="panel"><div class="panel__head"><h2>Situação dos avisos</h2><button type="button" class="btn btn--ghost btn--xs" data-atualizar><svg class="icon" aria-hidden="true"><use href="#i-refresh"/></svg>Atualizar</button></div>' +
        (demo ? '<div class="alert alert--info"><strong>Demonstração:</strong> nenhum e-mail é enviado. Os avisos abaixo mostram apenas o que <em>entraria na fila</em> no modo real.</div>'
              : '<div class="alert alert--info">Os avisos entram nesta fila automaticamente pelo banco. O <strong>envio</strong> depende da função “enviar-avisos” publicada no Supabase com um provedor de e-mail (ver docs/NOTIFICACOES.md). Enquanto ela não estiver ativa, os avisos ficam “Na fila” — nada é marcado como enviado sem ter sido.</div>') +
        (fila.erro ? '<div class="alert alert--error">' + S.esc(S.mensagem(fila.erro)) + "</div>" :
          fila.length ? '<table class="table table--cards"><thead><tr><th>Quando</th><th>Tipo</th><th>Situação</th><th class="num">Tentativas</th></tr></thead><tbody>' +
            fila.map(function (o) {
              var sit = SIT[o.status] || [o.status, ""];
              return '<tr><td data-th="Quando">' + S.esc(T.format.date(o.createdAt, clinica.timezone) + " " + T.format.time(o.createdAt, clinica.timezone)) + '</td><td data-th="Tipo">' + S.esc(TIPO[o.kind] || o.kind) +
                '</td><td data-th="Situação"><span class="st ' + sit[1] + '">' + sit[0] + "</span>" + (o.lastError ? '<br><span class="small muted">' + S.esc(o.lastError) + "</span>" : "") + '</td><td data-th="Tentativas" class="num">' + (o.attempts || 0) + "</td></tr>";
            }).join("") + "</tbody></table>"
          : '<div class="empty">Nenhum aviso gerado ainda.</div>') +
        "</section>" +
        '<section class="panel"><h2>Não incluídos nesta versão</h2><ul class="list-plain small muted"><li>Lembretes por WhatsApp ou SMS.</li><li>Pagamentos on-line.</li><li>Resumo diário automático.</li></ul></section></div>';
      S.$("[data-atualizar]", alvo).onclick = telaNotificacoes;
      salvarCom(S.$("[data-f]", alvo), function () {
        return PS.api.salvarNotificacoes({ notifyEmail: S.$("#n-email").value.trim(), notifyOnNewBooking: S.$("#n-novo").checked, notifyOnCancellation: S.$("#n-canc").checked, notifyDailySummary: S.$("#n-resumo").checked });
      }, "Preferências salvas.");
    }).catch(function (e) { PS.admin.erroComTentativa(alvo, e, telaNotificacoes); });
  }

  /* ---------------- Identidade visual (por clínica) ----------------
     O painel NÃO muda de cor: a prévia é um "mini site" ao lado, calculado
     pelo mesmo motor de temas do site público. */
  function telaCores() {
    var salvo = clinica.settings.branding || { paletteId: PS.config.defaultPalette, overrides: {} };
    var est = { paletteId: PS.theme.getPalette(salvo.paletteId).id, overrides: Object.assign({}, salvo.overrides || {}) };
    var NOMES = { primary: "Principal", deep: "Profunda", accent: "Destaque", background: "Fundo", text: "Texto" };
    alvo.innerHTML = '<section class="panel brand-editor"><div class="panel__head"><h2>Identidade visual da clínica</h2></div>' +
      '<p class="muted small">Vale para o site público, o agendamento e a Área do cliente' + (PS.api.modo === "demo" ? " (na demonstração, salva neste navegador)" : " de todos os visitantes") + ". O painel administrativo mantém a identidade própria.</p>" +
      '<div class="brand-editor__grid"><div>' +
        '<p class="field__label" id="pal-l">Paletas</p><div class="pal-grid" role="radiogroup" aria-labelledby="pal-l">' + PS.palettes.map(function (p) {
          return '<button type="button" class="pal-opt" role="radio" aria-checked="false" data-pal="' + p.id + '"><span class="pal-opt__sw" aria-hidden="true">' +
            ["primary", "deep", "accent", "background", "text"].map(function (k) { return '<i style="background:' + p.colors[k] + '"></i>'; }).join("") +
            '</span><span class="pal-opt__n">' + S.esc(p.name) + '</span><span class="pal-opt__m">' + S.esc(p.mood) + "</span></button>";
        }).join("") + "</div>" +
        '<p class="field__label" style="margin-top:1.25rem">Cores manuais</p><div class="hex-list">' + PS.theme.editable.map(function (k) {
          return '<div class="hex-row" data-k="' + k + '"><input type="color" data-cor="' + k + '" aria-label="Cor ' + NOMES[k] + '"><label for="hx-' + k + '">' + NOMES[k] + '</label>' +
            '<input class="input" id="hx-' + k + '" data-hex="' + k + '" maxlength="7" spellcheck="false" autocomplete="off">' +
            '<button type="button" class="btn btn--ghost btn--xs" data-reset="' + k + '" aria-label="Voltar ' + NOMES[k] + ' ao padrão da paleta"><svg class="icon" aria-hidden="true"><use href="#i-reset"/></svg></button></div>';
        }).join("") + "</div></div>" +
        '<div><p class="field__label">Prévia</p><div class="brand-preview" data-prev aria-hidden="true">' +
          '<div class="bp-top"><span class="bp-mark">' + S.esc(PS.content.brand.monogram) + '</span><span class="bp-name">' + S.esc(PS.content.brand.short) + '</span><span class="bp-btn">Agendar</span></div>' +
          '<div class="bp-hero"><span class="bp-kicker">Podologia</span><span class="bp-title">Cuidado técnico <em>e humano.</em></span><span class="bp-text">Texto de exemplo para conferir a legibilidade.</span><span class="bp-link">Ver serviços</span></div>' +
          '<div class="bp-deep"><span class="bp-dt">Seção profunda</span><span class="bp-acc">destaque</span></div></div>' +
          '<div data-checks aria-live="polite"></div></div>' +
      "</div>" +
      '<p class="alert" data-msg hidden role="status"></p>' +
      '<div class="form-actions"><button type="button" class="btn btn--primary" data-salvar>Salvar identidade da clínica</button>' +
        '<button type="button" class="btn btn--outline" data-voltar-salvo>Desfazer alterações</button>' +
        '<button type="button" class="btn btn--outline" data-original>Restaurar Ameixa & Champagne</button></div></section>';

    var prev = S.$("[data-prev]", alvo);
    function render() {
      var pal = PS.theme.getPalette(est.paletteId), r = PS.theme.compute(pal, est.overrides);
      Object.keys(r.tokens).forEach(function (t) { prev.style.setProperty(t, r.tokens[t]); });
      S.$all("[data-pal]", alvo).forEach(function (b) { b.setAttribute("aria-checked", b.getAttribute("data-pal") === pal.id ? "true" : "false"); b.tabIndex = b.getAttribute("data-pal") === pal.id ? 0 : -1; });
      PS.theme.editable.forEach(function (k) {
        var row = S.$('[data-k="' + k + '"]', alvo);
        S.$("[data-cor]", row).value = r.colors[k];
        var hx = S.$("[data-hex]", row);
        if (document.activeElement !== hx) { hx.value = r.colors[k].toUpperCase(); hx.removeAttribute("aria-invalid"); }
        row.classList.toggle("is-changed", Object.prototype.hasOwnProperty.call(est.overrides, k));
      });
      var baixo = r.checks.filter(function (c) { return c.ratio < 4.5; });
      S.$("[data-checks]", alvo).innerHTML = '<ul class="checks">' + r.checks.map(function (c) {
        return '<li class="' + (c.ratio >= 4.5 ? "ok" : "bad") + '"><span>' + S.esc(c.name) + "</span><strong>" + c.ratio.toFixed(1).replace(".", ",") + ":1 · " + (c.ratio >= 7 ? "AAA" : c.ratio >= 4.5 ? "AA" : "abaixo de AA") + "</strong></li>";
      }).join("") + "</ul>" + (baixo.length ? '<p class="alert alert--error small">Algum contraste ficou abaixo do mínimo (4,5:1). Escolha tons mais contrastantes antes de salvar.</p>' : "");
      S.$("[data-salvar]", alvo).disabled = baixo.length > 0;
    }
    S.$all("[data-pal]", alvo).forEach(function (b) { b.onclick = function () { est = { paletteId: b.getAttribute("data-pal"), overrides: {} }; render(); }; });
    S.$(".pal-grid", alvo).addEventListener("keydown", function (e) {
      var l = S.$all("[data-pal]", alvo), i = l.indexOf(document.activeElement), d = { ArrowRight: 1, ArrowDown: 1, ArrowLeft: -1, ArrowUp: -1 }[e.key];
      if (i < 0 || !d) return; e.preventDefault(); var b = l[(i + d + l.length) % l.length]; b.focus(); b.click();
    });
    function definir(k, v) {
      var base = PS.color.normalizeHex(PS.theme.getPalette(est.paletteId).colors[k]);
      v = PS.color.normalizeHex(v);
      if (!v) return;
      if (v === base) delete est.overrides[k]; else est.overrides[k] = v;
      render();
    }
    S.$all("[data-cor]", alvo).forEach(function (i) { i.oninput = function () { definir(i.getAttribute("data-cor"), i.value); }; });
    S.$all("[data-hex]", alvo).forEach(function (i) {
      i.oninput = function () {
        var v = i.value.trim(); if (v && v[0] !== "#") v = "#" + v;
        var ok = /^#[0-9a-fA-F]{6}$/.test(v);
        var ruim = !/^#?[0-9a-fA-F]{0,6}$/.test(i.value.trim()) || (v.length >= 7 && !ok);
        i.setAttribute("aria-invalid", ruim ? "true" : "false");
        if (ok) definir(i.getAttribute("data-hex"), v);
      };
      i.onblur = render;
    });
    S.$all("[data-reset]", alvo).forEach(function (b) { b.onclick = function () { delete est.overrides[b.getAttribute("data-reset")]; render(); }; });
    S.$("[data-voltar-salvo]", alvo).onclick = function () { est = { paletteId: PS.theme.getPalette(salvo.paletteId).id, overrides: Object.assign({}, salvo.overrides || {}) }; render(); };
    S.$("[data-original]", alvo).onclick = function () { est = { paletteId: PS.config.defaultPalette, overrides: {} }; render(); };
    S.$("[data-salvar]", alvo).onclick = function () {
      var btn = this, msg = S.$("[data-msg]", alvo), b = { paletteId: est.paletteId, overrides: Object.assign({}, est.overrides) };
      S.ocupado(btn, true, "Salvando…");
      PS.api.salvarCores(b).then(recarregarClinica).then(function () {
        salvo = clinica.settings.branding;
        // Neste navegador, o site e o portal passam a mostrar a identidade salva
        PS.theme.setBranding(b, { animate: false });
        S.ocupado(btn, false);
        S.alerta(msg, "Identidade salva: " + PS.theme.getPalette(b.paletteId).name + (Object.keys(b.overrides).length ? " com cores personalizadas" : "") + ".", "ok");
      }).catch(function (e) { S.ocupado(btn, false); S.alerta(msg, S.mensagem(e)); });
    };
    render();
  }

  /* ---------------- Acesso administrativo ---------------- */
  function listaPendentes(lista) {
    return lista.length ? '<table class="table table--cards"><thead><tr><th>E-mail</th><th>Expira em</th><th><span class="sr-only">Ações</span></th></tr></thead><tbody>' +
      lista.map(function (i) {
        return '<tr><td data-th="E-mail">' + S.esc(i.email) + '</td><td data-th="Expira em">' + S.esc(new Date(i.expiresAt).toLocaleDateString("pt-BR")) + '</td><td><button type="button" class="btn btn--ghost btn--xs" data-revogar="' + S.esc(i.id) + '">Revogar</button></td></tr>';
      }).join("") + "</tbody></table>" : '<div class="empty">Nenhum convite pendente.</div>';
  }
  function telaAcesso() {
    var demo = PS.api.modo === "demo";
    alvo.innerHTML = '<p class="loading"><span class="spinner"></span>Carregando acessos…</p>';
    PS.api.acessos().then(function (a) {
      var souDona = a.members.some(function (m) { return m.isMe && m.role === "owner"; });
      alvo.innerHTML = '<div class="stack">' +
        '<section class="panel"><div class="panel__head"><h2>Administradoras</h2></div>' +
          '<p class="muted small">Não existe cadastro aberto de administradora. A proprietária é criada na configuração inicial; outras pessoas entram só por convite, e a permissão é conferida pelo banco a cada acesso.</p>' +
          '<table class="table table--cards"><thead><tr><th>E-mail</th><th>Papel</th><th><span class="sr-only">Ações</span></th></tr></thead><tbody>' +
          a.members.map(function (m) {
            var pode = souDona && !m.isMe && m.role !== "owner";
            return '<tr><td data-th="E-mail">' + S.esc(m.email) + (m.isMe ? ' <span class="tag">você</span>' : "") + '</td><td data-th="Papel">' + (m.role === "owner" ? "Proprietária" : "Administradora") + "</td>" +
              "<td>" + (pode ? '<button type="button" class="btn btn--ghost btn--xs" data-remover="' + S.esc(m.userId) + '" data-email="' + S.esc(m.email) + '">Remover acesso</button>' : "") + "</td></tr>";
          }).join("") + "</tbody></table>" +
          (souDona ? "" : '<p class="small muted" style="margin-top:.75rem">Somente a proprietária pode remover administradoras.</p>') + "</section>" +
        '<section class="panel"><h2>Convidar administradora</h2>' +
          (demo ? '<div class="alert alert--info">Demonstração: o convite é registrado e pode ser revogado, mas não pode ser aceito (não há e-mail nem conta real).</div>' : "") +
          '<form class="form" data-f novalidate>' + campo("inv-email", "E-mail da pessoa convidada", "", "email", 'maxlength="254" autocomplete="off"') +
          '<p class="alert" data-msg hidden role="status"></p><div class="form-actions"><button class="btn btn--primary" type="submit">Gerar convite</button></div></form>' +
          '<div data-codigo></div>' +
          '<p class="small muted">A pessoa cria a conta com <strong>o mesmo e-mail</strong> em <code>admin/aceitar-convite.html</code> e usa o código (válido por 7 dias, uso único). O código aparece só uma vez e não fica salvo — no banco fica apenas a impressão digital (hash).</p></section>' +
        '<section class="panel"><h2>Convites pendentes</h2><div data-pendentes>' + listaPendentes(a.invites) + "</div></section></div>";

      S.$("[data-f]", alvo).addEventListener("submit", function (e) {
        e.preventDefault();
        var f = e.target, email = S.$("#inv-email").value.trim(), msg = S.$("[data-msg]", f), btn = S.$("[type=submit]", f);
        if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return S.alerta(msg, "Informe um e-mail válido.");
        S.ocupado(btn, true, "Gerando…");
        PS.api.convidarAdministradora(email).then(function (codigo) {
          S.ocupado(btn, false);
          S.$("[data-codigo]", alvo).innerHTML = '<div class="invite-code"><p><strong>Convite criado para ' + S.esc(email) + ".</strong> Copie o código agora e envie por um canal seguro:</p>" +
            '<div class="invite-code__row"><code data-cod>' + S.esc(codigo) + '</code><button type="button" class="btn btn--outline btn--xs" data-copiar><svg class="icon" aria-hidden="true"><use href="#i-copy"/></svg>Copiar</button></div></div>';
          S.$("[data-copiar]", alvo).onclick = function () {
            var t = S.$("[data-cod]", alvo).textContent;
            (navigator.clipboard ? navigator.clipboard.writeText(t) : Promise.reject()).then(function () { S.toast("Código copiado."); }, function () { S.toast("Selecione o código e copie manualmente."); });
          };
          S.$("#inv-email").value = "";
          PS.api.acessos().then(pendentes).catch(function () {});
        }).catch(function (err) { S.ocupado(btn, false); S.alerta(msg, S.mensagem(err)); });
      });
      function pendentes(a2) { S.$("[data-pendentes]", alvo).innerHTML = listaPendentes(a2.invites); }
      alvo.onclick = function (e) {
        var rv = e.target.closest("[data-revogar]"), rm = e.target.closest("[data-remover]");
        if (rv) S.confirmar({ titulo: "Revogar convite?", texto: "O código deixa de funcionar imediatamente.", confirmar: "Revogar" }).then(function (sim) {
          if (sim) PS.api.revogarConvite(rv.getAttribute("data-revogar")).then(function () { S.toast("Convite revogado."); telaAcesso(); }, function (er) { S.toast(S.mensagem(er), "erro"); });
        });
        if (rm) S.confirmar({ titulo: "Remover acesso?", texto: rm.getAttribute("data-email") + " perde o acesso ao painel imediatamente.", confirmar: "Remover acesso", perigo: true }).then(function (sim) {
          if (sim) PS.api.removerAdministradora(rm.getAttribute("data-remover")).then(function () { S.toast("Acesso removido."); telaAcesso(); }, function (er) { S.toast(S.mensagem(er), "erro"); });
        });
      };
    }).catch(function (e) { PS.admin.erroComTentativa(alvo, e, telaAcesso); });
  }
})();
