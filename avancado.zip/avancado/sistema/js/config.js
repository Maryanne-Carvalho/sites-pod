/* ==========================================================================
   CONFIGURAÇÃO DO SISTEMA — escolha entre DEMONSTRAÇÃO e SUPABASE (real)
   --------------------------------------------------------------------------
   modo: "demo"     → dados fictícios guardados só neste navegador.
                      NÃO existe login de verdade nem servidor. Serve para
                      conhecer e testar as telas.
   modo: "supabase" → banco de dados e login reais (Supabase).
                      Preencha url, anonKey e clinicId (veja docs/SUPABASE.md).

   ⚠ Aqui só entram dados PÚBLICOS. A chave "anon" pode ficar no site porque
     quem protege os dados são as regras de acesso do banco (RLS).
     NUNCA coloque a chave "service_role" neste arquivo nem em nenhum outro
     arquivo do site.
   ========================================================================== */
window.PS = window.PS || {};

window.PS.sistema = {
  modo: "demo",

  supabase: {
    url: "",        // ex.: "https://abcdefghijkl.supabase.co"
    anonKey: "",    // chave pública "anon" (Project Settings → API)
    clinicId: ""    // ID mostrado ao rodar supabase/setup-clinica-e-admin.sql
  },

  /* Em produção, deixe false: a central de demonstração e as contas de teste
     ficam indisponíveis. (No modo "supabase" elas nunca existem.) */
  permitirDemonstracao: true,

  /* Endereço público do site (usado nos links de recuperação de senha). Vazio = detecta sozinho. */
  enderecoDoSite: "",

  /* Botões "Agendar" do site:
       true  → levam a agendar.html (demonstração ou Supabase, conforme "modo");
       false → levam à página de contato (use enquanto a agenda on-line não estiver pronta). */
  agendamentoOnline: true,

  /* Chave de armazenamento da demonstração (exclusiva do Avançado; não afeta Básico nem Elegance).
     "v2" = dados com convites e fila de avisos (versão Beatriz Nascimento). */
  demoStorageKey: "avancado-demo:v2:beatriz-nascimento",

  /* Versão da biblioteca do Supabase carregada no modo real */
  supabaseJs: "https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.45.4/dist/umd/supabase.min.js"
};
