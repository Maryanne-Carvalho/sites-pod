# Avisos por e-mail — como funcionam e como ativar

## O que já funciona (testado no PostgreSQL local)

A migração 004 cria a tabela `notification_outbox` (a **fila de avisos**). O próprio banco coloca um item na fila quando:

| Evento | Tipo na fila | Respeita a preferência |
|---|---|---|
| Cliente agenda pelo site | `new_booking` | “Novo agendamento feito pelo site” |
| Cliente cancela direto | `cancellation` | “Cancelamento feito pelo cliente” |
| Cliente pede cancelamento/remarcação | `request` | apenas exige e-mail configurado |

- Sem e-mail configurado em **Configurações › Notificações**, nada entra na fila.
- A fila **não guarda** nome, telefone, e-mail do paciente nem textos livres: só clínica, tipo, agendamento e situação do envio.
- Administradoras **leem** a fila no painel (aba Notificações › Situação dos avisos). Ninguém consegue inserir avisos falsos nem marcar como “enviado” pela API — isso só é possível no servidor, pela Edge Function (papel `service_role`).

## O que depende de você (NÃO testado contra um Supabase real)

O **envio** é feito pela Edge Function `supabase/functions/enviar-avisos/index.ts`, um **modelo** pronto para o provedor [Resend](https://resend.com). Ela não foi executada por nós.

1. Instale o Supabase CLI e faça login (`supabase login`), depois `supabase link --project-ref SEU_PROJETO`.
2. Crie uma conta no Resend, valide o domínio de envio e gere uma API key.
3. Cadastre os segredos **no servidor** (nunca no site):
   ```
   supabase secrets set RESEND_API_KEY=re_xxx
   supabase secrets set AVISOS_REMETENTE="Beatriz Nascimento <avisos@seudominio.com.br>"
   supabase secrets set AVISOS_CHAVE_AGENDADOR=uma-frase-longa-e-aleatoria
   ```
4. Publique: `supabase functions deploy enviar-avisos --no-verify-jwt`
5. Agende a chamada a cada 5 minutos (Supabase › Integrations › Cron, ou outro agendador) para
   `https://SEU_PROJETO.functions.supabase.co/enviar-avisos` com o cabeçalho
   `Authorization: Bearer <AVISOS_CHAVE_AGENDADOR>`.
6. Faça um agendamento de teste pelo site e confira no painel se o aviso passa de “Na fila” para “Enviado”.

Cada aviso tem até 5 tentativas; depois fica “Falhou”, com o motivo resumido.

## Não incluídos nesta versão

- Lembretes por **WhatsApp** ou SMS para pacientes.
- **Resumo diário** automático (a preferência existe, mas está marcada como “não incluído”).
- **Pagamentos** on-line.

Nenhum desses recursos é simulado: o painel diz claramente que não estão disponíveis.
