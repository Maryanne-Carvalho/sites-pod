# Relatório de auditoria inicial — Modelo Avançado (versão recebida)

Data da auditoria: 11/11/2026. Base: `Podologa_avancado.zip` (77 arquivos), antes de qualquer alteração. O commit `baseline (original recebido)` do repositório guarda exatamente essa versão.

## 1. O que foi analisado

| Área | Arquivos | Método |
|---|---|---|
| Site público (9 páginas) | `*.html`, `css/*`, `js/*` | leitura do código, navegação real em Chrome |
| Agendamento on-line | `agendar.html`, `sistema/js/agendar.js`, `seletor-horario.js`, `disponibilidade.js`, `tempo.js` | leitura + teste de navegador |
| Portal do cliente (6 telas) | `cliente/*.html`, `sistema/js/cliente.js` | leitura + teste de navegador |
| Painel (8 telas) | `admin/*.html`, `sistema/js/admin-*.js` | leitura + teste de navegador |
| Camada de API | `api.js`, `api-demo.js` (769 linhas), `api-supabase.js` (391 linhas) | comparação método a método (mesma superfície nas duas) |
| Banco | `001_tabelas.sql`, `002_seguranca_rls.sql`, `003_funcoes.sql`, `setup-clinica-e-admin.sql` | leitura + execução em PostgreSQL 16 local |
| Testes existentes | `supabase/tests/*`, `tests/*` | execução real |

## 2. Resultado dos testes existentes (antes de mexer)

| Teste | Resultado |
|---|---|
| SQL de permissões e agenda (`10_…sql`) | **72/72** passaram |
| Reserva simultânea (8 clientes no mesmo horário) | passou (1 aceita, 7 recusadas; e a restrição recusa gravação direta) |
| Motor do navegador × motor do banco (5 cenários) | passou (horários idênticos) |
| Dados de demonstração sem conflito | passou |
| Navegador completo (`50_…js`) | **FALHOU** — “Nenhum horário livre dentro do almoço (0 livres)” e depois `TypeError` |

**Diagnóstico da falha:** não era defeito do sistema. O teste escolhia “a próxima segunda-feira daqui a 7 dias” e os dados fictícios criam um *feriado de exemplo* numa data relativa a hoje, que coincidiu com essa segunda. O `tests/RESULTADOS.md` recebido afirmava 54/54, o que **não era reproduzível** na data da auditoria.

## 3. Pontos fortes encontrados

- Regra essencial no banco: restrição de exclusão `sem_sobreposicao` (btree_gist) impede dois atendimentos ativos sobrepostos, inclusive em gravações simultâneas; trava por clínica (`pg_advisory_xact_lock`) nas funções de reserva.
- Funções `SECURITY DEFINER` com `search_path = ''`, `revoke all` + `grant` explícito, RLS em todas as tabelas.
- Convites guardados só como hash; aceite exige o mesmo e-mail.
- Duas pontes de API (demonstração e Supabase) com exatamente os mesmos métodos.
- Indicadores e relatórios calculados a partir dos agendamentos reais (sem números fixos).
- Notificações por e-mail **honestamente** marcadas como “não ativas”.

## 4. Problemas encontrados

### Banco e segurança
| # | Problema | Gravidade |
|---|---|---|
| B1 | `appointment_notes.clinic_id` e `appointment_requests.clinic_id` não eram presos à clínica do agendamento: uma administradora da clínica B podia gravar observação apontando para um agendamento da clínica A informando o `clinic_id` da própria clínica (a política só olhava o `clinic_id` informado). | Alta |
| B2 | Horários de atendimento e pausas legíveis por qualquer visitante para **qualquer** clínica, inclusive não publicada (`using (true)`). | Média |
| B3 | Salvar horários apagava e regravava em **várias chamadas separadas** pelo navegador: uma falha no meio deixava a clínica sem horários. | Alta (operacional) |
| B4 | Anonimização (LGPD) não apagava observações dos atendimentos, motivos em texto livre, nem encerrava pedidos pendentes. | Média |
| B5 | Convites sem validação de e-mail na função, sem revogação, sem lista; não havia remoção de administradora. | Média |
| B6 | Funções de gatilho do esquema `app` executáveis por `PUBLIC` (padrão do PostgreSQL). | Baixa |
| B7 | Cores da clínica (`branding`, legível pelo público) aceitavam qualquer JSON — risco de valores inesperados chegarem ao CSS do site. | Média |

### Painel e telas
| # | Problema |
|---|---|
| P1 | Horários: só **um turno e uma pausa por dia** na tela (o banco aceitava vários; a tela avisava que turnos extras seriam descartados ao salvar). |
| P2 | Acesso administrativo: só gerava convite; não listava administradoras nem convites, não revogava, não removia. |
| P3 | Configurações agrupavam regras numa aba só; faltavam abas pedidas (Horários, Confirmação, Cancelamento, Remarcação). |
| P4 | Identidade visual: 8 paletas antigas, só 2 cores editáveis, sem HEX; o painel mudava de cor junto com o site. |
| P5 | CSV: proteção contra fórmula só cobria `= + - @` (faltavam TAB e retorno de carro). |
| P6 | Erros de conexão: mensagens genéricas, sem “tentar de novo”; requisições sem limite de tempo podiam deixar a tela carregando. |
| P7 | Busca de pacientes: sanitização parcial de caracteres da sintaxe do PostgREST. |
| P8 | Bloqueio: contagem de agendamentos afetados sem tratamento de erro (mostraria 0 se falhasse). |

### Identidade e conteúdo
- Visual e conteúdo herdados do Elegance v1 (“Dra. Marina Oliveira”, “Podologia Studio”, Cormorant + Jost, paleta “rosa-areia”).
- Fotos do Unsplash genéricas, incluindo retrato de profissional de saúde não relacionado à podologia — contraria o briefing.

## 5. Mapa de dependências e persistência

O mapa completo interface ↔ API ↔ banco está em `docs/MAPA-DA-ARQUITETURA.md`. Na auditoria, todas as operações do painel e do portal foram conferidas: **todas gravam de fato** (no modo demonstração, no armazenamento do navegador com as mesmas regras; no modo Supabase, por RPC/PostgREST com RLS). Não foi encontrada nenhuma tela que fingisse salvar. A única exceção era o envio de e-mails, já declarado como inativo.
