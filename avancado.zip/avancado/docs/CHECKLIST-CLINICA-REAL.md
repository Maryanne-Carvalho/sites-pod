# Checklist para colocar uma clínica real no ar

Marque cada item. Não publique com itens críticos (⚠) pendentes.

## Conteúdo e identidade
- [ ] ⚠ `js/content.js`: nome, profissional, **registro profissional real** (ou deixe vazio), formação real, telefone, WhatsApp (`isDemoNumber: false`), e-mail, endereço, horários exibidos, redes sociais.
- [ ] ⚠ Depoimentos: só reais e autorizados; `testimonialsAreDemo: false`. Sem notas ou estrelas inventadas.
- [ ] ⚠ Fotos reais da profissional e do consultório em `window.PS.photos` (ver `docs/FOTOS.md`).
- [ ] Identidade visual escolhida e salva em Painel › Configurações › Identidade visual.
- [ ] ⚠ Política de privacidade revisada por profissional jurídico (prazo de retenção, controladora, contato).

## Supabase (projeto de PRODUÇÃO)
- [ ] ⚠ Migrações 001 → 002 → 003 → 004 aplicadas, sem erros; depois `setup-clinica-e-admin.sql` com os dados da clínica e o e-mail da proprietária.
- [ ] ⚠ Nada da pasta `supabase/tests/` rodado em produção.
- [ ] Authentication: confirmação de e-mail ligada, cadastro anônimo desligado, senha mínima ≥ 8, URLs de redirecionamento do domínio final.
- [ ] SMTP próprio configurado (o envio padrão do Supabase é limitado).
- [ ] Modelos de e-mail traduzidos.
- [ ] Horários, serviços (duração e preço), regras de confirmação/cancelamento/remarcação conferidos no painel.
- [ ] (Opcional) Avisos por e-mail: Edge Function publicada, segredos cadastrados, agendador ativo, teste feito (`docs/NOTIFICACOES.md`).
- [ ] Backups do banco conferidos no plano contratado.

## Site
- [ ] ⚠ `sistema/js/config.js`: `modo: "supabase"`, URL, **chave pública (anon)**, `clinicId`, `permitirDemonstracao: false`, `enderecoDoSite`.
- [ ] ⚠ Conferir que nenhuma chave `service_role`/`sb_secret` existe em nenhum arquivo do site ou do repositório.
- [ ] Publicado com HTTPS (Vercel: `docs/VERCEL.md`).

## Testes antes de divulgar (num projeto de TESTE, nunca em produção)
- [ ] `supabase/tests/90_integracao_supabase_real.mjs` executado num projeto **de teste** idêntico, todas as linhas PASSOU.
- [ ] Cadastro real de cliente com confirmação de e-mail; recuperação de senha; troca de senha.
- [ ] Agendamento on-line, cancelamento e remarcação dentro e fora do prazo.
- [ ] Convite de administradora: criar, aceitar com o mesmo e-mail, revogar, remover.
- [ ] Celular (iPhone e Android) e computador.

## Operação
- [ ] Combinar com a equipe: observações são **administrativas**, nunca dados de saúde.
- [ ] Rotina para pedidos de exclusão (anonimizar em Pacientes) e de cópia dos dados (cliente exporta em Meus dados).
