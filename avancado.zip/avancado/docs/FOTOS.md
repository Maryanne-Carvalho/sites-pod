# Fotos do site — orientação

O briefing original pedia fotografias de **uma podóloga negra** em **ambiente profissional de podologia**. Depois, a cliente liberou o retrato para qualquer pessoa; o ambiente de podologia continua sendo o critério das demais fotos.

## Fotos de demonstração incluídas (Pexels, licença gratuita)

| Espaço | Foto (página no Pexels) | Descrição oficial da foto |
|---|---|---|
| `retrato` (Início e Sobre) | pexels.com/photo/7904416 — Anna Tarazevich | Profissional sorridente, de jaleco branco, sentada à mesa com materiais de atendimento (sem estetoscópio) |
| `atendimento` (Início) | pexels.com/photo/5619447 | Podóloga fazendo cuidado nos pés de uma paciente em consultório |
| `sala` (Clínica) | pexels.com/photo/5619462 | Consultório moderno com maca e equipamentos (sem pessoas) |
| `recepcao` (Clínica) | pexels.com/photo/5619496 | Consultório vazio com divisória de proteção |
| `instrumental` (Clínica) | pexels.com/photo/5619451 | Profissional de uniforme atendendo sob luminária |

Licença Pexels: uso gratuito, inclusive comercial, sem obrigação de crédito (o rodapé mostra “Fotos de demonstração: Pexels” por transparência). Não é permitido vender a foto isolada nem sugerir que as pessoas fotografadas endossam a marca.

**Limites honestos:**
- A escolha foi feita pela **descrição oficial** de cada foto no Pexels: o ambiente onde o modelo foi produzido bloqueia imagens externas, então não foi possível olhar as fotos. Abra o site com internet e confira se ficaram como você quer.
- O retrato é de uma profissional de saúde de jaleco, não de uma podóloga identificada; por decisão da cliente, a foto não precisa representar uma mulher negra. As fotos de atendimento vêm de uma sessão de podologia/cuidado dos pés.
- As fotos são carregadas direto do Pexels. Sem internet, ou se o Pexels mudar o endereço, aparece automaticamente o quadro gráfico “BN”.
- Para a clínica real, o ideal é trocar todas pelas fotos **da própria profissional e do próprio consultório**.

## Como colocar as fotos reais

Em `js/content.js`, bloco `window.PS.photos`, preencha `src` de cada item:

| Chave | Onde aparece | Foto recomendada |
|---|---|---|
| `retrato` | Início (destaque) e Sobre | Retrato vertical da profissional, de jaleco, no consultório |
| `atendimento` | Início (seção Clínica) | Mãos com luvas e instrumental durante o atendimento, sem identificar o paciente |
| `sala` | Clínica | Cadeira podológica, iluminação e bancada |
| `recepcao` | Clínica | Recepção |
| `instrumental` | Clínica | Instrumental esterilizado em embalagem lacrada |
| `detalhe` | reserva | Detalhe do ambiente |

Exemplo: `retrato: { src: "assets/img/beatriz-retrato.jpg", alt: "...", hint: "..." }`. Use JPG ou WebP de até ~300 KB, 1200 px no lado maior.

Boas práticas: use fotos **da própria profissional e do próprio consultório**; peça autorização por escrito para qualquer pessoa fotografada; nunca publique pés ou rostos de pacientes sem consentimento expresso.
