# Relatório de alterações — Modelo Avançado · Beatriz Nascimento | Podologia

Todas as alterações estão registradas em commits no repositório (`git log`), a partir do commit `baseline (original recebido)`.

## 1. Banco de dados — migração nova `004_correcoes_e_recursos.sql`

As migrações 001–003 **não foram alteradas**. A 004 é idempotente e não afrouxa nenhuma restrição.

| Correção / recurso | Detalhe |
|---|---|
| B1 · Observações e pedidos presos à clínica do agendamento | `unique(id, clinic_id)` em `appointments` + chaves estrangeiras compostas em `appointment_notes` e `appointment_requests` (criadas `NOT VALID`, linhas antigas corrigidas, depois validadas). |
| B2 · Horários públicos só de clínica publicada | Políticas `rules_select` e `breaks_select` refeitas (publicada **ou** administradora). |
| B3 · Gravação atômica de horários | `admin_save_schedule(clínica, turnos, pausas)`: valida dia, formato, fim > início, até 6 turnos/6 pausas por dia, turnos e pausas sem sobreposição, pausa inteira dentro de um turno — e grava tudo ou nada. Erros: `INVALID_SCHEDULE`, `SHIFT_OVERLAP`, `BREAK_OVERLAP`, `BREAK_OUTSIDE_SHIFT`. |
| B4 · Anonimização completa | Também apaga observações dos atendimentos, apaga motivos em texto livre, encerra pedidos pendentes e mantém o histórico sem identificação. |
| B5 · Acesso administrativo | `create_admin_invite` valida e-mail, recusa quem já é membro, limita 20 convites abertos e substitui convite anterior do mesmo e-mail; `revoked_at`; `list_admin_access`; `revoke_admin_invite`; `remove_clinic_member` (só proprietária; não remove a si mesma nem proprietárias); `accept_admin_invite` recusa convite revogado e só concede `admin`. |
| B6 · Funções internas fechadas | `revoke all on all functions in schema app`; só `is_clinic_admin` e `is_own_patient` (usadas pelas políticas) continuam liberadas. |
| B7 · Cores validadas | Gatilho `validate_branding`: `paletteId` restrito e somente as chaves `primary, deep, accent, background, text` com `#RRGGBB`. Padrão novo: `ameixa-champagne`. |
| Fila de avisos | Tabela `notification_outbox` (sem dados pessoais), gatilhos respeitando preferências, leitura só por administradoras, `claim_notifications`/`finish_notification` só para `service_role`. |

Testes novos: `supabase/tests/11_testes_migracao_004.sql` (**67 verificações**), incluindo varredura geral de privilégios (toda função `SECURITY DEFINER` com `search_path`; visitante só executa 2 funções; RLS em todas as tabelas; visitante sem escrita).

## 2. API (duas pontes, mesma superfície)

- `salvarHorarios` → RPC atômica (Supabase) e mesma validação na demonstração (`validarGrade`).
- Novos: `acessos`, `revogarConvite`, `removerAdministradora`, `filaDeAvisos` (demonstração e Supabase).
- Demonstração passa a imitar: anonimização completa, convites (registrados e revogáveis, não aceitáveis), fila de avisos (nada é enviado), validação de cores.
- `traduzir`: códigos do PostgreSQL/PostgREST (`PGRST116`, `23503`, `23505`, `23P01`, `42501`, `23514`) e tempo esgotado.
- Limite de 20 s por requisição ao Supabase (sem isso a tela podia ficar “carregando” para sempre).
- Busca de pacientes: remove caracteres da sintaxe de filtros do PostgREST; bloqueio informa “desconhecido” se a contagem falhar.

## 3. Painel administrativo (prioridade)

- **Horários com vários turnos e pausas por dia** (`sistema/js/admin-horarios.js`), em Agenda › Horários e Configurações › Horários: adicionar/remover turnos e pausas, nome da pausa, “copiar para os dias marcados”, resumo por dia, validação local idêntica à do banco e barra de salvar fixa.
- **Configurações em 10 abas:** Clínica, Serviços, Horários, Regras, Confirmação, Cancelamento, Remarcação, Notificações, Identidade visual, Acesso administrativo.
- **Notificações honestas:** preferências + tabela real da fila (Na fila / Enviado / Falhou / Ignorado, tentativas, erro). Resumo diário, WhatsApp e pagamentos marcados “não incluídos”.
- **Acesso administrativo:** lista de administradoras e convites pendentes, gerar convite com botão copiar, revogar convite, remover administradora (com confirmação).
- **Identidade visual:** 9 paletas, 5 cores com seletor + HEX + restaurar por cor, prévia ao vivo num “mini site”, relatório de contraste e salvar bloqueado abaixo de AA. O painel **não muda de cor** (identidade própria fixa).
- **Erros e carregamento:** “Tentar de novo” em falhas de rede, aviso de navegador sem internet, novas mensagens para todos os códigos de erro.
- **CSV:** proteção contra fórmula cobre `= + - @`, TAB, retorno de carro e espaços antes deles.
- Correções de largura em telas pequenas (tabelas, calendário mensal, lista da agenda, abas roláveis).

## 4. Nova identidade: Beatriz Nascimento | Podologia

- Conteúdo novo (`js/content.js`), sem registro, instituição ou certificação inventados (campos vazios com orientação).
- Linguagem visual própria “Assinatura” (`css/assinatura.css`): DM Serif Display + Sora, fio champanhe, numeração “Nº”, quadros com moldura deslocada, faixas profundas. Removidos `elegance.css`, `pages.css`, `elegance.js` e `layout.js` herdados.
- 9 páginas públicas reescritas (Início, Sobre, Clínica, Serviços, Avaliações, Contato, Privacidade, Agendamento, Central de demonstração). Botões “Agendar” seguem `agendamentoOnline` em `config.js`.
- **Fotos:** fotos gratuitas do Pexels (retrato de profissional de jaleco, atendimento podológico e consultório), com o quadro gráfico como reserva sem internet (ver `docs/FOTOS.md`).
- **Ateliê de cores** (demonstração): 9 paletas, 5 cores com HEX, restaurar por cor e total, relatório WCAG, persistência entre páginas, chave exclusiva.
- Motor de temas: 5 cores editáveis, derivadas recalculadas, paleta desconhecida vinda do banco cai na padrão, e o texto do botão agora **sempre** atinge 4,5:1 (defeito encontrado por teste aleatório e corrigido).
- Política de privacidade reescrita como **modelo** com aviso de revisão jurídica obrigatória.

## 5. Testes

- `tests/50_navegador_completo.js`: corrigida a fragilidade de data (escolhe segunda-feira sem bloqueios); seção de cores reescrita para os novos requisitos com **mais** verificações (de 9 para 24 nessa seção; o arquivo passou de 55 para 70 verificações executadas).
- Novos: `tests/45_funcoes_puras.js` (18), `tests/60_responsivo_e_acessibilidade.js` (11 larguras × 37 telas + acessibilidade básica), `supabase/tests/11_testes_migracao_004.sql` (67), `supabase/tests/90_integracao_supabase_real.mjs` (preparado, não executado).
- Nenhum teste foi removido ou enfraquecido.
