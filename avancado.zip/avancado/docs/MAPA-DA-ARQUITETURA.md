# Mapa da arquitetura — interface ↔ API ↔ banco

```
 Navegador (HTML + CSS + JS, sem etapa de build)
 ├─ Site público ── js/content.js (textos DEMONSTRATIVOS) ── js/site.js
 │                  js/theme-engine.js + js/palettes.js (9 paletas, 5 cores)
 │                  js/palette-switcher.js (Ateliê de cores, só demonstração)
 ├─ agendar.html, cliente/*, admin/*  ── sistema/js/*.js (telas)
 │        │
 │        ▼
 │   sistema/js/api.js  → escolhe a ponte conforme sistema/js/config.js
 │        ├─ api-demo.js      (modo "demo": dados fictícios no navegador,
 │        │                     mesmas regras do banco — NÃO é segurança)
 │        └─ api-supabase.js  (modo "supabase": chave pública + RLS)
 │                 │  PostgREST (tabelas) e RPC (funções)
 ▼                 ▼
 Supabase: Auth (login) · PostgreSQL (RLS, funções SECURITY DEFINER,
           restrição sem_sobreposicao) · Edge Function enviar-avisos (opcional)
```

**Dados de demonstração × dados operacionais:** `js/content.js` só alimenta textos do site público. Serviços, horários, regras, pacientes e agendamentos reais ficam no banco; na demonstração, em `sistema/js/dados-demo.js` + armazenamento local (chave `avancado-demo:v2:beatriz-nascimento`).

## Telas → métodos da API → objetos do banco

| Tela | Método (`PS.api.*`) | Supabase (modo real) | Garantia no banco |
|---|---|---|---|
| Agendar (site) | `servicos`, `horariosLivres`, `agendar` | `services` (select), `get_available_slots`, `book_appointment` | RLS; recálculo do horário livre + trava por clínica + `sem_sobreposicao` |
| Login/cadastro cliente | `entrar`, `cadastrarCliente`, `pedirNovaSenha`, `definirNovaSenha`, `sair` | Supabase Auth, `register_my_patient`, `my_access` | papel decidido pelo banco; cadastro sempre “cliente” |
| Meus agendamentos | `meusAgendamentos`, `cancelarMeu`, `reagendarMeu`, `desistirDoPedido` | `appointments` (RLS: só os seus), `cancel_my_appointment`, `reschedule_my_appointment`, `withdraw_my_request` | prazos e modo direto/aprovação conferidos no banco |
| Meus dados | `meuCadastro`, `atualizarMeuCadastro`, `exportarMeusDados` | `patients` (RLS), `update_my_patient`, `export_my_data` | só o próprio cadastro |
| Visão geral | `agendamentos`, `pedidosPendentes`, `responderPedido`, `mudarStatus` | `appointments`, `appointment_requests`, `admin_resolve_request`, `admin_set_status` | `is_clinic_admin`; matriz de transições |
| Agenda (dia/semana/mês) | `agendamentos`, `horariosLivres`, `remarcar`, `salvarObservacao`, `bloqueios`, `adicionarBloqueio`, `removerBloqueio` | `admin_reschedule`, `appointment_notes`, `schedule_exceptions` | observação presa à clínica do agendamento (FK composta, 004) |
| Horários (Agenda e Configurações) | `horariosDeAtendimento`, `salvarHorarios`, `salvarRegras` | `availability_rules/breaks` (select), **`admin_save_schedule`** (004), `clinic_settings` | gravação atômica; turnos/pausas validados |
| Novo agendamento | `pacientes`, `salvarPaciente`, `horariosLivres`, `agendar(…, patientId)` | `patients`, `book_appointment` | mesmas regras da reserva on-line (sem antecedência mínima/limite de dias para a equipe) |
| Pacientes | `pacientes`, `paciente`, `adicionarAnotacao`, `removerAnotacao`, `anonimizarPaciente` | `patients`, `patient_notes`, `anonymize_patient` (004 ampliada) | anotações administrativas (não é prontuário) |
| Relatórios | `agendamentos` | `appointments` | cálculo no navegador a partir dos registros; CSV com proteção de fórmula |
| Config › Clínica / Serviços | `salvarClinica`, `salvarServico` | `clinics`, `services` | colunas liberadas por GRANT; RLS |
| Config › Regras / Confirmação / Cancelamento / Remarcação | `salvarRegras` | `clinic_settings` | CHECKs de faixa e valores |
| Config › Notificações | `notificacoes`, `salvarNotificacoes`, **`filaDeAvisos`** | `clinic_private_settings`, **`notification_outbox`** (só leitura) | fila preenchida por gatilho; envio só no servidor |
| Config › Identidade visual | `salvarCores` | `clinic_settings.branding` | **gatilho `validate_branding`** (004) |
| Config › Acesso administrativo | **`acessos`**, `convidarAdministradora`, **`revogarConvite`**, **`removerAdministradora`** | **`list_admin_access`**, `create_admin_invite`, **`revoke_admin_invite`**, **`remove_clinic_member`** | só proprietária remove; convite por hash, e-mail igual, uso único |
| Aceitar convite | `aceitarConvite` | Auth + `accept_admin_invite` | convite revogado/expirado/usado é recusado |
| Central de demonstração | `demo.*` | — (só existe no modo demo) | — |

Em **negrito**: criados nesta versão.

## Objetos do banco (após 004)

- **Tabelas:** `clinics`, `clinic_settings`, `clinic_private_settings`, `clinic_members`, `clinic_invites` (+ `revoked_at`), `services`, `patients`, `patient_notes`, `availability_rules`, `availability_breaks`, `schedule_exceptions`, `appointments` (+ `unique(id, clinic_id)`), `appointment_notes`, `appointment_requests`, `audit_log`, **`notification_outbox`**.
- **Funções chamáveis pelo visitante:** apenas `get_available_slots` e `my_access` (verificado por teste automático).
- **Funções só para o servidor (service_role):** `claim_notifications`, `finish_notification`.
- **Gatilhos novos:** `appointments_notify`, `requests_notify`, `clinic_settings_branding_check`.
