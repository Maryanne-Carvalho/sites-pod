# Limitações conhecidas (o que ainda falta)

1. **Sem validação num Supabase real.** Tudo o que envolve banco foi validado num PostgreSQL 16 local que imita o Supabase (papéis `anon`/`authenticated`/`service_role`, `auth.uid()` lendo o JWT). Isso não cobre: Supabase Auth (cadastro, confirmação de e-mail, recuperação de senha), PostgREST real, políticas padrão do projeto, limites de taxa, CORS, e a ponte `api-supabase.js` falando com a internet. O script `supabase/tests/90_integracao_supabase_real.mjs` está pronto, mas **não foi executado**.
2. **Edge Function de avisos não testada.** `supabase/functions/enviar-avisos` é um modelo (Resend). O banco enche a fila corretamente (testado), mas o envio nunca foi executado.
3. **Demonstração não é segurança.** No modo demo, qualquer pessoa pode alterar os dados no próprio navegador. A proteção real está no banco (modo Supabase).
4. **Fotos de demonstração.** O site usa fotos gratuitas do Pexels escolhidas pela descrição oficial (não foi possível visualizá-las aqui). O retrato mostra uma profissional de jaleco, não uma podóloga verificada. Para a clínica real, use fotos próprias (ver `docs/FOTOS.md`).
5. **Conteúdo fictício.** Profissional, endereço, telefones, horários exibidos e depoimentos são de demonstração. Não há registro profissional, formação ou certificação preenchidos.
6. **Documentos legais são modelo.** A política de privacidade precisa de revisão jurídica.
7. **Fontes externas.** DM Serif Display e Sora vêm do Google Fonts; sem internet, o site usa fontes de reserva (testes rodaram assim). A biblioteca do Supabase vem do jsDelivr sem verificação de integridade (SRI); recomenda-se hospedar o arquivo junto do site ou acrescentar o `integrity` da versão 2.45.4.
8. **Acessibilidade:** verificação automática (rótulos, nomes, h1, idioma, foco, contraste das paletas). Não houve teste com leitor de tela nem com pessoas usuárias.
9. **Relatórios** são calculados no navegador a partir de até 400 dias de agendamentos carregados; clínicas com volume muito alto podem precisar de agregação no banco.
10. **Fuso horário** da clínica é definido no setup inicial (não há tela para trocar), por segurança da agenda já marcada.
