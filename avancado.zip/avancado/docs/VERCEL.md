# Publicar na Vercel

O modelo é HTML/CSS/JS puro: não há etapa de build.

1. Coloque a pasta do projeto num repositório Git (GitHub, GitLab ou Bitbucket). Confira que **não há** nenhum arquivo com segredo (`.env` real, chave `service_role`, senhas). O `.env.example` não contém segredos.
2. Na Vercel: **Add New › Project**, importe o repositório.
3. Framework Preset: **Other**. Build Command: *vazio*. Output Directory: `.` (raiz). Install Command: *vazio*.
4. Antes do deploy de produção, edite `sistema/js/config.js`:
   - `modo: "supabase"`; `supabase.url`, `supabase.anonKey` (**chave pública**) e `supabase.clinicId`;
   - `permitirDemonstracao: false`;
   - `enderecoDoSite: "https://seu-dominio.com.br"`.
5. Deploy. Depois, em **Settings › Domains**, conecte o domínio (HTTPS é automático — o modo real exige https).
6. No Supabase (Authentication › URL Configuration), use o domínio final em **Site URL** e nas **Redirect URLs** (`/cliente/entrar.html`, `/cliente/nova-senha.html`, `/admin/aceitar-convite.html`).

## Cabeçalhos de segurança recomendados (opcional)

Crie `vercel.json` na raiz:

```json
{
  "headers": [
    { "source": "/(.*)", "headers": [
      { "key": "X-Content-Type-Options", "value": "nosniff" },
      { "key": "Referrer-Policy", "value": "strict-origin-when-cross-origin" },
      { "key": "X-Frame-Options", "value": "DENY" },
      { "key": "Permissions-Policy", "value": "camera=(), microphone=(), geolocation=()" }
    ]},
    { "source": "/admin/(.*)", "headers": [ { "key": "X-Robots-Tag", "value": "noindex, nofollow" } ] }
  ]
}
```

Uma Content-Security-Policy estrita é possível, mas exige listar `fonts.googleapis.com`, `fonts.gstatic.com`, `cdn.jsdelivr.net` e o domínio do seu projeto Supabase; teste antes de publicar.

## Depois de publicar

Siga `docs/CHECKLIST-CLINICA-REAL.md`.
