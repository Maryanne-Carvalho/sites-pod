# Funcionalidades operacionais

Legenda: **Demo** = funciona na demonstração (dados no navegador, mesmas regras) · **Local** = validado no PostgreSQL 16 local que imita o Supabase · **Real** = conferido num Supabase de verdade.
Nenhum item está marcado como “Real”: não houve acesso a um projeto real (ver `docs/LIMITACOES.md`).

| Funcionalidade | Demo | Local (banco) | Observação |
|---|---|---|---|
| Site público (9 páginas), menu, rodapé, WhatsApp, FAQ | ✔ | — | textos em `js/content.js` |
| Ateliê de cores (9 paletas, 5 cores, HEX, restaurar) | ✔ | — | só na demonstração; some no modo real |
| Agendamento on-line com horários livres reais | ✔ | ✔ | duração, intervalo, grade, turnos, pausas, bloqueios, feriados, férias, antecedência, limite de dias, fuso |
| Bloqueio de reserva dupla / simultânea | ✔ | ✔ | restrição `sem_sobreposicao` + trava por clínica |
| Confirmação automática ou por aprovação | ✔ | ✔ | Config › Confirmação |
| Cadastro de cliente com aceite de privacidade | ✔ | ✔ | aceite gravado com data |
| Login, recuperação e nova senha | ✔ (simulado) | — | no real: Supabase Auth (não testado aqui) |
| Meus agendamentos, cancelar, remarcar, pedidos pendentes, desistir do pedido | ✔ | ✔ | prazos e modo direto/aprovação no banco |
| Meus dados: corrigir, exportar (LGPD) | ✔ | ✔ | `export_my_data` |
| Isolamento entre clientes e entre clínicas | (não é segurança) | ✔ | RLS + funções |
| Visão geral com indicadores reais e pedidos | ✔ | ✔ | calculados dos registros |
| Agenda dia/semana/mês, status, remarcar, observação | ✔ | ✔ | observação administrativa (não é prontuário) |
| **Horários com vários turnos e pausas por dia** | ✔ | ✔ | gravação atômica `admin_save_schedule` |
| Bloqueios, feriados, férias | ✔ | ✔ | |
| Novo agendamento manual (mesmas regras) | ✔ | ✔ | |
| Pacientes, anotações administrativas, anonimização | ✔ | ✔ | anonimização ampliada na 004 |
| Relatórios e CSV com proteção de fórmula | ✔ | — | cálculo no navegador a partir dos registros |
| Configurações em 10 abas | ✔ | ✔ | |
| Identidade visual por clínica (salva no banco) | ✔ | ✔ | gatilho valida as cores |
| Acesso administrativo: convidar, listar, revogar, remover | ✔ (convite não aceitável) | ✔ | só proprietária remove |
| Fila de avisos por e-mail | ✔ (nada é enviado) | ✔ | **envio** depende da Edge Function (não testada) |
| Erros de conexão com “tentar de novo”, aviso off-line, limite de 20 s | ✔ | — | |
| Responsivo 320–1920 px e acessibilidade básica | ✔ | — | teste automático 60 |

## Não incluídos (e não simulados)

- Pagamentos on-line.
- Lembretes por WhatsApp/SMS.
- Resumo diário automático por e-mail.
- Prontuário clínico (de propósito: o sistema não foi projetado para dados de saúde).
