# Modelo Avançado — Beatriz Nascimento | Podologia

Template comercial We Lúmen: **site público**, **agendamento on-line**, **Área do cliente** e **painel da podóloga**, com banco de dados e login reais via **Supabase** — ou uma **demonstração** completa que roda só no navegador.

> Todo o conteúdo é fictício: “Beatriz Nascimento”, endereço, telefones, horários exibidos e depoimentos. Não há registro profissional, instituição ou certificação inventados.

## Comece aqui

1. Abra `index.html` no navegador (funciona direto do arquivo, sem servidor).
2. Abra a **Central de demonstração** (`demonstracao.html`) para entrar como podóloga ou como cliente com as contas fictícias:
   - podóloga: `podologa.demo@exemplo.com` / `demonstracao`
   - cliente: `cliente.demo@exemplo.com` / `demonstracao`
3. Experimente as cores no **Ateliê de cores** (botão no canto da tela).

## Dois modos (em `sistema/js/config.js`)

| Modo | Para quê | Segurança |
|---|---|---|
| `"demo"` | conhecer e testar as telas | dados só neste navegador; **não é segurança** |
| `"supabase"` | clínica real | regras no banco (RLS + funções); site usa só a chave **pública** |

Para ligar ao Supabase: `docs/SUPABASE.md`. Para publicar: `docs/VERCEL.md`. Antes de divulgar: `docs/CHECKLIST-CLINICA-REAL.md`.

## Estrutura

```
├─ index, sobre, clinica, servicos, avaliacoes, contato, privacidade (.html)   site público
├─ agendar.html · demonstracao.html                                           agendamento e central de demonstração
├─ cliente/   entrar, cadastro, recuperar-senha, nova-senha, index, meus-dados
├─ admin/     entrar, aceitar-convite, index, agenda, novo-agendamento, pacientes, relatorios, configuracoes
├─ css/       tokens, base, components, assinatura (linguagem visual exclusiva)
├─ js/        content (textos), palettes (9), color-utils, theme-engine, palette-switcher (Ateliê), site
├─ sistema/   css/sistema.css · js/ (telas, api, api-demo, api-supabase, dados-demo, admin-horarios…)
├─ supabase/  migrations/001…004 · setup-clinica-e-admin.sql · functions/enviar-avisos · tests/
├─ tests/     45 funções puras · 50 navegador completo · 60 responsivo e acessibilidade · RESULTADOS.md
└─ docs/      relatórios, mapa da arquitetura, Supabase, Vercel, LGPD, segurança, avisos, fotos, checklist
```

## Personalizar

- **Textos do site:** `js/content.js` (dados demonstrativos, separados dos dados operacionais).
- **Fotos:** `window.PS.photos` em `js/content.js` (ver `docs/FOTOS.md`).
- **Cores:** no modo real, Painel › Configurações › Identidade visual (salvas por clínica no banco). Na demonstração, também pelo Ateliê de cores. O painel administrativo mantém identidade própria.
- **Serviços, horários (vários turnos por dia), regras, avisos e acessos:** pelo painel.

## Testes

- Banco (PostgreSQL local que imita o Supabase): `DB=welumen_test ./supabase/tests/rodar-testes.sh`
- Navegador (Node + Playwright): `node tests/45_funcoes_puras.js`, `node tests/50_navegador_completo.js`, `node tests/60_responsivo_e_acessibilidade.js`
- Supabase real (só em projeto de **teste**): `supabase/tests/90_integracao_supabase_real.mjs` — preparado, ainda não executado.

Resultados e o que cada um prova: `tests/RESULTADOS.md`.

## Não incluídos

Pagamentos on-line, lembretes por WhatsApp/SMS e resumo diário automático. Nenhum deles é simulado.
