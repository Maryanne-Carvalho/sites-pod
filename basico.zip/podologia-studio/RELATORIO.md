# Relatório — Podologia Studio · Modelo Básico v1.0

Reformulação da Learning Page v0.1 para um template comercial, com identidade própria (diferente do Elegance), conteúdo centralizado no `config.js` e Laboratório de cores ampliado.

## 1. Alterações realizadas

### Identidade visual
- **Paleta padrão "Terracota Natural"**: terracota `#A9502F`, areia `#EADBC6`, creme `#F7F0E6`, branco quente `#FFFAF4`, oliva `#6F7445`, grafite `#2B2926`, oliva escuro `#3B3A2A` nas seções escuras.
- **Tipografia**: Instrument Serif (títulos, com itálico de destaque) + Figtree (textos, botões e subtítulos). Fraunces + Manrope saíram deste modelo.
- **Elemento assinatura**: o arco aparece no monograma "CR", nas fotos, nos selos de ícone e no fundo do hero.
- **Botões**: retangulares com cantos suaves, contorno de 1,5px e 52px de altura. Sombras mais leves.
- **Fotos**: um véu muito leve na cor principal deixa qualquer foto "dentro da paleta".
- **Tamanhos de título**: escalam pela largura do site (unidade `cqi`), não da janela, e por isso se ajustam também com o laboratório aberto.
- **Animações**: entrada suave das seções ao rolar, desligada para quem pede menos movimento no sistema.

### Estrutura da página (nova ordem)
1. Cabeçalho (monograma + nome + profissão, menu, botão Agendar)
2. Primeira dobra: "Camila Ribeiro · Podóloga", título autoral ("Podologia que *escuta* antes de cuidar."), apresentação curta, 3 atendimentos em destaque, WhatsApp + Ver serviços, foto com cartão "Primeira consulta"
3. Apresentação da profissional (com citação e um dado honesto, "1 pessoa por vez", no lugar dos "8 anos" inventados)
4. **Benefícios do atendimento** (nova)
5. Serviços em cartões comerciais: duração, "Indicado para" e botão de agendar com o serviço já preenchido na mensagem
6. Diferenciais do consultório (seção escura)
7. Depoimentos com selo "fictício" bem visível
8. Perguntas frequentes (mantido)
9. **Chamada para agendamento** (nova faixa, com passos e telefone)
10. Localização e contato: endereço, ponto de referência, tabela de horários, WhatsApp, e-mail, Instagram, mapa ilustrativo, acessibilidade, "Abrir no mapa"
11. Rodapé (com horários)
12. **Nota do modelo** (camada neutra): "Este site é um modelo. Tudo nele pode ser seu.", com a lista do que pode ser adaptado e um botão para testar as cores

### Conteúdo centralizado (`config.js` + novo `content.js`)
- Saíram do HTML e foram para o `config.js`: nome, profissão, iniciais, slogan, cidade, WhatsApp (número, exibição e mensagens com `{nome}` e `{servico}`), e-mail, Instagram, endereço, referência, acessibilidade, link do mapa, horários, todos os textos do hero, apresentação, benefícios, serviços, diferenciais, depoimentos, FAQ, agendamento e fotos.
- `content.js` monta tudo como texto puro, então o config não consegue "quebrar" a página.
- Lista vazia no config esconde a seção e o link do menu. Campo vazio (ex.: Instagram) esconde o item.
- **Novas chaves de publicação**: `demoMode` (liga WhatsApp, mapa e e-mail de verdade e esconde os avisos "fictício"), `studio.showBar`, `studio.showLab` e `studio.showTemplateNote`. Um site de cliente pronto é só trocar 4 valores.
- `storageKey` próprio do Básico (`podologia-studio:basico:theme`), para não misturar com o Elegance no mesmo navegador.

### Motor de cores (`theme-engine.js`)
- Ajuste manual passou de 3 para **5 cores**: principal, secundária, destaque, **fundo** e **texto**.
- Trocar o fundo recalcula os cartões e o texto secundário. Se o tema virar de claro para escuro (ou o contrário), recalcula também as seções escuras, a cor secundária e o texto.
- Texto escolhido à mão é garantido em **4,5:1 (AA)** e o motor **avisa** quando precisa adaptar uma cor (antes trocava sem avisar, até 7:1).
- Painel de legibilidade passou de 4 para 6 combinações (inclui texto secundário e texto em cartões).
- Novas funções: `clearOverride` (voltar uma cor), `exportPalette` (gerar bloco para `palettes.js`).

### Laboratório de cores
- 9 paletas: as 8 do briefing + Preto & Champagne.
- Campo HEX **editável** ao lado de cada seletor (colar a cor da marca da cliente). Código inválido é sinalizado sem quebrar o site.
- Botão por cor para voltar ao padrão da paleta. Avisos de ajuste automático. Resumo de legibilidade anunciado a leitores de tela sem repetir a cada movimento.
- "Copiar como paleta", além de "Copiar variáveis CSS".
- **Desktop (≥ 1024px)**: painel lateral de 368px; o site se reorganiza ao lado (antes, entre 700 e 1199px, o painel cobria o site).
- **Celular/tablet**: folha de até 60% da tela com puxador e botão **minimizar** (fica só a faixa de paletas, com cerca de 200px). O site ganha espaço extra embaixo enquanto a folha está aberta, e os avisos passam para o topo da tela.
- Isolamento reforçado: `color-scheme: light` fixo (a paleta escura não escurece mais as barras de rolagem e os seletores do painel), sem transição de tema dentro do painel, fonte e seleção próprias.
- Atualização ao vivo agrupada por quadro de animação, e o salvamento no navegador acontece só quando a escolha termina.

### Correções da auditoria
- Foto do hero carrega imediatamente (antes esperava o JavaScript detectar que ela estava na tela).
- "Dra." removido (podóloga não usa título de médica).
- Contorno de foco do botão "Cores" visível em qualquer fundo.
- `overflow-x: clip` no lugar de `hidden` (com reserva para navegadores antigos).
- `aria-hidden="false"` desnecessário removido.

## 2. Funcionalidades preservadas
- Paleta aplicada antes da página aparecer (sem "piscar").
- Cores legíveis calculadas automaticamente (texto sobre botões, links, seções escuras).
- Salvamento das escolhas no navegador.
- Restaurar paleta, Configuração original, Copiar variáveis CSS.
- Navegação por setas na lista de paletas, Esc para fechar, foco devolvido ao botão que abriu.
- Abertura automática do laboratório em telas largas (a menos que tenha sido fechado antes).
- Menu móvel (Esc, clique fora, fecha ao escolher link, fecha ao alargar).
- FAQ acessível com animação e setas do teclado.
- Fotos com quadro alternativo e tempo-limite configurável.
- Modo demonstração do WhatsApp com aviso (agora com o assunto do serviço).
- Link ativo no menu, cabeçalho com sombra ao rolar, voltar ao topo, avisos flutuantes, ano automático no rodapé.
- Layout por container queries (reorganiza com o painel aberto).
- Funciona abrindo o arquivo direto, sem servidor e sem dependências.

## 3. Problemas e limitações encontrados
1. **Fotografias**: este ambiente não tem acesso ao Unsplash, então não foi possível ver, escolher nem validar fotos novas. Mantive as 3 fotos do projeto aprovado, com novos textos alternativos e um véu de cor que as integra à paleta. **Nenhuma delas é comprovadamente de uma podóloga.** Recomendo um ensaio da própria cliente ou fotos licenciadas. A especificação de cada foto está em `assets/img/LEIA-ME.txt`.
2. **Fontes**: Instrument Serif e Figtree não carregaram no ambiente de teste (sem internet). As capturas usaram as fontes de reserva (Palatino/Georgia e fontes do sistema). Vale abrir o site no seu navegador para conferir o visual final com as fontes reais.
3. **Navegadores**: os testes rodaram no Google Chrome (modo automático). Safari, Firefox e celulares reais não foram testados. Em especial, o seletor de cor nativo do iPhone tem visual diferente.
4. **Sem JavaScript**: serviços, horários, depoimentos e FAQ dependem de JavaScript (troca consciente para centralizar tudo no config). Quem navega sem JavaScript vê um aviso. O Google lê páginas com JavaScript normalmente.
5. **Título e descrição** do `<head>` continuam no `index.html` de propósito: prévias de link no WhatsApp não executam JavaScript.
6. Paletas personalizadas com escolhas muito extremas (ex.: cor secundária quase preta num tema claro) continuam legíveis, mas podem ficar pouco harmoniosas. O painel de legibilidade e os avisos orientam o ajuste.

## 4. Resultado dos testes

Executados com Playwright + Google Chrome sobre os arquivos finais, abrindo o `index.html` direto (file://), como a cliente faria. O modo publicado foi testado numa cópia temporária com `demoMode: false` e a camada do estúdio desligada.

**108 de 108 verificações aprovadas.**

Durante o desenvolvimento, a primeira rodada encontrou 2 falhas, ambas corrigidas antes desta rodada final: o puxador da folha do laboratório no celular estava sendo espremido para 7px (corrigido para 32px), e o próprio teste de imagens pulava a seção do meio da página (o carregamento sob demanda funciona como esperado).

| # | Verificação | Resultado |
|---|---|---|
| 1 | Carregamento sem erros no console | ✅ Aprovado |
| 2 | Conteúdo do config renderizado: services (6/6) | ✅ Aprovado |
| 3 | Conteúdo do config renderizado: testimonials (3/3) | ✅ Aprovado |
| 4 | Conteúdo do config renderizado: faq (6/6) | ✅ Aprovado |
| 5 | Conteúdo do config renderizado: benefits (4/4) | ✅ Aprovado |
| 6 | Conteúdo do config renderizado: diffs (4/4) | ✅ Aprovado |
| 7 | Conteúdo do config renderizado: hours (6/6) | ✅ Aprovado |
| 8 | Conteúdo do config renderizado: highlights (3/3) | ✅ Aprovado |
| 9 | Todos os textos ligados ao config preenchidos | ✅ Aprovado |
| 10 | Hero mostra nome e profissão (Camila Ribeiro) | ✅ Aprovado |
| 11 | Apenas um h1 na página | ✅ Aprovado |
| 12 | Sem IDs duplicados | ✅ Aprovado |
| 13 | Endereço montado a partir do config | ✅ Aprovado |
| 14 | Todos os links de navegação apontam para seções existentes | ✅ Aprovado |
| 15 | Clique no menu leva até #servicos | ✅ Aprovado |
| 16 | Clique no menu leva até #contato | ✅ Aprovado |
| 17 | Clique no menu leva até #sobre | ✅ Aprovado |
| 18 | Link ativo do menu acompanha a seção visível | ✅ Aprovado |
| 19 | Botões de WhatsApp em modo demonstração mostram aviso (13 botões) | ✅ Aprovado |
| 20 | Nenhum botão navegou para fora da página | ✅ Aprovado |
| 21 | Botão 'Abrir no mapa' mostra aviso de demonstração | ✅ Aprovado |
| 22 | Botão voltar ao topo aparece e funciona | ✅ Aprovado |
| 23 | Modo publicado: botões abrem wa.me com número do config | ✅ Aprovado |
| 24 | Modo publicado: mensagem leva o nome e o serviço | ✅ Aprovado |
| 25 | Modo publicado: links abrem em nova aba | ✅ Aprovado |
| 26 | Modo publicado: avisos 'fictício' escondidos | ✅ Aprovado |
| 27 | Modo publicado: laboratório, barra e nota do modelo removidos | ✅ Aprovado |
| 28 | Modo publicado: ignora cores salvas e usa a paleta do config | ✅ Aprovado |
| 29 | Modo publicado: mapa e e-mail viram links reais | ✅ Aprovado |
| 30 | Item sem valor no config (Instagram vazio) é escondido | ✅ Aprovado |
| 31 | Modo publicado: sem erros no console | ✅ Aprovado |
| 32 | Laboratório lista 9 paletas (8 pedidas + Preto & Champagne) | ✅ Aprovado |
| 33 | Paleta terracota-natural: aplicada, identificada e com contraste ≥ 4,5 (mín. 5.11) | ✅ Aprovado |
| 34 | Paleta salvia-serena: aplicada, identificada e com contraste ≥ 4,5 (mín. 4.95) | ✅ Aprovado |
| 35 | Paleta rosa-delicado: aplicada, identificada e com contraste ≥ 4,5 (mín. 5.19) | ✅ Aprovado |
| 36 | Paleta lavanda-suave: aplicada, identificada e com contraste ≥ 4,5 (mín. 5.31) | ✅ Aprovado |
| 37 | Paleta oliva-elegante: aplicada, identificada e com contraste ≥ 4,5 (mín. 6.05) | ✅ Aprovado |
| 38 | Paleta coral-moderno: aplicada, identificada e com contraste ≥ 4,5 (mín. 5.25) | ✅ Aprovado |
| 39 | Paleta azul-tranquilo: aplicada, identificada e com contraste ≥ 4,5 (mín. 5.54) | ✅ Aprovado |
| 40 | Paleta chocolate-premium: aplicada, identificada e com contraste ≥ 4,5 (mín. 6.35) | ✅ Aprovado |
| 41 | Paleta preto-champagne: aplicada, identificada e com contraste ≥ 4,5 (mín. 8.11) | ✅ Aprovado |
| 42 | Laboratório mantém visual próprio em todas as paletas (incl. escura) | ✅ Aprovado |
| 43 | Paleta escura liga color-scheme dark no site e o laboratório continua claro | ✅ Aprovado |
| 44 | Seletor 'primary' atualiza o site na hora e mostra o HEX | ✅ Aprovado |
| 45 | Seletor 'secondary' atualiza o site na hora e mostra o HEX | ✅ Aprovado |
| 46 | Seletor 'accent' atualiza o site na hora e mostra o HEX | ✅ Aprovado |
| 47 | Seletor 'background' atualiza o site na hora e mostra o HEX | ✅ Aprovado |
| 48 | Seletor 'text' atualiza o site na hora e mostra o HEX | ✅ Aprovado |
| 49 | Texto muito claro é ajustado para leitura e o painel avisa | ✅ Aprovado |
| 50 | Fundo escuro numa paleta clara recalcula cartões e textos com boa leitura | ✅ Aprovado |
| 51 | Código HEX digitado é aplicado | ✅ Aprovado |
| 52 | Código HEX inválido é sinalizado sem quebrar o site | ✅ Aprovado |
| 53 | Botão de voltar uma cor ao padrão funciona | ✅ Aprovado |
| 54 | Paleta e ajustes continuam aplicados após recarregar a página | ✅ Aprovado |
| 55 | Laboratório reabre como estava (desktop) | ✅ Aprovado |
| 56 | 'Restaurar paleta' remove ajustes e mantém a paleta | ✅ Aprovado |
| 57 | 'Configuração original' volta para Terracota Natural | ✅ Aprovado |
| 58 | 'Copiar variáveis CSS' copia um bloco :root válido | ✅ Aprovado |
| 59 | 'Copiar como paleta' gera bloco para palettes.js | ✅ Aprovado |
| 60 | Setas do teclado trocam de paleta no laboratório | ✅ Aprovado |
| 61 | Esc fecha o laboratório e devolve o foco | ✅ Aprovado |
| 62 | Sem erros no console durante o uso do laboratório | ✅ Aprovado |
| 63 | Celular: laboratório começa fechado | ✅ Aprovado |
| 64 | Celular: menu abre | ✅ Aprovado |
| 65 | Celular: Esc fecha o menu | ✅ Aprovado |
| 66 | Celular: link do menu fecha o menu e rola até a seção | ✅ Aprovado |
| 67 | FAQ abre uma pergunta e fecha a anterior | ✅ Aprovado |
| 68 | FAQ: seta para baixo vai para a próxima pergunta | ✅ Aprovado |
| 69 | Celular: laboratório abre como folha e deixa o site visível acima (506px de 844) | ✅ Aprovado |
| 70 | Celular: site ganha espaço extra embaixo enquanto a folha está aberta | ✅ Aprovado |
| 71 | Celular: troca de paleta aparece na hora na parte visível do site | ✅ Aprovado |
| 72 | Celular: modo minimizado deixa só a faixa de paletas (206px) | ✅ Aprovado |
| 73 | Celular: dá para trocar de paleta no modo minimizado | ✅ Aprovado |
| 74 | Celular: botões com área de toque adequada (≥ 32px; principais ≥ 44px) | ✅ Aprovado |
| 75 | Celular: laboratório fecha e o espaço extra some | ✅ Aprovado |
| 76 | Responsivo 320px: sem rolagem horizontal nem elementos vazando | ✅ Aprovado |
| 77 | Sem erros no console (320px) | ✅ Aprovado |
| 78 | Responsivo 360px: sem rolagem horizontal nem elementos vazando | ✅ Aprovado |
| 79 | Sem erros no console (360px) | ✅ Aprovado |
| 80 | Responsivo 375px: sem rolagem horizontal nem elementos vazando | ✅ Aprovado |
| 81 | Animação de entrada revela o conteúdo ao rolar (375px) | ✅ Aprovado |
| 82 | Sem erros no console (375px) | ✅ Aprovado |
| 83 | Responsivo 414px: sem rolagem horizontal nem elementos vazando | ✅ Aprovado |
| 84 | Sem erros no console (414px) | ✅ Aprovado |
| 85 | Responsivo 600px: sem rolagem horizontal nem elementos vazando | ✅ Aprovado |
| 86 | Sem erros no console (600px) | ✅ Aprovado |
| 87 | Responsivo 768px: sem rolagem horizontal nem elementos vazando | ✅ Aprovado |
| 88 | Sem erros no console (768px) | ✅ Aprovado |
| 89 | Responsivo 820px: sem rolagem horizontal nem elementos vazando | ✅ Aprovado |
| 90 | Sem erros no console (820px) | ✅ Aprovado |
| 91 | Responsivo 1024px: sem rolagem horizontal nem elementos vazando | ✅ Aprovado |
| 92 | Sem erros no console (1024px) | ✅ Aprovado |
| 93 | Responsivo 1024px com laboratório aberto: sem rolagem horizontal nem elementos vazando (site com 656px ao lado do painel) | ✅ Aprovado |
| 94 | Sem erros no console (1024px com laboratório aberto) | ✅ Aprovado |
| 95 | Responsivo 1280px: sem rolagem horizontal nem elementos vazando | ✅ Aprovado |
| 96 | Sem erros no console (1280px) | ✅ Aprovado |
| 97 | Responsivo 1280px com laboratório aberto: sem rolagem horizontal nem elementos vazando (site com 912px ao lado do painel) | ✅ Aprovado |
| 98 | Sem erros no console (1280px com laboratório aberto) | ✅ Aprovado |
| 99 | Responsivo 1440px: sem rolagem horizontal nem elementos vazando | ✅ Aprovado |
| 100 | Animação de entrada revela o conteúdo ao rolar (1440px) | ✅ Aprovado |
| 101 | Sem erros no console (1440px) | ✅ Aprovado |
| 102 | Responsivo 1440px com laboratório aberto: sem rolagem horizontal nem elementos vazando (site com 1072px ao lado do painel) | ✅ Aprovado |
| 103 | Sem erros no console (1440px com laboratório aberto) | ✅ Aprovado |
| 104 | Responsivo 1920px: sem rolagem horizontal nem elementos vazando | ✅ Aprovado |
| 105 | Sem erros no console (1920px) | ✅ Aprovado |
| 106 | Responsivo 1920px com laboratório aberto: sem rolagem horizontal nem elementos vazando (site com 1552px ao lado do painel) | ✅ Aprovado |
| 107 | Sem erros no console (1920px com laboratório aberto) | ✅ Aprovado |
| 108 | Imagens: cada espaço mostra a foto ou o quadro alternativo com descrição | ✅ Aprovado |

Também foram conferidas capturas de tela em 1440px (com e sem laboratório) e 390px (site completo, laboratório aberto e minimizado), além das paletas Preto & Champagne, Azul Tranquilo e Rosa Delicado.
