/* ==========================================================================
   CONFIGURAÇÃO DO SITE — Modelo Básico
   Tudo o que muda de uma cliente para outra fica aqui: identidade,
   contato, endereço, horários, serviços, textos principais, depoimentos,
   perguntas frequentes e imagens. O index.html só tem a estrutura.

   Regras simples para editar:
   - Mantenha as aspas e as vírgulas no fim de cada linha.
   - Para remover um item de uma lista (serviço, pergunta...), apague o
     bloco inteiro entre { e }, incluindo a vírgula depois dele.
   - Textos com *asteriscos* aparecem em itálico colorido (destaque).
   - Ícones disponíveis: foot, nail, layers, leaf, drop, heart, shield,
     user, clock, calendar, sparkle, sun, home, chat.

   Importante: o <title> e a descrição do <head> do index.html também
   precisam ser editados à mão (prévias de link no WhatsApp e no Google
   não leem este arquivo).
   ========================================================================== */

window.PS = window.PS || {};

window.PS.config = {
  /* ---- Modo demonstração ----
     true  → botões de WhatsApp e mapa mostram um aviso em vez de abrir;
             avisos "fictício" ficam visíveis.
     false → botões abrem o WhatsApp/mapa de verdade e os avisos somem. */
  demoMode: true,

  /* ---- Camada de apresentação do modelo (não faz parte do site da cliente) ----
     No site publicado de uma cliente, use showBar: false, showLab: false
     e showTemplateNote: false. */
  studio: {
    showBar: true,
    showLab: true,
    showTemplateNote: true,
    productName: "Podologia Studio",
    modelName: "Modelo Básico",
    version: "v1.0"
  },

  /* ---- Identidade da profissional ---- */
  brand: {
    name: "Camila Ribeiro",
    firstName: "Camila",
    profession: "Podóloga",
    tagline: "Podologia humanizada",
    initials: "CR",
    city: "São Paulo",
    state: "SP"
  },

  /* ---- Contato ----
     whatsapp.number: somente dígitos, com DDI e DDD (ex.: 5511912345678).
     Nas mensagens, {nome} vira o primeiro nome e {servico} o serviço. */
  whatsapp: {
    number: "5511900000000",
    display: "(11) 90000-0000",
    defaultMessage: "Olá, {nome}! Vi seu site e gostaria de agendar uma avaliação.",
    serviceMessage: "Olá, {nome}! Vi seu site e gostaria de agendar: {servico}."
  },

  contact: {
    email: "contato@camilaribeiro.exemplo",
    instagram: { handle: "@camilaribeiro.podologia", url: "" },
    address: {
      street: "Rua das Acácias, 120 — sala 4",
      neighborhood: "Vila Mariana",
      city: "São Paulo",
      state: "SP",
      reference: "A 6 minutos a pé do metrô"
    },
    mapsUrl: "https://www.google.com/maps/search/?api=1&query=Vila+Mariana+S%C3%A3o+Paulo",
    accessibility: "Consultório no térreo, com acesso sem degraus"
  },

  hours: [
    { days: "Segunda a sexta", time: "9h às 19h" },
    { days: "Sábados", time: "9h às 13h" },
    { days: "Domingos e feriados", time: "Fechado" }
  ],

  /* ---- Primeira dobra ---- */
  hero: {
    eyebrow: "Podologia humanizada · Vila Mariana",
    title: "Podologia que *escuta* antes de cuidar.",
    lead: "Sou a Camila, podóloga. No meu consultório, cada atendimento começa por uma conversa sem pressa, para entender o que seus pés estão pedindo e cuidar deles com leveza.",
    highlights: ["Unhas encravadas", "Calos e calosidades", "Pés sensíveis e diabéticos"],
    card: {
      title: "Primeira consulta",
      text: "Avaliação completa e um plano de cuidados para a sua rotina."
    },
    primaryCta: "Agendar pelo WhatsApp",
    secondaryCta: "Ver serviços"
  },

  /* ---- Apresentação da profissional ---- */
  about: {
    eyebrow: "Quem vai cuidar de você",
    title: "Prazer, eu sou a *Camila*.",
    paragraphs: [
      "Escolhi a podologia porque acredito que cuidar dos pés é cuidar da autonomia de cada pessoa: caminhar, trabalhar, passear e viver sem incômodo.",
      "No consultório, atendo uma pessoa por vez, com hora marcada. Explico cada etapa antes de começar e você sai com orientações simples para manter os resultados em casa."
    ],
    quote: "Ninguém precisa sentir vergonha dos próprios pés. Aqui, o cuidado começa pelo acolhimento.",
    checklist: [
      "Atendimento individual, com tempo para conversar",
      "Explicações claras, sem termos difíceis",
      "Orientações por escrito para o cuidado em casa"
    ],
    stat: { number: "1", unit: "pessoa por vez", label: "Atendimento exclusivo, com horário reservado só para você" },
    demoNote: "Perfil fictício criado para demonstração. No site de uma profissional real, formação e registros devem ser informados por ela."
  },

  /* ---- Benefícios para quem é atendido ---- */
  benefits: [
    { icon: "foot", title: "Caminhar sem dor", text: "Alívio de incômodos como unhas encravadas, calos e rachaduras, para voltar à rotina com conforto." },
    { icon: "shield", title: "Prevenção de problemas", text: "Avaliação atenta para perceber cedo o que merece cuidado e evitar que pequenos incômodos voltem." },
    { icon: "leaf", title: "Pele e unhas saudáveis", text: "Cuidados que respeitam a sensibilidade de cada pessoa, com foco em saúde e bem-estar." },
    { icon: "home", title: "Autonomia em casa", text: "Você aprende a cuidar dos pés no dia a dia, com orientações práticas e fáceis de seguir." }
  ],

  /* ---- Serviços ----
     duration é opcional. Para esconder o "Indicado para", deixe forWho vazio (""). */
  services: [
    {
      icon: "foot",
      title: "Avaliação podológica",
      text: "Análise da pele, das unhas e da pisada para entender o que seus pés precisam e definir os próximos cuidados.",
      forWho: "Primeira consulta e acompanhamento",
      duration: "50 min"
    },
    {
      icon: "nail",
      title: "Unhas encravadas",
      text: "Tratamento cuidadoso da unha encravada, com alívio do incômodo e orientação para evitar que volte.",
      forWho: "Dor, vermelhidão ou unha curvada",
      duration: "40 min"
    },
    {
      icon: "layers",
      title: "Calos e calosidades",
      text: "Remoção de calos e áreas de pele endurecida, com dicas de calçado e hidratação para o dia a dia.",
      forWho: "Pele grossa, ardência ao caminhar",
      duration: "40 min"
    },
    {
      icon: "heart",
      title: "Pés sensíveis e diabéticos",
      text: "Atendimento com atenção redobrada para pessoas com diabetes, idosos e gestantes, em complemento ao acompanhamento médico.",
      forWho: "Diabetes, idosos e gestantes",
      duration: "50 min"
    },
    {
      icon: "drop",
      title: "Rachaduras e hidratação",
      text: "Cuidado com ressecamento e fissuras nos calcanhares, com indicação de uma rotina de hidratação adequada.",
      forWho: "Calcanhares ressecados ou fissurados",
      duration: "40 min"
    },
    {
      icon: "sparkle",
      title: "Manutenção preventiva",
      text: "Corte técnico das unhas e revisão periódica para manter os pés saudáveis e confortáveis ao longo do ano.",
      forWho: "Quem quer manter os pés em dia",
      duration: "30 min"
    }
  ],

  /* ---- Diferenciais do consultório ---- */
  differentials: [
    { title: "Consultório próprio e tranquilo", text: "Um ambiente calmo e reservado, pensado para você se sentir à vontade do início ao fim." },
    { title: "Higiene e biossegurança", text: "Instrumentais esterilizados, materiais descartáveis quando indicado e superfícies higienizadas entre os atendimentos." },
    { title: "Hora marcada, sem espera", text: "Seu horário é reservado só para você. Sem fila e sem atendimento corrido." },
    { title: "Acompanhamento depois da consulta", text: "Dúvidas depois do atendimento? É só chamar no WhatsApp para receber orientação." }
  ],

  /* ---- Depoimentos (SEMPRE demonstrativos neste modelo) ----
     Em um site publicado, use apenas relatos reais e autorizados. */
  testimonials: [
    { name: "Ana", detail: "34 anos", text: "Eu adiava a consulta por vergonha. Fui recebida com muita calma, entendi o que estava acontecendo e saí com um passo a passo para cuidar em casa." },
    { name: "Ricardo", detail: "41 anos", text: "Levei minha mãe, que tem os pés bem sensíveis. Gostei da paciência e de como cada etapa foi explicada antes de começar." },
    { name: "Carla", detail: "52 anos", text: "Ambiente limpo, pontualidade e muita atenção. As dicas sobre calçado e hidratação já mudaram a minha rotina." }
  ],

  /* ---- Perguntas frequentes ---- */
  faq: [
    { q: "Qual é a diferença entre podologia e pedicure?", a: "A pedicure tem foco estético. A podologia cuida da saúde dos pés: avalia pele e unhas, trata alterações como calos e unhas encravadas e orienta a prevenção. Os dois atendimentos podem se complementar." },
    { q: "O atendimento dói?", a: "A maioria dos cuidados é tranquila. A sensibilidade varia de pessoa para pessoa, por isso cada etapa é explicada antes e você pode pedir uma pausa a qualquer momento." },
    { q: "Com que frequência devo ir à podóloga?", a: "Depende das necessidades de cada pessoa. Na primeira consulta, a avaliação ajuda a definir um intervalo adequado para o seu caso." },
    { q: "Pessoas com diabetes podem ser atendidas?", a: "Sim. O atendimento é feito com cuidado redobrado e não substitui o acompanhamento médico. Se possível, traga informações sobre o seu tratamento atual." },
    { q: "Como os materiais são higienizados?", a: "Os instrumentais passam por limpeza e esterilização, e materiais descartáveis são usados quando indicado. Você pode perguntar sobre o processo sempre que quiser." },
    { q: "Como faço para agendar?", a: "Pelo WhatsApp. Conte brevemente o que está sentindo e escolha o melhor horário entre as opções disponíveis." }
  ],

  /* ---- Chamada para agendamento ---- */
  booking: {
    title: "Seus pés merecem esse *cuidado*.",
    text: "Agende pelo WhatsApp em poucos minutos. Você conta o que está sentindo e escolhe o melhor horário.",
    steps: ["Envie uma mensagem contando o que sente", "Escolha o dia e o horário disponíveis", "Receba a confirmação e as orientações"]
  },

  /* ---- Imagens ----
     Endereços externos (Unsplash, uso gratuito). Se alguma não carregar,
     o site mostra automaticamente um quadro nas cores da paleta.
     Para usar fotos próprias, coloque os arquivos em assets/img/ e troque
     o "src", ex.: "assets/img/hero.jpg". Veja assets/img/LEIA-ME.txt. */
  images: {
    hero: {
      src: "https://images.unsplash.com/photo-1675159364615-38e1f6b62282?auto=format&fit=crop&w=1000&q=75",
      alt: "Mãos da podóloga cuidando de um pé apoiado sobre toalha branca"
    },
    about: {
      src: "https://images.unsplash.com/photo-1594824476967-48c8b964273f?auto=format&fit=crop&w=900&q=75",
      alt: "Retrato ilustrativo da profissional, sorrindo"
    },
    care: {
      src: "https://images.unsplash.com/photo-1712638932314-e2b185ca0930?auto=format&fit=crop&w=1100&q=75",
      alt: "Ambiente de atendimento tranquilo, com toalhas brancas"
    }
  },

  /* Tempo máximo (ms) para uma imagem carregar antes de mostrar o quadro neutro */
  imageTimeout: 9000,

  /* Paleta usada na primeira visita e no botão "Configuração original" */
  defaultPalette: "terracota-natural",

  /* Chave usada para salvar as escolhas no navegador
     (diferente em cada modelo, para um não interferir no outro) */
  storageKey: "podologia-studio:basico:theme"
};
