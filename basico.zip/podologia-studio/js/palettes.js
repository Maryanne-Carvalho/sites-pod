/* ==========================================================================
   PALETAS PREDEFINIDAS — Modelo Básico
   Cada paleta define 8 cores-base e um raio de borda (personalidade).
   As cores de texto sobre botões, links e seções escuras são calculadas
   automaticamente pelo motor de temas para manter a legibilidade.

   Papel de cada cor:
     primary     cor principal (botões, destaques, links)
     secondary   cor de apoio (faixas e fundos suaves)
     accent      cor de destaque complementar (detalhes, ícones, números)
     background  fundo geral da página
     surface     fundo de cartões (normalmente um pouco mais claro que o fundo)
     text        texto principal
     muted       texto secundário
     deep        fundo das seções escuras e base do rodapé

   Para criar uma nova paleta: copie um bloco, troque id, nome, clima e cores.
   Dica: no Laboratório, "Copiar como paleta" gera um bloco pronto.
   ========================================================================== */

window.PS = window.PS || {};

window.PS.palettes = [
  {
    id: "terracota-natural",
    name: "Terracota Natural",
    mood: "Acolhedor e autoral",
    radius: 14,
    colors: {
      primary: "#a9502f",
      secondary: "#eadbc6",
      accent: "#6f7445",
      background: "#f7f0e6",
      surface: "#fffaf4",
      text: "#2b2926",
      muted: "#655e57",
      deep: "#3b3a2a"
    }
  },
  {
    id: "salvia-serena",
    name: "Sálvia Serena",
    mood: "Natural e tranquilo",
    radius: 18,
    colors: {
      primary: "#56715e",
      secondary: "#e2e8dc",
      accent: "#878a4c",
      background: "#f7f6f0",
      surface: "#fffffb",
      text: "#24302a",
      muted: "#56625a",
      deep: "#2e3c33"
    }
  },
  {
    id: "rosa-delicado",
    name: "Rosa Delicado",
    mood: "Suave e feminino",
    radius: 22,
    colors: {
      primary: "#9d525b",
      secondary: "#efdcd1",
      accent: "#c98f86",
      background: "#fbf7f1",
      surface: "#fffdfa",
      text: "#3a2b2a",
      muted: "#6e5d5a",
      deep: "#4a3033"
    }
  },
  {
    id: "lavanda-suave",
    name: "Lavanda Suave",
    mood: "Calmo e contemporâneo",
    radius: 20,
    colors: {
      primary: "#6f5f9c",
      secondary: "#e8e6ee",
      accent: "#b3a8d3",
      background: "#fafafc",
      surface: "#ffffff",
      text: "#2c2a33",
      muted: "#5f5b69",
      deep: "#34303f"
    }
  },
  {
    id: "oliva-elegante",
    name: "Oliva Elegante",
    mood: "Sóbrio e sofisticado",
    radius: 10,
    colors: {
      primary: "#5b6234",
      secondary: "#ebe0c9",
      accent: "#b49359",
      background: "#faf7ef",
      surface: "#fffdf8",
      text: "#26281c",
      muted: "#5d5f4f",
      deep: "#2e3220"
    }
  },
  {
    id: "coral-moderno",
    name: "Coral Moderno",
    mood: "Leve e luminoso",
    radius: 24,
    colors: {
      primary: "#b54a36",
      secondary: "#f6e6d9",
      accent: "#ef9f8b",
      background: "#fdf8f3",
      surface: "#ffffff",
      text: "#2a2a2c",
      muted: "#655f5b",
      deep: "#2d2d30"
    }
  },
  {
    id: "azul-tranquilo",
    name: "Azul Tranquilo",
    mood: "Clínico e confiável",
    radius: 12,
    colors: {
      primary: "#4a6880",
      secondary: "#e2eaef",
      accent: "#97b3c6",
      background: "#f6f9fa",
      surface: "#ffffff",
      text: "#1d2a35",
      muted: "#526170",
      deep: "#1c3249"
    }
  },
  {
    id: "chocolate-premium",
    name: "Chocolate Premium",
    mood: "Clássico e luxuoso",
    radius: 8,
    colors: {
      primary: "#6b4430",
      secondary: "#efe2cc",
      accent: "#c4a271",
      background: "#faf5ec",
      surface: "#fffcf6",
      text: "#2e221b",
      muted: "#67574c",
      deep: "#3a271d"
    }
  },
  {
    id: "preto-champagne",
    name: "Preto & Champagne",
    mood: "Elegante e noturno",
    radius: 6,
    colors: {
      primary: "#d2bd92",
      secondary: "#2a2724",
      accent: "#e6d6b3",
      background: "#141413",
      surface: "#1d1c1a",
      text: "#f2ede3",
      muted: "#b3ab9e",
      deep: "#26231f"
    }
  }
];
