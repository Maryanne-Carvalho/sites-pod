/* ==========================================================================
   CONTEÚDO A PARTIR DO CONFIG
   Lê js/config.js e preenche o site: identidade, primeira dobra,
   apresentação, benefícios, serviços, diferenciais, depoimentos, FAQ,
   agendamento, contato e rodapé. Todo texto entra como texto puro
   (sem HTML), então o config não consegue "quebrar" a página.
   Roda antes de site.js, que liga os botões e o acordeão.
   ========================================================================== */

(function () {
  "use strict";

  var PS = window.PS;
  var cfg = PS.config || {};
  var root = document.documentElement;

  /* ---------------- Utilitários ---------------- */
  function $(sel, ctx) { return (ctx || document).querySelector(sel); }
  function $$(sel, ctx) { return Array.prototype.slice.call((ctx || document).querySelectorAll(sel)); }

  function get(path) {
    return path.split(".").reduce(function (obj, k) { return obj == null ? undefined : obj[k]; }, cfg);
  }

  function el(tag, className, text) {
    var node = document.createElement(tag);
    if (className) node.className = className;
    if (text != null) node.textContent = text;
    return node;
  }

  /* Texto com *destaque* → <em>destaque</em> (sem interpretar HTML) */
  function setRich(node, str) {
    node.textContent = "";
    String(str || "").split(/\*([^*]+)\*/).forEach(function (part, i) {
      if (!part) return;
      node.appendChild(i % 2 ? el("em", null, part) : document.createTextNode(part));
    });
  }

  function icon(name, extraClass) {
    var id = document.getElementById("i-" + name) ? name : "foot";
    var ns = "http://www.w3.org/2000/svg";
    var svg = document.createElementNS(ns, "svg");
    svg.setAttribute("class", "icon" + (extraClass ? " " + extraClass : ""));
    svg.setAttribute("aria-hidden", "true");
    var use = document.createElementNS(ns, "use");
    use.setAttribute("href", "#i-" + id);
    svg.appendChild(use);
    return svg;
  }

  function list(path) {
    var v = get(path);
    return Array.isArray(v) ? v : [];
  }

  /* Esconde uma seção (e os links do menu para ela) quando a lista está vazia */
  function hideSection(id) {
    var s = document.getElementById(id);
    if (s) s.hidden = true;
    $$('a[href="#' + id + '"]').forEach(function (a) {
      var li = a.closest("li");
      (li || a).hidden = true;
    });
  }

  /* ---------------- Modo demonstração e camada do estúdio ---------------- */
  if (cfg.demoMode === false) root.classList.add("is-live");

  var studio = cfg.studio || {};
  if (studio.showBar === false) $$("[data-studio-bar]").forEach(function (n) { n.remove(); });
  if (studio.showTemplateNote === false) $$("[data-template-note]").forEach(function (n) { n.remove(); });
  $$("[data-studio-product]").forEach(function (n) { n.textContent = studio.productName || ""; });
  $$("[data-studio-model]").forEach(function (n) {
    n.textContent = [studio.modelName, studio.version].filter(Boolean).join(" · ");
  });

  /* ---------------- Ligações simples: data-bind="caminho.no.config" ---------------- */
  $$("[data-bind]").forEach(function (node) {
    var v = get(node.getAttribute("data-bind"));
    if (v == null || v === "") return;
    if (node.hasAttribute("data-rich")) setRich(node, v);
    else node.textContent = v;
  });

  /* Itens com valor vazio no config somem (ex.: instagram sem @) */
  $$("[data-bind-optional]").forEach(function (node) {
    var v = get(node.getAttribute("data-bind-optional"));
    if (!v) node.hidden = true;
  });

  var brand = cfg.brand || {};
  var initials = brand.initials || (brand.name || "").split(/\s+/).map(function (w) { return w[0]; }).slice(0, 2).join("");
  $$("[data-brand-initials]").forEach(function (n) { n.textContent = initials; });
  $$("[data-brand-link]").forEach(function (a) {
    a.setAttribute("aria-label", (brand.name || "") + " — " + (brand.profession || "") + ", voltar ao início");
  });

  /* ---------------- Primeira dobra ---------------- */
  var highlights = $("[data-hero-highlights]");
  if (highlights) {
    list("hero.highlights").forEach(function (h) {
      var li = el("li");
      li.appendChild(icon("check"));
      li.appendChild(document.createTextNode(h));
      highlights.appendChild(li);
    });
  }

  /* ---------------- Apresentação ---------------- */
  var aboutText = $("[data-about-paragraphs]");
  if (aboutText) list("about.paragraphs").forEach(function (p) { aboutText.appendChild(el("p", null, p)); });

  var checklist = $("[data-about-checklist]");
  if (checklist) {
    list("about.checklist").forEach(function (c) {
      var li = el("li");
      li.appendChild(icon("check"));
      li.appendChild(el("span", null, c));
      checklist.appendChild(li);
    });
  }

  /* ---------------- Benefícios ---------------- */
  var benefits = $("[data-benefits]");
  if (benefits) {
    var bl = list("benefits");
    if (!bl.length) hideSection("beneficios");
    bl.forEach(function (b) {
      var li = el("li", "benefit");
      li.setAttribute("data-reveal", "");
      var ic = el("span", "benefit__icon");
      ic.appendChild(icon(b.icon));
      li.appendChild(ic);
      li.appendChild(el("h3", "benefit__title", b.title));
      li.appendChild(el("p", "benefit__text", b.text));
      benefits.appendChild(li);
    });
  }

  /* ---------------- Serviços ---------------- */
  var services = $("[data-services]");
  if (services) {
    var sl = list("services");
    if (!sl.length) hideSection("servicos");
    sl.forEach(function (s) {
      var li = el("li", "card card--interactive service");
      li.setAttribute("data-reveal", "");

      var top = el("div", "service__top");
      var badge = el("span", "icon-badge");
      badge.appendChild(icon(s.icon));
      top.appendChild(badge);
      if (s.duration) {
        var d = el("span", "service__duration");
        d.appendChild(icon("clock"));
        d.appendChild(document.createTextNode(s.duration));
        top.appendChild(d);
      }
      li.appendChild(top);

      li.appendChild(el("h3", null, s.title));
      li.appendChild(el("p", "service__text", s.text));

      if (s.forWho) {
        var who = el("p", "service__for");
        who.appendChild(el("span", null, "Indicado para"));
        who.appendChild(document.createTextNode(s.forWho));
        li.appendChild(who);
      }

      var a = el("a", "link-arrow service__cta", "Agendar este cuidado ");
      a.href = "#contato";
      a.setAttribute("data-whatsapp", "");
      a.setAttribute("data-service", s.title);
      a.setAttribute("aria-label", "Agendar " + s.title + " pelo WhatsApp");
      a.appendChild(icon("arrow"));
      li.appendChild(a);

      services.appendChild(li);
    });
  }

  /* ---------------- Diferenciais ---------------- */
  var diffs = $("[data-differentials]");
  if (diffs) {
    var dl = list("differentials");
    if (!dl.length) hideSection("diferenciais");
    dl.forEach(function (d, i) {
      var li = el("li", "value");
      li.setAttribute("data-reveal", "");
      li.appendChild(el("span", "value__num", String(i + 1).padStart(2, "0")));
      var body = el("div");
      body.appendChild(el("h3", null, d.title));
      body.appendChild(el("p", null, d.text));
      li.appendChild(body);
      diffs.appendChild(li);
    });
  }

  /* ---------------- Depoimentos ---------------- */
  var tgrid = $("[data-testimonials]");
  if (tgrid) {
    var tl = list("testimonials");
    if (!tl.length) hideSection("depoimentos");
    tl.forEach(function (t) {
      var li = el("li", "card testimonial");
      li.setAttribute("data-reveal", "");
      var ns = "http://www.w3.org/2000/svg";
      var mark = document.createElementNS(ns, "svg");
      mark.setAttribute("class", "testimonial__mark");
      mark.setAttribute("viewBox", "0 0 40 32");
      mark.setAttribute("aria-hidden", "true");
      var path = document.createElementNS(ns, "path");
      path.setAttribute("d", "M0 32V19C0 8.5 6 2 16 0l2 4.5C12 6.4 9 10.6 9 16h8v16zm22 0V19C22 8.5 28 2 38 0l2 4.5C34 6.4 31 10.6 31 16h8v16z");
      mark.appendChild(path);
      li.appendChild(mark);

      var quote = el("blockquote", "testimonial__text");
      quote.appendChild(el("p", null, t.text));
      li.appendChild(quote);

      var author = el("div", "testimonial__author");
      var av = el("span", "avatar", (t.name || "?").charAt(0));
      av.setAttribute("aria-hidden", "true");
      author.appendChild(av);
      var who = el("div");
      who.appendChild(el("p", "testimonial__name", t.name + (t.detail ? ", " + t.detail : "")));
      who.appendChild(el("p", "testimonial__meta", cfg.demoMode === false ? "Paciente" : "Depoimento ilustrativo"));
      author.appendChild(who);
      li.appendChild(author);
      tgrid.appendChild(li);
    });
  }

  /* ---------------- Perguntas frequentes ---------------- */
  var acc = $("[data-faq]");
  if (acc) {
    var fl = list("faq");
    if (!fl.length) hideSection("duvidas");
    fl.forEach(function (f, i) {
      var n = i + 1;
      var item = el("div", "accordion__item");
      var h = el("h3");
      var btn = el("button", "accordion__trigger");
      btn.type = "button";
      btn.id = "faq-" + n + "-btn";
      btn.setAttribute("aria-expanded", "false");
      btn.setAttribute("aria-controls", "faq-" + n);
      btn.appendChild(el("span", null, f.q));
      var sign = el("span", "accordion__sign");
      sign.setAttribute("aria-hidden", "true");
      btn.appendChild(sign);
      h.appendChild(btn);
      var panel = el("div", "accordion__panel");
      panel.id = "faq-" + n;
      panel.setAttribute("role", "region");
      panel.setAttribute("aria-labelledby", btn.id);
      panel.hidden = true;
      var inner = el("div");
      inner.appendChild(el("p", null, f.a));
      panel.appendChild(inner);
      item.appendChild(h);
      item.appendChild(panel);
      acc.appendChild(item);
    });
  }

  /* ---------------- Agendamento ---------------- */
  var steps = $("[data-booking-steps]");
  if (steps) {
    list("booking.steps").forEach(function (s, i) {
      var li = el("li");
      li.appendChild(el("span", "steps__num", String(i + 1)));
      li.appendChild(document.createTextNode(s));
      steps.appendChild(li);
    });
  }

  /* ---------------- Contato e endereço ---------------- */
  var addr = (cfg.contact && cfg.contact.address) || {};
  var cityLine = [addr.neighborhood, [addr.city, addr.state].filter(Boolean).join(" – ")].filter(Boolean).join(", ");

  $$("[data-address]").forEach(function (n) {
    n.textContent = "";
    if (addr.street) n.appendChild(document.createTextNode(addr.street));
    if (addr.street && cityLine) n.appendChild(el("br"));
    if (cityLine) n.appendChild(document.createTextNode(cityLine));
  });
  $$("[data-address-short]").forEach(function (n) {
    n.textContent = [addr.neighborhood, addr.city].filter(Boolean).join(", ");
  });

  $$("[data-hours]").forEach(function (box) {
    box.textContent = "";
    list("hours").forEach(function (h) {
      var row = el("li", "hours__row");
      row.appendChild(el("span", "hours__days", h.days));
      row.appendChild(el("span", "hours__time", h.time));
      box.appendChild(row);
    });
  });

  var insta = cfg.contact && cfg.contact.instagram;
  $$("[data-instagram]").forEach(function (n) {
    if (!insta || !insta.handle) { (n.closest("li") || n).hidden = true; return; }
    n.textContent = insta.handle;
    if (n.tagName === "A") {
      if (insta.url) { n.href = insta.url; n.target = "_blank"; n.rel = "noopener"; }
      else n.removeAttribute("href");
    }
  });

  $$("[data-email-link]").forEach(function (a) {
    var email = cfg.contact && cfg.contact.email;
    if (!email) { (a.closest("li") || a).hidden = true; return; }
    a.textContent = email;
    if (cfg.demoMode === false) a.href = "mailto:" + email;
    else a.removeAttribute("href");
  });

  $$("[data-year]").forEach(function (n) { n.textContent = String(new Date().getFullYear()); });

  PS.content = { ready: true, get: get };
})();
