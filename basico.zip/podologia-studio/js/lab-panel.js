/* ==========================================================================
   LABORATÓRIO DE CORES — interface
   Monta a lista de paletas, os seletores manuais (5 cores, com HEX
   editável) e o painel de legibilidade. Conversa apenas com PS.theme.
   Para desligar no site publicado: config.studio.showLab = false.
   ========================================================================== */

(function () {
  "use strict";

  var PS = window.PS;
  var theme = PS.theme;
  var C = PS.color;
  var palettes = PS.palettes;
  var config = PS.config;
  var root = document.documentElement;

  var lab = document.querySelector("[data-lab]");
  var fab = document.querySelector(".lab-fab");
  var openers = Array.prototype.slice.call(document.querySelectorAll("[data-lab-open]"));

  /* ---- Laboratório desligado: remove tudo que pertence a ele ---- */
  if (config.studio && config.studio.showLab === false) {
    if (lab) lab.remove();
    if (fab) fab.remove();
    openers.forEach(function (o) { o.remove(); });
    return;
  }

  var list = document.querySelector("[data-palette-list]");
  var pickersBox = document.querySelector("[data-pickers]");
  var status = document.querySelector("[data-lab-status]");
  var customBadge = document.querySelector("[data-custom-badge]");
  var notesBox = document.querySelector("[data-lab-notes]");
  var contrastList = document.querySelector("[data-contrast-list]");
  var contrastSummary = document.querySelector("[data-contrast-summary]");
  var fabSwatches = document.querySelector("[data-fab-swatches]");
  var closeBtn = document.querySelector("[data-lab-close]");
  var compactBtn = document.querySelector("[data-lab-compact]");
  var grip = document.querySelector("[data-lab-grip]");
  var LAB_KEY = config.storageKey + ":lab-open";
  var sheetQuery = window.matchMedia("(max-width: 1023.98px)");

  if (!lab || !list) return;

  /* ---------------- Lista de paletas ---------------- */
  var options = palettes.map(function (p) {
    var btn = document.createElement("button");
    btn.type = "button";
    btn.className = "palette-option";
    btn.setAttribute("role", "radio");
    btn.setAttribute("aria-checked", "false");
    btn.setAttribute("tabindex", "-1");
    btn.dataset.palette = p.id;

    var sw = document.createElement("span");
    sw.className = "palette-option__swatches";
    sw.setAttribute("aria-hidden", "true");
    [p.colors.primary, p.colors.accent, p.colors.secondary, p.colors.background].forEach(function (c) {
      var i = document.createElement("i");
      i.style.background = c;
      sw.appendChild(i);
    });

    var name = document.createElement("span");
    name.className = "palette-option__name";
    name.textContent = p.name;
    var mood = document.createElement("span");
    mood.className = "palette-option__mood";
    mood.textContent = p.mood;
    name.appendChild(mood);

    var check = document.createElement("span");
    check.className = "palette-option__check";
    check.setAttribute("aria-hidden", "true");
    check.innerHTML = '<svg class="icon"><use href="#i-check"/></svg>';

    btn.appendChild(sw);
    btn.appendChild(name);
    btn.appendChild(check);

    btn.addEventListener("click", function () { selectPalette(p.id, true); });
    list.appendChild(btn);
    return btn;
  });

  function selectPalette(id, announce) {
    var current = theme.getState();
    if (current && current.palette.id === id && !current.customized) {
      if (announce) PS.ui.toast("“" + current.palette.name + "” já está aplicada.");
      return;
    }
    var result = theme.setPalette(id);
    if (announce) PS.ui.toast("Paleta “" + result.palette.name + "” aplicada ao site.");
  }

  // Navegação por setas dentro do grupo de opções (padrão de radiogroup)
  list.addEventListener("keydown", function (event) {
    var keys = ["ArrowRight", "ArrowDown", "ArrowLeft", "ArrowUp", "Home", "End"];
    if (keys.indexOf(event.key) === -1) return;
    event.preventDefault();
    var index = options.indexOf(document.activeElement);
    if (index < 0) index = 0;
    var next = index;
    if (event.key === "ArrowRight" || event.key === "ArrowDown") next = (index + 1) % options.length;
    if (event.key === "ArrowLeft" || event.key === "ArrowUp") next = (index - 1 + options.length) % options.length;
    if (event.key === "Home") next = 0;
    if (event.key === "End") next = options.length - 1;
    options[next].focus();
    options[next].scrollIntoView({ block: "nearest", inline: "nearest" });
    selectPalette(options[next].dataset.palette, false);
  });

  /* ---------------- Seletores manuais ---------------- */
  var HINTS = {
    primary: "Botões e destaques",
    secondary: "Faixas e fundos suaves",
    accent: "Detalhes, ícones e números",
    background: "Fundo da página",
    text: "Títulos e textos"
  };

  var pickers = theme.editable.map(function (key) {
    var row = document.createElement("div");
    row.className = "picker";
    var id = "lab-pk-" + key;
    var label = theme.labels[key];
    row.innerHTML =
      '<input type="color" id="' + id + '">' +
      '<label class="picker__name" for="' + id + '"></label>' +
      '<input class="picker__hex" type="text" inputmode="text" maxlength="7" spellcheck="false" autocomplete="off">' +
      '<button class="picker__reset" type="button" hidden><svg class="icon" aria-hidden="true"><use href="#i-reset"/></svg></button>';
    var nameEl = row.querySelector(".picker__name");
    nameEl.textContent = label;
    var small = document.createElement("small");
    small.textContent = HINTS[key];
    nameEl.appendChild(small);

    var color = row.querySelector('input[type="color"]');
    var hex = row.querySelector(".picker__hex");
    var reset = row.querySelector(".picker__reset");
    hex.setAttribute("aria-label", "Código HEX — " + label);
    reset.setAttribute("aria-label", "Voltar " + label.toLowerCase() + " ao padrão da paleta");
    reset.title = "Voltar ao padrão da paleta";
    pickersBox.appendChild(row);

    // Atualização ao vivo, agrupada por quadro de animação
    var pending = null;
    var frame = 0;
    function liveApply(value) {
      pending = value;
      if (frame) return;
      frame = window.requestAnimationFrame(function () {
        frame = 0;
        theme.setOverride(key, pending, { animate: false, save: false });
      });
    }

    color.addEventListener("input", function () { liveApply(color.value); });
    color.addEventListener("change", function () {
      theme.setOverride(key, color.value, { animate: false });
      PS.ui.toast(label + " ajustada para " + color.value.toUpperCase() + ".");
    });

    function commitHex(announce) {
      var v = C.normalizeHex(hex.value);
      if (!v) {
        hex.setAttribute("aria-invalid", "true");
        if (announce) PS.ui.toast("Use um código como #A9502F.");
        return;
      }
      hex.removeAttribute("aria-invalid");
      theme.setOverride(key, v, { animate: false });
      if (announce) PS.ui.toast(label + " ajustada para " + v.toUpperCase() + ".");
    }

    hex.addEventListener("input", function () {
      var raw = hex.value.trim();
      if (raw && raw[0] !== "#") raw = "#" + raw;
      if (/^#[0-9a-f]{6}$/i.test(raw)) {
        hex.removeAttribute("aria-invalid");
        liveApply(raw);
      }
    });
    hex.addEventListener("keydown", function (e) {
      if (e.key === "Enter") { e.preventDefault(); commitHex(true); }
    });
    hex.addEventListener("change", function () { commitHex(false); });
    hex.addEventListener("blur", function () {
      // devolve o valor válido atual se o campo ficou com algo incompleto
      if (hex.getAttribute("aria-invalid") === "true") {
        hex.removeAttribute("aria-invalid");
        render(theme.getState());
      }
    });

    reset.addEventListener("click", function () {
      theme.clearOverride(key, { animate: true });
      PS.ui.toast(label + " voltou ao padrão da paleta.");
      color.focus();
    });

    return { key: key, color: color, hex: hex, reset: reset };
  });

  /* ---------------- Ações ---------------- */
  lab.querySelectorAll("[data-action]").forEach(function (btn) {
    btn.addEventListener("click", function () {
      var action = btn.getAttribute("data-action");
      var r;
      if (action === "restore") {
        var st = theme.getState();
        if (!st.customized) {
          PS.ui.toast("A paleta “" + st.palette.name + "” já está sem ajustes.");
          return;
        }
        r = theme.restore();
        PS.ui.toast("Ajustes removidos. Paleta “" + r.palette.name + "” restaurada.");
      }
      if (action === "original") {
        r = theme.resetOriginal();
        PS.ui.toast("Configuração original restaurada: “" + r.palette.name + "”.");
      }
      if (action === "copy-css") copyText(theme.exportCss(), "Variáveis CSS copiadas. Cole em css/tokens.css.");
      if (action === "copy-palette") copyText(theme.exportPalette(), "Paleta copiada. Cole em js/palettes.js.");
    });
  });

  function copyText(text, okMessage) {
    function done() { PS.ui.toast(okMessage); }
    function fallback() {
      var ta = document.createElement("textarea");
      ta.value = text;
      ta.setAttribute("readonly", "");
      ta.style.position = "fixed";
      ta.style.opacity = "0";
      document.body.appendChild(ta);
      ta.select();
      var ok = false;
      try { ok = document.execCommand("copy"); } catch (e) { ok = false; }
      document.body.removeChild(ta);
      if (ok) done();
      else PS.ui.toast("Não foi possível copiar automaticamente neste navegador.");
    }
    if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard.writeText(text).then(done, fallback);
    } else {
      fallback();
    }
  }

  /* ---------------- Atualização da interface ---------------- */
  var lastContrastSig = "";
  var summaryTimer = null;

  function render(state) {
    if (!state) return;

    options.forEach(function (btn) {
      var selected = btn.dataset.palette === state.palette.id;
      btn.setAttribute("aria-checked", selected ? "true" : "false");
      btn.setAttribute("tabindex", selected ? "0" : "-1");
    });

    if (status) status.textContent = state.palette.name + (state.customized ? " · ajustada" : "");
    if (customBadge) customBadge.hidden = !state.customized;

    pickers.forEach(function (p) {
      var value = state.overrides[p.key] || state.colors[p.key];
      if (document.activeElement !== p.color) p.color.value = value;
      if (document.activeElement !== p.hex) p.hex.value = value.toUpperCase();
      p.reset.hidden = !state.overrides[p.key];
    });

    if (notesBox) {
      notesBox.innerHTML = "";
      (state.notes || []).forEach(function (n) {
        var li = document.createElement("li");
        li.textContent = n.message;
        notesBox.appendChild(li);
      });
    }

    var sig = state.checks.map(function (c) { return c.fg + c.bg; }).join("|");
    if (contrastList && sig !== lastContrastSig) {
      lastContrastSig = sig;
      contrastList.innerHTML = "";
      state.checks.forEach(function (chk) {
        var li = document.createElement("li");
        li.className = "contrast-item";
        li.innerHTML =
          '<span class="contrast-item__sample" aria-hidden="true">Aa</span>' +
          '<span class="contrast-item__name"></span>' +
          '<span class="contrast-item__ratio"></span>' +
          '<span class="contrast-item__grade grade--' + chk.grade.key + '"></span>';
        var sample = li.querySelector(".contrast-item__sample");
        sample.style.background = chk.bg;
        sample.style.color = chk.fg;
        li.querySelector(".contrast-item__name").textContent = chk.name;
        li.querySelector(".contrast-item__ratio").textContent = chk.ratio.toFixed(1).replace(".", ",") + ":1";
        li.querySelector(".contrast-item__grade").textContent = chk.grade.label;
        contrastList.appendChild(li);
      });

      // Resumo anunciado a leitores de tela, sem repetir a cada movimento do seletor
      clearTimeout(summaryTimer);
      summaryTimer = setTimeout(function () {
        var okCount = state.checks.filter(function (c) { return c.ratio >= 4.5; }).length;
        if (contrastSummary) {
          contrastSummary.textContent = okCount === state.checks.length
            ? "Todas as " + okCount + " combinações com boa leitura."
            : okCount + " de " + state.checks.length + " combinações com boa leitura. Ajuste as cores marcadas.";
          contrastSummary.style.color = okCount === state.checks.length ? "#1f7a45" : "#8a5a00";
        }
      }, 500);
    }

    if (fabSwatches) {
      fabSwatches.innerHTML = "";
      ["primary", "accent", "secondary"].forEach(function (k) {
        var i = document.createElement("i");
        i.style.background = state.colors[k];
        fabSwatches.appendChild(i);
      });
    }
  }

  document.addEventListener("ps:themechange", function (e) { render(e.detail); });
  render(theme.getState());

  /* ---------------- Abrir, fechar e minimizar ---------------- */
  var lastOpener = null;
  var closeTimer = null;

  function rememberOpen(value) {
    try { localStorage.setItem(LAB_KEY, value ? "1" : "0"); } catch (e) { /* sem armazenamento */ }
  }

  function setOpenersExpanded(value) {
    openers.forEach(function (o) { o.setAttribute("aria-expanded", value ? "true" : "false"); });
  }

  // Altura da folha (celular) → espaço extra no fim do site
  function syncSheetHeight() {
    var isSheet = sheetQuery.matches;
    root.classList.toggle("lab-sheet", isSheet);
    var h = isSheet && !lab.hidden ? Math.round(lab.getBoundingClientRect().height) : 0;
    root.style.setProperty("--lab-sheet-h", h + "px");
  }

  if ("ResizeObserver" in window) new ResizeObserver(syncSheetHeight).observe(lab);
  if (sheetQuery.addEventListener) sheetQuery.addEventListener("change", syncSheetHeight);
  else if (sheetQuery.addListener) sheetQuery.addListener(syncSheetHeight);

  function setCompact(value) {
    lab.classList.toggle("is-compact", value);
    if (compactBtn) {
      compactBtn.setAttribute("aria-pressed", value ? "true" : "false");
      compactBtn.setAttribute("aria-label", value ? "Expandir laboratório" : "Minimizar laboratório");
      compactBtn.title = value ? "Expandir" : "Minimizar e ver mais do site";
    }
    if (value) {
      var sel = list.querySelector('[aria-checked="true"]');
      if (sel) sel.scrollIntoView({ block: "nearest", inline: "center" });
    }
    syncSheetHeight();
  }

  if (compactBtn) compactBtn.addEventListener("click", function () { setCompact(!lab.classList.contains("is-compact")); });
  if (grip) grip.addEventListener("click", function () { setCompact(!lab.classList.contains("is-compact")); });

  function openLab(opener, moveFocus) {
    clearTimeout(closeTimer);
    lastOpener = opener || null;
    lab.hidden = false;
    lab.classList.add("is-entering");
    void lab.offsetWidth;
    lab.classList.remove("is-entering");
    root.classList.add("lab-open");
    setOpenersExpanded(true);
    rememberOpen(true);
    syncSheetHeight();
    if (moveFocus) {
      var selected = list.querySelector('[aria-checked="true"]') || options[0];
      selected.focus({ preventScroll: true });
    }
  }

  function closeLab() {
    if (lab.hidden) return;
    lab.classList.add("is-entering");
    root.classList.remove("lab-open");
    setOpenersExpanded(false);
    rememberOpen(false);
    closeTimer = setTimeout(function () {
      lab.hidden = true;
      syncSheetHeight();
    }, 330);
    var target = lastOpener && lastOpener.offsetParent !== null ? lastOpener : fab;
    if (target && lab.contains(document.activeElement)) target.focus({ preventScroll: true });
  }

  openers.forEach(function (o) {
    o.addEventListener("click", function () {
      if (!root.classList.contains("lab-open")) openLab(o, true);
      else closeLab();
    });
  });

  if (closeBtn) closeBtn.addEventListener("click", closeLab);

  document.addEventListener("keydown", function (event) {
    if (event.key === "Escape" && !lab.hidden && lab.contains(document.activeElement)) closeLab();
  });

  // Abre o laboratório a partir de qualquer link/botão com data-lab-trigger (ex.: nota do modelo)
  document.querySelectorAll("[data-lab-trigger]").forEach(function (t) {
    t.addEventListener("click", function (e) {
      e.preventDefault();
      if (!root.classList.contains("lab-open")) openLab(t, true);
    });
  });

  PS.lab = { open: function () { openLab(null, false); }, close: closeLab, compact: setCompact };

  // Em telas largas, o painel começa aberto (a menos que tenha sido fechado antes).
  // Em telas menores ele fica recolhido ao carregar, para não cobrir o site.
  var stored = null;
  try { stored = localStorage.getItem(LAB_KEY); } catch (e) { stored = null; }
  var wide = window.matchMedia("(min-width: 1200px)").matches;
  syncSheetHeight();
  if (wide && stored !== "0") openLab(null, false);
})();
