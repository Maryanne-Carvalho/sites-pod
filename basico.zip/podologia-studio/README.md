# Podologia Studio — Modelo Básico (v1.0)

Template comercial de site para podólogas, com identidade própria (terracota, Instrument Serif + Figtree) e um **Laboratório de cores** para a cliente ver a própria marca aplicada em tempo real.

A profissional "Camila Ribeiro", os depoimentos, o endereço e os contatos são **fictícios**.

## Como abrir

1. Descompacte a pasta `podologia-studio`.
2. Dê dois cliques em `index.html` (Chrome, Edge, Firefox ou Safari atualizados).

Não precisa de servidor nem de instalação. Com internet, carregam as fontes (Google Fonts) e as fotos (Unsplash). Sem internet, o site usa fontes do sistema e quadros nas cores da paleta no lugar das fotos.

## Estrutura

```
podologia-studio/
├── index.html            Estrutura do site + painel do laboratório (sem textos da cliente)
├── README.md             Este guia
├── RELATORIO.md          Relatório das alterações e dos testes da v1.0
├── assets/img/           Fotos próprias da cliente (veja LEIA-ME.txt)
├── css/
│   ├── tokens.css        Variáveis: cores, tipografia, espaços, raios, sombras
│   ├── base.css          Reset, tipografia e utilitários
│   ├── components.css    Botões, cartões, selos, mídia com fallback, FAQ, avisos
│   ├── sections.css      Layout de cada seção (responsivo via container queries)
│   └── lab.css           Visual do Laboratório de cores (neutro, separado do site)
└── js/
    ├── config.js         ★ TUDO o que muda por cliente: nome, contato, horários, serviços, textos, fotos
    ├── palettes.js       As 9 paletas predefinidas
    ├── color-utils.js    Cálculo de contraste e mistura de cores
    ├── theme-engine.js   Aplica a paleta e calcula cores legíveis automaticamente
    ├── content.js        Preenche o site com os dados do config.js
    ├── site.js           Menu, FAQ, imagens, WhatsApp, mapa, voltar ao topo, animações
    └── lab-panel.js      Interface do Laboratório de cores
```

## Adaptar para uma cliente (passo a passo)

1. **`js/config.js`**: troque nome, profissão, WhatsApp, e-mail, Instagram, endereço, horários, textos do hero e da apresentação, benefícios, serviços, diferenciais e perguntas frequentes. Textos entre `*asteriscos*` aparecem em itálico colorido.
2. **Cores**: abra o site, escolha ou ajuste as cores no Laboratório e então:
   - para fixar a paleta: **"Copiar variáveis CSS"** → cole em `css/tokens.css` (blocos "Cores-base" e "Cores calculadas"); **ou**
   - **"Copiar como paleta"** → cole em `js/palettes.js` e coloque o `id` em `defaultPalette` no `config.js`.
3. **Fotos**: coloque os arquivos em `assets/img/` e troque os `src` em `config.images`.
4. **`index.html`**: edite à mão o `<title>` e a `<meta name="description">`. Prévias de link no WhatsApp e no Google leem só essas linhas.
5. **Depoimentos**: use apenas relatos reais e autorizados pela paciente.

## Publicar o site de uma cliente

No `config.js`:

```js
demoMode: false,          // botões abrem WhatsApp e mapa de verdade; avisos "fictício" somem
studio: {
  showBar: false,         // tira a barra escura "Podologia Studio" do topo
  showLab: false,         // tira o Laboratório de cores (e ignora cores salvas no navegador)
  showTemplateNote: false // tira a nota "Este site é um modelo" do fim da página
}
```

No `index.html`, remova também `<meta name="robots" content="noindex">` para o Google poder indexar o site.

## Paletas incluídas

Terracota Natural (padrão) · Sálvia Serena · Rosa Delicado · Lavanda Suave · Oliva Elegante · Coral Moderno · Azul Tranquilo · Chocolate Premium · Preto & Champagne (escura).

Todas passam no contraste WCAG AA (4,5:1) em texto, texto secundário, cartões, botões, links e seções escuras.

## Laboratório de cores

- 9 paletas, com a selecionada marcada.
- Ajuste manual de 5 cores (principal, secundária, destaque, fundo, texto), com seletor e campo HEX editável.
- Atualização instantânea do site inteiro.
- Cores escolhidas à mão são adaptadas automaticamente quando usadas em textos, e o painel avisa quando isso acontece.
- Painel de legibilidade com 6 combinações.
- Restaurar paleta, voltar uma cor específica, configuração original, copiar CSS e copiar como paleta.
- As escolhas ficam salvas no navegador e continuam aplicadas ao recarregar a página.
- Desktop (a partir de 1024px): painel lateral, com o site se reorganizando ao lado. Celular e tablet: folha inferior com modo minimizado (só a faixa de paletas), para ver o site mudando enquanto escolhe.
