# Relatório técnico — Elegance Podologia · modelo intermediário v2.0

Reformulação completa do modelo Elegance: nova marca e profissional fictício, identidade visual própria (diferente do Podologia Studio Básico), as 6 páginas reconstruídas, conteúdo centralizado e um personalizador de cores redesenhado, com persistência entre as páginas.

## 1. Auditoria inicial (antes das alterações)

- **Estrutura**: 6 páginas HTML independentes. Cabeçalho, rodapé e listas são montados por `js/elegance.js` a partir de `js/content.js`. Motor de cores próprio (`js/theme.js`) com persistência via `localStorage` + `window.name`. Dois arquivos CSS (`elegance.css`, `pages.css`). Sem dependências e sem etapa de build.
- **Teste de base** (Chrome automático, 6 páginas em 375 e 1440px): sem erros no console e sem rolagem horizontal.
- **Problemas encontrados**:
  1. Identidade ainda feminina e com a marca "Podologia Studio" ("Dra. Marina Oliveira"), igual à da antiga Learning Page.
  2. Personalizador com 8 paletas antigas e só 2 cores editáveis (principal e destaque), sem campo HEX, sem restaurar por cor e sem avisos de correção.
  3. Link "Comparar com a página básica" apontando para fora da pasta (`../../index.html`): quebrado quando o modelo é entregue sozinho.
  4. Serviços sem o campo "Para quem pode ser indicado"; galeria sem filtros.
  5. Botões de WhatsApp em modo demonstração dependiam do número estar vazio. Não havia uma chave única para publicar e esconder os avisos.

## 2. Alterações realizadas

### Marca e conteúdo
- Profissional fictício **Rafael Mendes, podólogo**, e marca **Elegance Podologia** (Pinheiros, São Paulo). "Podologia Studio" deixou de aparecer no site; continua apenas como nome do produto na documentação.
- Todos os textos foram reescritos no masculino e com o novo posicionamento: técnico, contemporâneo e humanizado.
- História, trajetória, formação, números e avaliações estão marcados como demonstrativos. Formação diz "instituição a ser informada pelo profissional". Nenhum registro, instituição ou certificação real foi inventado.
- Serviços: os 6 originais foram mantidos, com o novo campo **"Para quem pode ser indicado"**. Nenhuma promessa de cura, e avisos de que a podologia não substitui o médico (no rodapé, nos serviços e no FAQ).

### Identidade visual
- **Paleta padrão Azul-Petróleo**: `#174C57` principal, `#12343D` seções escuras, `#B77B54` cobre, `#F4F7F5` branco gelo, `#E9E5DA` marfim (faixas), `#29383B` grafite azulado (texto). Contraste conferido: texto 11,3:1, botões 9,5:1, links 8,8:1. O `#A9BEC2` (azul acinzentado) não entrou como cor fixa, porque os textos secundários sobre as seções escuras já são calculados nesse tom (`#C2CCCD`) para garantir contraste.
- **Tipografia**: **Bodoni Moda** (títulos editoriais, itálico de destaque em cobre) + **Hanken Grotesk** (textos). É diferente do Básico (Instrument Serif + Figtree) e da dupla anterior do Elegance.
- **Linguagem gráfica**:
  - Formas e marca: cantos retos (2 a 8px), filetes finos, monograma "E" em moldura quadrada com um ponto de cobre.
  - Rótulos e grades: rótulos numerados no estilo editorial ("01 — O profissional"), grade fina de fundo e molduras deslocadas.
  - Composição: assimétrica, com colunas fixas que acompanham a rolagem.
- **Microinterações**:
  - Botões com preenchimento que desliza no hover.
  - Setas que avançam ao passar o mouse.
  - Zoom suave nas fotos.
  - Títulos que viram itálico ao passar o mouse.
  - Entrada suave das seções ao rolar, desligada para quem pede menos movimento no sistema.

### Páginas
- **Início**:
  1. Hero assimétrico: nome e profissão em destaque, título autoral "Podologia de *precisão*, com tempo para ouvir.", retrato masculino, 3 atendimentos principais, WhatsApp + Serviços, barra de endereço e horário.
  2. Apresentação do profissional.
  3. Serviços em destaque (grade escalonada).
  4. Clínica (seção escura com mosaico de fotos).
  5. Diferenciais.
  6. Etapas do atendimento.
  7. Avaliações demonstrativas.
  8. Chamada para agendamento.
  9. Índice das páginas internas.
- **Sobre mim**: apresentação com retrato, história (com capitular), citação em destaque, filosofia sobre foto ampla, linha do tempo horizontal com marcadores em losango (vertical no celular), formação, valores e diferenciais.
- **A clínica**: foto ampla com título sobreposto, cartão de horários fixo, 3 espaços alternados, **galeria com filtros por ambiente**, ampliação com setas, teclado, gesto de deslizar no celular e foco preso na janela, biossegurança em etapas, experiência e **informações úteis** (pontualidade, acessibilidade, estacionamento, pagamento).
- **Serviços**: índice lateral fixo que acompanha a leitura. Cada serviço tem descrição, objetivo, como funciona, para quem é indicado, "antes de agendar" e botão de WhatsApp com o serviço já na mensagem.
- **Avaliações**: depoimento em destaque (bloco escuro com aspas grandes), mosaico em colunas, espaço preparado para avaliações reais e chave `reviewsAreReal`.
- **Contato**: hero com WhatsApp e passos, 6 cartões (WhatsApp, telefone, e-mail, endereço, horários, redes sociais), endereço + mapa (espaço reservado ou mapa incorporado), FAQ e botão "Abrir no mapa".

### Conteúdo centralizado (`js/content.js`)
- Ficaram centralizados: marca, profissional, slogan, cidade/bairro, apresentação, história, formação, valores, números, serviços, fotos (com `id` do Unsplash ou `src` local e enquadramento opcional), depoimentos, FAQ, contato, endereço, mapa, horários, redes sociais e informações úteis.
- **Publicação com 4 chaves**: `site.demoMode` (contatos reais e avisos escondidos), `studio.showBar`, `studio.showCustomizer`, `studio.showTemplateNote`. Opcional: `studio.compareUrl`, que substitui o link quebrado de comparação.
- Mensagens do WhatsApp com `{nome}` e `{servico}`. Redes sociais sem URL aparecem só na demonstração. Telefone e e-mail viram links clicáveis apenas no site publicado.

### Motor de cores (`js/theme.js`)
- **5 cores editáveis**: principal, secundária, destaque, fundo e texto. Trocar o fundo recalcula cartões, textos e seções escuras.
- Contraste mínimo AA (4,5:1) garantido nos textos, com avisos quando uma cor é adaptada. São 6 verificações de legibilidade.
- Mantidos: persistência em `localStorage` + `window.name` e sincronização entre abas. Novo: o site publicado ignora cores salvas.
- Novas funções: restaurar uma cor e exportar paleta. A chave de salvamento passou a ser `...:elegance:theme:v2`.

### Ateliê de cores (`js/customizer.js` + `css/customizer.css`, novos)
- Visual neutro próprio (cabeçalho escuro, fonte do sistema, rótulos em fonte monoespaçada), isolado da paleta do site, inclusive na paleta escura.
- **Abas**: Paletas (9, em lista com amostra de 4 cores) · Ajuste fino (5 seletores + HEX editável + restaurar cada cor + avisos) · Legibilidade (6 verificações WCAG com resumo).
- Ações: restaurar paleta, configuração original, copiar CSS, copiar paleta.
- **Entre páginas**: a paleta segue em todas, e o painel lembra se estava aberto e em qual aba.
- **Desktop**: painel flutuante, com o site navegável ao lado. **Celular**: folha de até 64% da tela, com modo minimizado (só a faixa de paletas) e espaço extra no fim da página.

### Correções de acessibilidade e responsividade
- Menu móvel em tela cheia com links numerados. Corrigido: o `backdrop-filter` do cabeçalho prendia o menu dentro dele.
- Estados de foco visíveis em todos os elementos. Alvos de toque de no mínimo 32px (principais com 44 a 58px). Botões quebram linha em telas muito estreitas.
- Fotos com quadro alternativo descrito para leitores de tela. Galeria e FAQ navegáveis por teclado.

## 3. Funcionalidades preservadas
- As 6 páginas, com cabeçalho, rodapé, trilha de navegação e "página anterior/próxima".
- Conteúdo inteiro vindo do `content.js`.
- Paleta aplicada antes da página aparecer, sem "piscar".
- Persistência entre páginas com reserva via `window.name` e sincronização entre abas.
- Restaurar paleta e configuração original.
- Cálculo automático de cores legíveis.
- Galeria com ampliação, setas, Esc e foco preso.
- FAQ acessível.
- Índice de serviços que acompanha a leitura.
- Fotos com quadro alternativo e tempo-limite.
- Avisos de demonstração.
- Voltar ao topo e aviso flutuante.
- Âncoras entre páginas (ex.: `servicos.html#calos`).
- Funcionamento sem servidor.

## 4. Problemas e limitações
1. **Fotos**: este ambiente não acessa o Unsplash, então nenhuma foto pôde ser vista aqui. O retrato do Rafael foi escolhido pela descrição oficial da página do Unsplash (homem jovem de uniforme e óculos, sentado à mesa de uma clínica, licença gratuita). As demais são as do projeto anterior. Recomendo conferir as fotos no navegador e, idealmente, usar um ensaio real (veja `assets/img/LEIA-ME.txt`). A foto do retrato mostra um profissional "de uniforme" e pode ter aparência de médico; se for o caso, troque por uma foto sem estetoscópio.
2. **Fontes**: Bodoni Moda e Hanken Grotesk não carregaram no ambiente de teste (sem internet). As capturas usaram fontes de reserva. Confira o visual final no navegador.
3. **Navegadores**: testado no Google Chrome (modo automático). Safari, Firefox e celulares reais não foram testados.
4. **Sem JavaScript**: o conteúdo depende de JavaScript (arquitetura original). Quem navega sem ele vê um aviso com links para as páginas.
5. **`<title>` e descrição** de cada página continuam no HTML, de propósito: prévias de link no WhatsApp não executam JavaScript.

## 5. Resultado dos testes

Executados com Playwright + Google Chrome, abrindo as páginas direto do disco (file://), como o cliente faria. O modo publicado foi testado numa cópia temporária com `demoMode: false`, camada do modelo desligada, `reviewsAreReal: true` e um Instagram com URL.

**125 de 125 verificações aprovadas na rodada final.**

Rodadas anteriores encontraram e ajudaram a corrigir:
- Menu móvel que não ocupava a tela inteira (o `backdrop-filter` do cabeçalho prendia o menu).
- Cartões de contato passando da tela em 320px (e-mail longo).
- Textos de botão cortados em 320px e no cartão de horários em 1024px.
- Puxador do personalizador pequeno no celular (26px, agora 32px).

Também foram corrigidos, pelas capturas de tela:
- Botão do índice de Serviços apagado.
- Legenda do retrato escondida no Sobre.
- Linha do tempo desalinhada.
- Borda dupla nas redes sociais do rodapé.
- Espaço antes de vírgula no hero.
- Composição do hero no celular.

| # | Verificação | Resultado |
|---|---|---|
| 1 | [index] carrega sem erros no console | ✅ Aprovado |
| 2 | [index] todos os textos e listas vindos do content.js preenchidos | ✅ Aprovado |
| 3 | [index] nenhum link quebrado, vazio ou para fora da pasta | ✅ Aprovado |
| 4 | [index] sem IDs duplicados e com um único h1 | ✅ Aprovado |
| 5 | [index] menu marca a página atual | ✅ Aprovado |
| 6 | [index] identidade Rafael Mendes / Elegance (sem 'Podologia Studio', sem textos da versão feminina) | ✅ Aprovado |
| 7 | [sobre] carrega sem erros no console | ✅ Aprovado |
| 8 | [sobre] todos os textos e listas vindos do content.js preenchidos | ✅ Aprovado |
| 9 | [sobre] nenhum link quebrado, vazio ou para fora da pasta | ✅ Aprovado |
| 10 | [sobre] sem IDs duplicados e com um único h1 | ✅ Aprovado |
| 11 | [sobre] menu marca a página atual | ✅ Aprovado |
| 12 | [sobre] identidade Rafael Mendes / Elegance (sem 'Podologia Studio', sem textos da versão feminina) | ✅ Aprovado |
| 13 | [clinica] carrega sem erros no console | ✅ Aprovado |
| 14 | [clinica] todos os textos e listas vindos do content.js preenchidos | ✅ Aprovado |
| 15 | [clinica] nenhum link quebrado, vazio ou para fora da pasta | ✅ Aprovado |
| 16 | [clinica] sem IDs duplicados e com um único h1 | ✅ Aprovado |
| 17 | [clinica] menu marca a página atual | ✅ Aprovado |
| 18 | [clinica] identidade Rafael Mendes / Elegance (sem 'Podologia Studio', sem textos da versão feminina) | ✅ Aprovado |
| 19 | [servicos] carrega sem erros no console | ✅ Aprovado |
| 20 | [servicos] todos os textos e listas vindos do content.js preenchidos | ✅ Aprovado |
| 21 | [servicos] nenhum link quebrado, vazio ou para fora da pasta | ✅ Aprovado |
| 22 | [servicos] sem IDs duplicados e com um único h1 | ✅ Aprovado |
| 23 | [servicos] menu marca a página atual | ✅ Aprovado |
| 24 | [servicos] identidade Rafael Mendes / Elegance (sem 'Podologia Studio', sem textos da versão feminina) | ✅ Aprovado |
| 25 | [avaliacoes] carrega sem erros no console | ✅ Aprovado |
| 26 | [avaliacoes] todos os textos e listas vindos do content.js preenchidos | ✅ Aprovado |
| 27 | [avaliacoes] nenhum link quebrado, vazio ou para fora da pasta | ✅ Aprovado |
| 28 | [avaliacoes] sem IDs duplicados e com um único h1 | ✅ Aprovado |
| 29 | [avaliacoes] menu marca a página atual | ✅ Aprovado |
| 30 | [avaliacoes] identidade Rafael Mendes / Elegance (sem 'Podologia Studio', sem textos da versão feminina) | ✅ Aprovado |
| 31 | [contato] carrega sem erros no console | ✅ Aprovado |
| 32 | [contato] todos os textos e listas vindos do content.js preenchidos | ✅ Aprovado |
| 33 | [contato] nenhum link quebrado, vazio ou para fora da pasta | ✅ Aprovado |
| 34 | [contato] sem IDs duplicados e com um único h1 | ✅ Aprovado |
| 35 | [contato] menu marca a página atual | ✅ Aprovado |
| 36 | [contato] identidade Rafael Mendes / Elegance (sem 'Podologia Studio', sem textos da versão feminina) | ✅ Aprovado |
| 37 | Menu principal leva para sobre.html | ✅ Aprovado |
| 38 | Menu principal leva para clinica.html | ✅ Aprovado |
| 39 | Menu principal leva para servicos.html | ✅ Aprovado |
| 40 | Menu principal leva para avaliacoes.html | ✅ Aprovado |
| 41 | Menu principal leva para contato.html | ✅ Aprovado |
| 42 | Menu principal leva para index.html | ✅ Aprovado |
| 43 | Links 'página anterior / próxima' seguem a ordem do menu | ✅ Aprovado |
| 44 | Rodapé tem links para as seis páginas | ✅ Aprovado |
| 45 | Serviço em destaque abre a página de serviços no item certo | ✅ Aprovado |
| 46 | Bloco 'Explore o site' aponta para as cinco páginas internas | ✅ Aprovado |
| 47 | Celular: menu abre em tela cheia abaixo do cabeçalho com as 6 páginas | ✅ Aprovado |
| 48 | Celular: Esc fecha o menu e devolve a rolagem | ✅ Aprovado |
| 49 | Celular: link do menu navega para a página | ✅ Aprovado |
| 50 | Celular: menu aberto depois de rolar fica logo abaixo do cabeçalho fixo | ✅ Aprovado |
| 51 | Galeria: filtro 'Biossegurança' mostra só essas fotos (3 de 10) | ✅ Aprovado |
| 52 | Ampliação abre ao clicar, com foco no botão fechar e rolagem travada | ✅ Aprovado |
| 53 | Ampliação navega por setas e botões, só dentro do filtro, voltando ao início | ✅ Aprovado |
| 54 | Ampliação mantém o foco do teclado dentro da janela | ✅ Aprovado |
| 55 | Esc fecha a ampliação e devolve o foco à foto | ✅ Aprovado |
| 56 | Galeria: filtro 'Todos' volta a mostrar as 10 fotos | ✅ Aprovado |
| 57 | FAQ: abre uma pergunta e fecha a anterior | ✅ Aprovado |
| 58 | FAQ: setas do teclado navegam entre as perguntas | ✅ Aprovado |
| 59 | Modo demonstração: todos os botões de WhatsApp das 6 páginas mostram aviso sem sair da página (23 botões) | ✅ Aprovado |
| 60 | Modo demonstração: 'Abrir no mapa' mostra aviso; telefone e e-mail não viram links | ✅ Aprovado |
| 61 | [publicado] index: WhatsApp real, telefone/e-mail clicáveis, avisos e camada do modelo removidos, paleta fixa | ✅ Aprovado |
| 62 | [publicado] sobre: WhatsApp real, telefone/e-mail clicáveis, avisos e camada do modelo removidos, paleta fixa | ✅ Aprovado |
| 63 | [publicado] clinica: WhatsApp real, telefone/e-mail clicáveis, avisos e camada do modelo removidos, paleta fixa | ✅ Aprovado |
| 64 | [publicado] servicos: WhatsApp real, telefone/e-mail clicáveis, avisos e camada do modelo removidos, paleta fixa | ✅ Aprovado |
| 65 | [publicado] mensagem do WhatsApp leva o nome do profissional e o serviço | ✅ Aprovado |
| 66 | [publicado] avaliacoes: WhatsApp real, telefone/e-mail clicáveis, avisos e camada do modelo removidos, paleta fixa | ✅ Aprovado |
| 67 | [publicado] contato: WhatsApp real, telefone/e-mail clicáveis, avisos e camada do modelo removidos, paleta fixa | ✅ Aprovado |
| 68 | Personalizador lista as 9 paletas do briefing | ✅ Aprovado |
| 69 | Paleta Azul-Petróleo: aplicada, identificada no painel e com contraste AA (mín. 5.56:1) | ✅ Aprovado |
| 70 | Paleta Azul-Marinho: aplicada, identificada no painel e com contraste AA (mín. 6.11:1) | ✅ Aprovado |
| 71 | Paleta Verde-Escuro: aplicada, identificada no painel e com contraste AA (mín. 5.90:1) | ✅ Aprovado |
| 72 | Paleta Bordô: aplicada, identificada no painel e com contraste AA (mín. 6.19:1) | ✅ Aprovado |
| 73 | Paleta Grafite & Cobre: aplicada, identificada no painel e com contraste AA (mín. 5.70:1) | ✅ Aprovado |
| 74 | Paleta Areia & Chocolate: aplicada, identificada no painel e com contraste AA (mín. 6.03:1) | ✅ Aprovado |
| 75 | Paleta Cinza & Azul: aplicada, identificada no painel e com contraste AA (mín. 5.70:1) | ✅ Aprovado |
| 76 | Paleta Preto & Champagne: aplicada, identificada no painel e com contraste AA (mín. 8.11:1) | ✅ Aprovado |
| 77 | Paleta Verde-Esmeralda: aplicada, identificada no painel e com contraste AA (mín. 6.02:1) | ✅ Aprovado |
| 78 | Personalizador mantém visual neutro e fixo em todas as paletas (inclusive a escura) | ✅ Aprovado |
| 79 | Seletor 'primary': atualiza o site na hora, mostra HEX e libera 'restaurar esta cor' | ✅ Aprovado |
| 80 | Seletor 'secondary': atualiza o site na hora, mostra HEX e libera 'restaurar esta cor' | ✅ Aprovado |
| 81 | Seletor 'accent': atualiza o site na hora, mostra HEX e libera 'restaurar esta cor' | ✅ Aprovado |
| 82 | Seletor 'background': atualiza o site na hora, mostra HEX e libera 'restaurar esta cor' | ✅ Aprovado |
| 83 | Seletor 'text': atualiza o site na hora, mostra HEX e libera 'restaurar esta cor' | ✅ Aprovado |
| 84 | Contador da aba 'Ajuste fino' mostra 5 cores alteradas | ✅ Aprovado |
| 85 | Campo HEX aceita código digitado (com ou sem #) | ✅ Aprovado |
| 86 | Código HEX inválido é sinalizado e não altera o site | ✅ Aprovado |
| 87 | Botão de restaurar cada cor devolve a cor da paleta | ✅ Aprovado |
| 88 | Correção automática: texto ilegível é ajustado e o painel avisa | ✅ Aprovado |
| 89 | Fundo escuro numa paleta clara: cartões e textos recalculados (AA) e painel continua claro | ✅ Aprovado |
| 90 | Aba Legibilidade mostra 6 verificações WCAG e o resumo | ✅ Aprovado |
| 91 | Persistência: paleta e ajuste mantidos ao navegar até sobre.html | ✅ Aprovado |
| 92 | Persistência: paleta e ajuste mantidos ao navegar até clinica.html | ✅ Aprovado |
| 93 | Persistência: paleta e ajuste mantidos ao navegar até servicos.html | ✅ Aprovado |
| 94 | Persistência: paleta e ajuste mantidos ao navegar até avaliacoes.html | ✅ Aprovado |
| 95 | Persistência: paleta e ajuste mantidos ao navegar até contato.html | ✅ Aprovado |
| 96 | Persistência: escolha mantida ao recarregar a página | ✅ Aprovado |
| 97 | Persistência com localStorage bloqueado (reserva via window.name) mantém a paleta entre páginas | ✅ Aprovado |
| 98 | 'Restaurar paleta' remove os ajustes e mantém a paleta escolhida | ✅ Aprovado |
| 99 | 'Configuração original' volta para Azul-Petróleo | ✅ Aprovado |
| 100 | 'Copiar CSS' copia o bloco :root da paleta | ✅ Aprovado |
| 101 | 'Copiar paleta' gera bloco pronto para palettes.js | ✅ Aprovado |
| 102 | Teclado: setas trocam de paleta na lista | ✅ Aprovado |
| 103 | Teclado: setas navegam entre as abas do painel | ✅ Aprovado |
| 104 | Painel continua aberto, na mesma aba, ao trocar de página | ✅ Aprovado |
| 105 | Esc fecha o personalizador | ✅ Aprovado |
| 106 | Estado de foco visível ao navegar com Tab | ✅ Aprovado |
| 107 | Sem erros no console durante o uso do personalizador | ✅ Aprovado |
| 108 | Celular: personalizador abre como folha e deixa o site visível acima (540px de 844) | ✅ Aprovado |
| 109 | Celular: troca de paleta aparece na hora na parte visível do site | ✅ Aprovado |
| 110 | Celular: modo minimizado mostra só a faixa de paletas (176px) | ✅ Aprovado |
| 111 | Celular: troca de paleta funciona no modo minimizado | ✅ Aprovado |
| 112 | Celular: botões e links principais com área de toque adequada (≥ 32px) | ✅ Aprovado |
| 113 | Celular: personalizador fecha e o espaço extra some | ✅ Aprovado |
| 114 | Responsivo 320px: 6 páginas sem rolagem horizontal, textos cortados, imagens distorcidas ou erros | ✅ Aprovado |
| 115 | Responsivo 360px: 6 páginas sem rolagem horizontal, textos cortados, imagens distorcidas ou erros | ✅ Aprovado |
| 116 | Responsivo 375px: 6 páginas sem rolagem horizontal, textos cortados, imagens distorcidas ou erros | ✅ Aprovado |
| 117 | Responsivo 390px: 6 páginas sem rolagem horizontal, textos cortados, imagens distorcidas ou erros | ✅ Aprovado |
| 118 | Responsivo 414px: 6 páginas sem rolagem horizontal, textos cortados, imagens distorcidas ou erros | ✅ Aprovado |
| 119 | Responsivo 600px: 6 páginas sem rolagem horizontal, textos cortados, imagens distorcidas ou erros | ✅ Aprovado |
| 120 | Responsivo 768px: 6 páginas sem rolagem horizontal, textos cortados, imagens distorcidas ou erros | ✅ Aprovado |
| 121 | Responsivo 1024px: 6 páginas sem rolagem horizontal, textos cortados, imagens distorcidas ou erros | ✅ Aprovado |
| 122 | Responsivo 1280px: 6 páginas sem rolagem horizontal, textos cortados, imagens distorcidas ou erros | ✅ Aprovado |
| 123 | Responsivo 1440px: 6 páginas sem rolagem horizontal, textos cortados, imagens distorcidas ou erros | ✅ Aprovado |
| 124 | Responsivo 1920px: 6 páginas sem rolagem horizontal, textos cortados, imagens distorcidas ou erros | ✅ Aprovado |
| 125 | Fotos: todas mostram a imagem ou o quadro alternativo com descrição acessível | ✅ Aprovado |

Também foram conferidas capturas de tela das 6 páginas em 1440px e 390px, do personalizador aberto (desktop e celular, normal e minimizado), da correção automática de contraste e da persistência entre páginas.

## 6. Orientações para personalizar para um cliente real

O passo a passo completo está no `README.md`. Em resumo:

1. Edite `js/content.js`: marca, profissional, contato, endereço, horários, redes sociais, textos de cada página, serviços, FAQ e fotos.
2. Coloque as fotos em `assets/img/` e troque `id` por `src`.
3. Defina as cores no Ateliê e use "Copiar CSS" ou "Copiar paleta" (e `theme.defaultPalette`).
4. Use apenas depoimentos reais e autorizados, e troque `reviewsAreReal` para `true`.
5. Edite `<title>` e descrição das 6 páginas.
6. Para publicar: `demoMode: false`, as três opções de `studio` em `false` e remova o `noindex`.
