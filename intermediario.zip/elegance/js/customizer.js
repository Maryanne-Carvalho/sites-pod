/* ==========================================================================
   PERSONALIZADOR DE CORES — "Ateliê de cores" (Elegance)
   Abas: Paletas · Ajuste fino · Legibilidade.
   Conversa apenas com PS.theme (motor de cores). A escolha vale para as
   seis páginas; o próprio painel lembra, nesta aba do navegador, se estava
   aberto e qual aba estava ativa ao trocar de página.
   Para desligar no site publicado: content.site.studio.showCustomizer = false.
   ========================================================================== */

(function () {
  "use strict";

  var PS = window.PS;
  var theme = PS.theme;
  var C = PS.color;
  var content = PS.content;
  var root = document.documentElement;
  var studio = (content.site && content.site.studio) || {};

  function $(sel, ctx) { return (ctx || document).querySelector(sel); }
  function $all(sel, ctx) { return Array.prototype.slice.call((ctx || document).querySelectorAll(sel)); }
  function icon(name) { return '<svg class="icon" aria-hidden="true"><use href="#i-' + name + '"/></svg>'; }
  function esc(v) {
    return String(v == null ? "" : v).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  }
  function toast(msg, ms) { if (PS.toast) PS.toast(msg, ms); }

  /* ---- Desligado: remove os botões que abririam o painel ---- */
  if (!theme || studio.showCustomizer === false) {
    $all("[data-cz-open]").forEach(function (b) { b.remove(); });
    return;
  }

  var UI_KEY = (content.theme && content.theme.storageKey ? content.theme.storageKey : "elegance") + ":ui";
  var sheetQuery = window.matchMedia("(max-width: 899.98px)");
  var HINTS = {
    primary: "Botões, links e destaques",
    secondary: "Faixas e fundos suaves",
    accent: "Detalhes, números e filetes",
    background: "Fundo das páginas",
    text: "Títulos e textos"
  };

  /* ---------------- Montagem ---------------- */
  var opts = PS.palettes.map(function (p) {
    var c = p.colors;
    return '<button type="button" class="cz__opt" role="radio" aria-checked="false" tabindex="-1" data-pal="' + esc(p.id) + '">' +
      '<span class="cz__sw" aria-hidden="true"><i style="background:' + c.primary + '"></i><i style="background:' + c.secondary + '"></i><i style="background:' + c.background + '"></i><i style="background:' + c.accent + '"></i></span>' +
      '<span><span class="cz__opt-name">' + esc(p.name) + '</span><span class="cz__opt-mood">' + esc(p.mood) + "</span></span>" +
      '<span class="cz__opt-check" aria-hidden="true">' + icon("check") + "</span>" +
    "</button>";
  }).join("");

  var pickers = theme.editable.map(function (k) {
    var label = theme.labels[k];
    return '<div class="cz__picker" data-cz-row="' + k + '">' +
      '<input type="color" id="cz-pk-' + k + '" data-cz-pick="' + k + '">' +
      '<label class="cz__picker-name" for="cz-pk-' + k + '">' + esc(label) + "<small>" + esc(HINTS[k]) + "</small></label>" +
      '<input class="cz__hex" type="text" maxlength="7" spellcheck="false" autocomplete="off" data-cz-hex="' + k + '" aria-label="Código HEX — ' + esc(label) + '">' +
      '<button class="cz__reset" type="button" data-cz-reset="' + k + '" aria-label="Voltar ' + esc(label.toLowerCase()) + ' ao padrão da paleta" title="Voltar ao padrão da paleta" hidden>' + icon("reset") + "</button>" +
    "</div>";
  }).join("");

  document.body.insertAdjacentHTML("beforeend",
    '<button class="cz-fab" type="button" data-cz-open aria-controls="cz" aria-expanded="false"><span class="cz-fab__dots" aria-hidden="true" data-cz-dots><i></i><i></i><i></i><i></i></span>Cores</button>' +
    '<section class="cz" id="cz" aria-labelledby="cz-title" hidden data-cz>' +
      '<div class="cz__head">' +
        '<button class="cz__grip" type="button" tabindex="-1" aria-label="Minimizar ou expandir" data-cz-grip></button>' +
        '<div class="cz__head-row">' +
          "<div>" +
            '<p class="cz__kicker">Ateliê de cores · ' + esc(studio.productName || "Elegance") + "</p>" +
            '<h2 class="cz__title" id="cz-title">Personalizar cores</h2>' +
          "</div>" +
          '<div class="cz__head-actions">' +
            '<button class="cz__icon-btn cz__compact" type="button" aria-pressed="false" aria-label="Minimizar personalizador" title="Minimizar e ver mais do site" data-cz-compact>' + icon("chevron") + "</button>" +
            '<button class="cz__icon-btn" type="button" aria-label="Fechar personalizador" data-cz-close>' + icon("close") + "</button>" +
          "</div>" +
        "</div>" +
        '<p class="cz__current"><span class="cz__current-sw" aria-hidden="true" data-cz-cur-sw></span><span>Aplicada: <strong data-cz-cur>—</strong></span><span class="cz__badge" data-cz-badge hidden>Ajustada</span></p>' +
      "</div>" +
      '<div class="cz__tabs" role="tablist" aria-label="Seções do personalizador">' +
        '<button class="cz__tab" type="button" role="tab" id="cz-tab-palettes" aria-controls="cz-panel-palettes" aria-selected="true" data-cz-tab="palettes">Paletas <span class="cz__tab-count">' + PS.palettes.length + "</span></button>" +
        '<button class="cz__tab" type="button" role="tab" id="cz-tab-custom" aria-controls="cz-panel-custom" aria-selected="false" tabindex="-1" data-cz-tab="custom">Ajuste fino <span class="cz__tab-count" data-cz-custom-count hidden></span></button>' +
        '<button class="cz__tab" type="button" role="tab" id="cz-tab-contrast" aria-controls="cz-panel-contrast" aria-selected="false" tabindex="-1" data-cz-tab="contrast">Legibilidade <span class="cz__tab-count" data-cz-contrast-count></span></button>' +
      "</div>" +
      '<div class="cz__body">' +
        '<div class="cz__panel" role="tabpanel" id="cz-panel-palettes" aria-labelledby="cz-tab-palettes" data-cz-panel="palettes">' +
          '<p class="cz__label" id="cz-pal-label">Escolha uma paleta</p>' +
          '<div class="cz__palettes" role="radiogroup" aria-labelledby="cz-pal-label" data-cz-list>' + opts + "</div>" +
        "</div>" +
        '<div class="cz__panel" role="tabpanel" id="cz-panel-custom" aria-labelledby="cz-tab-custom" data-cz-panel="custom" hidden>' +
          '<p class="cz__label">Cinco cores editáveis</p>' +
          '<div class="cz__pickers">' + pickers + "</div>" +
          '<ul class="cz__notes" data-cz-notes></ul>' +
          '<p class="cz__hint">Use o seletor ou cole o código HEX da marca. Quando uma cor escolhida prejudicar a leitura em textos, o site usa uma versão ajustada e avisa aqui.</p>' +
        "</div>" +
        '<div class="cz__panel" role="tabpanel" id="cz-panel-contrast" aria-labelledby="cz-tab-contrast" data-cz-panel="contrast" hidden>' +
          '<p class="cz__summary" role="status" data-cz-summary></p>' +
          '<ul class="cz__checks" data-cz-checks></ul>' +
          '<p class="cz__hint">Verificação de contraste pelo padrão WCAG 2.x: textos precisam de pelo menos 4,5:1 (AA); 7:1 é o nível AAA.</p>' +
        "</div>" +
      "</div>" +
      '<div class="cz__foot">' +
        '<button class="cz__btn" type="button" data-cz-act="restore">' + icon("reset") + "Restaurar paleta</button>" +
        '<button class="cz__btn" type="button" data-cz-act="original">' + icon("sparkle") + "Configuração original</button>" +
        '<button class="cz__btn cz__btn--dark" type="button" data-cz-act="copy-css">' + icon("copy") + "Copiar CSS</button>" +
        '<button class="cz__btn cz__btn--dark" type="button" data-cz-act="copy-palette">' + icon("code") + "Copiar paleta</button>" +
        '<p class="cz__save">Salvo neste navegador e aplicado nas seis páginas.</p>' +
      "</div>" +
    "</section>");

  var panel = $("[data-cz]");
  var list = $("[data-cz-list]", panel);
  var options = $all(".cz__opt", panel);
  var tabs = $all("[data-cz-tab]", panel);
  var openers = $all("[data-cz-open]");
  var compactBtn = $("[data-cz-compact]", panel);

  /* ---------------- Estado da interface (por aba do navegador) ---------------- */
  function readUi() {
    try { return JSON.parse(sessionStorage.getItem(UI_KEY)) || {}; } catch (e) { return {}; }
  }
  function writeUi(patch) {
    var ui = readUi();
    Object.keys(patch).forEach(function (k) { ui[k] = patch[k]; });
    try { sessionStorage.setItem(UI_KEY, JSON.stringify(ui)); } catch (e) { /* sem sessionStorage */ }
  }

  /* ---------------- Abas ---------------- */
  function selectTab(name, focus) {
    tabs.forEach(function (t) {
      var on = t.getAttribute("data-cz-tab") === name;
      t.setAttribute("aria-selected", on ? "true" : "false");
      t.setAttribute("tabindex", on ? "0" : "-1");
      if (on && focus) t.focus();
    });
    $all("[data-cz-panel]", panel).forEach(function (p) { p.hidden = p.getAttribute("data-cz-panel") !== name; });
    writeUi({ tab: name });
    syncSheet();
  }

  tabs.forEach(function (t, i) {
    t.addEventListener("click", function () { selectTab(t.getAttribute("data-cz-tab"), false); });
    t.addEventListener("keydown", function (e) {
      var n = null;
      if (e.key === "ArrowRight") n = (i + 1) % tabs.length;
      if (e.key === "ArrowLeft") n = (i - 1 + tabs.length) % tabs.length;
      if (e.key === "Home") n = 0;
      if (e.key === "End") n = tabs.length - 1;
      if (n !== null) { e.preventDefault(); selectTab(tabs[n].getAttribute("data-cz-tab"), true); }
    });
  });

  /* ---------------- Paletas ---------------- */
  function choose(id, announce) {
    var st = theme.getState();
    if (st && st.palette.id === id && !st.customized) {
      if (announce) toast("“" + st.palette.name + "” já está aplicada.");
      return;
    }
    var r = theme.setPalette(id);
    if (announce) toast("Paleta “" + r.palette.name + "” aplicada às seis páginas.");
  }

  options.forEach(function (o) {
    o.addEventListener("click", function () { choose(o.getAttribute("data-pal"), true); });
  });

  list.addEventListener("keydown", function (e) {
    var keys = ["ArrowRight", "ArrowDown", "ArrowLeft", "ArrowUp", "Home", "End"];
    if (keys.indexOf(e.key) === -1) return;
    e.preventDefault();
    var i = options.indexOf(document.activeElement);
    if (i < 0) i = 0;
    var n = i;
    if (e.key === "ArrowRight" || e.key === "ArrowDown") n = (i + 1) % options.length;
    if (e.key === "ArrowLeft" || e.key === "ArrowUp") n = (i - 1 + options.length) % options.length;
    if (e.key === "Home") n = 0;
    if (e.key === "End") n = options.length - 1;
    options[n].focus();
    options[n].scrollIntoView({ block: "nearest", inline: "nearest" });
    choose(options[n].getAttribute("data-pal"), false);
  });

  /* ---------------- Ajuste fino ---------------- */
  theme.editable.forEach(function (k) {
    var color = $('[data-cz-pick="' + k + '"]', panel);
    var hex = $('[data-cz-hex="' + k + '"]', panel);
    var reset = $('[data-cz-reset="' + k + '"]', panel);
    var label = theme.labels[k];
    var pending = null, frame = 0;

    function live(v) {
      pending = v;
      if (frame) return;
      frame = requestAnimationFrame(function () {
        frame = 0;
        theme.setOverride(k, pending, { animate: false, save: false });
      });
    }

    color.addEventListener("input", function () { live(color.value); });
    color.addEventListener("change", function () {
      theme.setOverride(k, color.value, { animate: false });
      toast(label + " ajustada para " + color.value.toUpperCase() + ".");
    });

    function commit(announce) {
      var v = C.normalizeHex(hex.value);
      if (!v) {
        hex.setAttribute("aria-invalid", "true");
        if (announce) toast("Use um código como #174C57.");
        return;
      }
      hex.removeAttribute("aria-invalid");
      theme.setOverride(k, v, { animate: false });
      if (announce) toast(label + " ajustada para " + v.toUpperCase() + ".");
    }

    hex.addEventListener("input", function () {
      var raw = hex.value.trim();
      if (raw && raw.charAt(0) !== "#") raw = "#" + raw;
      if (/^#[0-9a-f]{6}$/i.test(raw)) { hex.removeAttribute("aria-invalid"); live(raw); }
    });
    hex.addEventListener("keydown", function (e) { if (e.key === "Enter") { e.preventDefault(); commit(true); } });
    hex.addEventListener("change", function () { commit(false); });
    hex.addEventListener("blur", function () {
      if (hex.getAttribute("aria-invalid") === "true") { hex.removeAttribute("aria-invalid"); render(theme.getState()); }
    });

    reset.addEventListener("click", function () {
      theme.clearOverride(k);
      toast(label + " voltou ao padrão da paleta.");
      color.focus();
    });
  });

  /* ---------------- Ações ---------------- */
  $all("[data-cz-act]", panel).forEach(function (b) {
    b.addEventListener("click", function () {
      var act = b.getAttribute("data-cz-act");
      var r;
      if (act === "restore") {
        if (!theme.getState().customized) { toast("A paleta já está sem ajustes manuais."); return; }
        r = theme.restore();
        toast("Ajustes removidos. Paleta “" + r.palette.name + "” restaurada.");
      }
      if (act === "original") {
        r = theme.resetOriginal();
        toast("Configuração original restaurada: “" + r.palette.name + "”.");
      }
      if (act === "copy-css") copyText(theme.exportCss(), "Variáveis CSS copiadas. Cole no bloco de tokens de css/elegance.css.");
      if (act === "copy-palette") copyText(theme.exportPalette(), "Paleta copiada. Cole em js/palettes.js.");
    });
  });

  function copyText(text, ok) {
    function done() { toast(ok, 3600); }
    function fallback() {
      var ta = document.createElement("textarea");
      ta.value = text;
      ta.setAttribute("readonly", "");
      ta.style.position = "fixed";
      ta.style.opacity = "0";
      document.body.appendChild(ta);
      ta.select();
      var success = false;
      try { success = document.execCommand("copy"); } catch (e) { success = false; }
      document.body.removeChild(ta);
      if (success) done(); else toast("Não foi possível copiar automaticamente neste navegador.");
    }
    if (navigator.clipboard && window.isSecureContext) navigator.clipboard.writeText(text).then(done, fallback);
    else fallback();
  }

  /* ---------------- Atualização da interface ---------------- */
  var lastSig = "";
  var summaryTimer = null;

  function render(st) {
    if (!st) return;
    options.forEach(function (o) {
      var sel = o.getAttribute("data-pal") === st.palette.id;
      o.setAttribute("aria-checked", sel ? "true" : "false");
      o.setAttribute("tabindex", sel ? "0" : "-1");
    });

    $("[data-cz-cur]", panel).textContent = st.palette.name;
    $("[data-cz-badge]", panel).hidden = !st.customized;
    var swatch = ["primary", "accent", "background"].map(function (k) { return '<i style="background:' + st.colors[k] + '"></i>'; }).join("");
    $("[data-cz-cur-sw]", panel).innerHTML = swatch;

    var dots = $("[data-cz-dots]");
    if (dots) {
      var ds = dots.querySelectorAll("i");
      ["primary", "accent", "secondary", "deep"].forEach(function (k, i) { if (ds[i]) ds[i].style.background = st.colors[k]; });
    }

    var count = Object.keys(st.overrides).length;
    var cc = $("[data-cz-custom-count]", panel);
    cc.hidden = !count;
    cc.textContent = count;

    theme.editable.forEach(function (k) {
      var color = $('[data-cz-pick="' + k + '"]', panel);
      var hex = $('[data-cz-hex="' + k + '"]', panel);
      var value = st.overrides[k] || st.colors[k];
      if (document.activeElement !== color) color.value = value;
      if (document.activeElement !== hex) hex.value = value.toUpperCase();
      $('[data-cz-reset="' + k + '"]', panel).hidden = !st.overrides[k];
    });

    var notes = $("[data-cz-notes]", panel);
    notes.innerHTML = (st.notes || []).map(function (n) { return "<li>" + icon("info") + "<span>" + esc(n.message) + "</span></li>"; }).join("");

    var okCount = st.checks.filter(function (c) { return c.ratio >= 4.5; }).length;
    var total = st.checks.length;
    var badge = $("[data-cz-contrast-count]", panel);
    badge.textContent = okCount + "/" + total;
    badge.className = "cz__tab-count " + (okCount === total ? "is-ok" : "is-warn");

    var sig = st.checks.map(function (c) { return c.fg + c.bg; }).join("|");
    if (sig !== lastSig) {
      lastSig = sig;
      $("[data-cz-checks]", panel).innerHTML = st.checks.map(function (c) {
        return '<li class="cz__check"><span class="cz__check-sample" aria-hidden="true" style="background:' + c.bg + ";color:" + c.fg + '">Aa</span>' +
          "<span>" + esc(c.name) + "</span>" +
          '<span class="cz__check-ratio">' + c.ratio.toFixed(1).replace(".", ",") + ":1</span>" +
          '<span class="cz__grade grade--' + c.grade.key + '">' + esc(c.grade.label) + "</span></li>";
      }).join("");
      clearTimeout(summaryTimer);
      summaryTimer = setTimeout(function () {
        var s = $("[data-cz-summary]", panel);
        var all = okCount === total;
        s.className = "cz__summary" + (all ? "" : " is-warn");
        s.innerHTML = icon(all ? "shield" : "info") + "<span>" + (all
          ? "Todas as " + total + " combinações atendem ao padrão WCAG AA."
          : okCount + " de " + total + " combinações atendem ao padrão AA. Ajuste as cores marcadas.") + "</span>";
      }, 400);
    }
  }

  document.addEventListener("ps:themechange", function (e) { render(e.detail); });
  render(theme.getState());

  /* ---------------- Abrir, fechar e minimizar ---------------- */
  var lastOpener = null;
  var hideTimer = null;

  function syncSheet() {
    var isSheet = sheetQuery.matches && !panel.hidden;
    root.classList.toggle("cz-sheet-open", isSheet);
    root.style.setProperty("--cz-sheet-h", (isSheet ? Math.round(panel.getBoundingClientRect().height) : 0) + "px");
  }
  if ("ResizeObserver" in window) new ResizeObserver(syncSheet).observe(panel);
  if (sheetQuery.addEventListener) sheetQuery.addEventListener("change", syncSheet);

  function setCompact(v) {
    panel.classList.toggle("is-compact", v);
    compactBtn.setAttribute("aria-pressed", v ? "true" : "false");
    compactBtn.setAttribute("aria-label", v ? "Expandir personalizador" : "Minimizar personalizador");
    if (v) {
      var sel = $('[aria-checked="true"]', list);
      if (sel) sel.scrollIntoView({ block: "nearest", inline: "center" });
    }
    writeUi({ compact: v });
    syncSheet();
  }
  compactBtn.addEventListener("click", function () { setCompact(!panel.classList.contains("is-compact")); });
  $("[data-cz-grip]", panel).addEventListener("click", function () { setCompact(!panel.classList.contains("is-compact")); });

  function setExpanded(v) { openers.forEach(function (o) { o.setAttribute("aria-expanded", v ? "true" : "false"); }); }

  function open(opener, focus) {
    clearTimeout(hideTimer);
    lastOpener = opener || null;
    panel.hidden = false;
    panel.classList.add("is-entering");
    void panel.offsetWidth;
    panel.classList.remove("is-entering");
    root.classList.add("cz-open");
    setExpanded(true);
    writeUi({ open: true });
    syncSheet();
    if (focus) {
      var sel = $('[aria-checked="true"]', list) || options[0];
      if (!$('[data-cz-panel="palettes"]', panel).hidden) sel.focus({ preventScroll: true });
      else $('[aria-selected="true"]', panel).focus({ preventScroll: true });
    }
  }

  function close() {
    if (panel.hidden) return;
    panel.classList.add("is-entering");
    root.classList.remove("cz-open");
    setExpanded(false);
    writeUi({ open: false });
    hideTimer = setTimeout(function () { panel.hidden = true; panel.classList.remove("is-entering"); syncSheet(); }, 300);
    var target = lastOpener && lastOpener.offsetParent !== null ? lastOpener : $(".cz-fab");
    if (target && panel.contains(document.activeElement)) target.focus({ preventScroll: true });
  }

  openers.forEach(function (o) {
    o.addEventListener("click", function (e) {
      e.stopPropagation();
      if (!root.classList.contains("cz-open")) open(o, true); else close();
    });
  });
  $("[data-cz-close]", panel).addEventListener("click", close);
  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape" && !panel.hidden && panel.contains(document.activeElement)) close();
  });

  PS.customizer = { open: function () { open(null, false); }, close: close, compact: setCompact, tab: selectTab };

  /* Restaura o estado do painel ao chegar de outra página */
  var ui = readUi();
  if (ui.tab) selectTab(ui.tab, false);
  if (ui.compact) setCompact(true);
  if (ui.open) open(null, false);
})();
