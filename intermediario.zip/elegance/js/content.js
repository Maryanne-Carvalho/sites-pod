/* ==========================================================================
   CONTEÚDO DO SITE — Elegance Podologia (modelo intermediário)

   Tudo o que muda de um cliente para outro está neste arquivo: marca,
   profissional, história, formação, serviços, fotos, depoimentos,
   contato, endereço, horários e redes sociais. As páginas HTML só
   definem a estrutura; os textos e listas abaixo são inseridos
   automaticamente em todas as seis páginas.

   Regras simples para editar:
   - Mantenha as aspas e as vírgulas no fim de cada linha.
   - Para remover um item de uma lista, apague o bloco inteiro { ... },
     incluindo a vírgula depois dele.
   - Textos com *asteriscos* aparecem em itálico, na cor de destaque.

   IMPORTANTE: todo o conteúdo atual é FICTÍCIO, criado para demonstração.
   O <title> e a descrição do <head> de cada página também devem ser
   editados à mão (prévias de link no WhatsApp e no Google não leem
   este arquivo).
   ========================================================================== */

window.PS = window.PS || {};

window.PS.content = {

  /* ------------------------------------------------------------------ */
  /* Publicação                                                          */
  /* No site de um cliente real: demoMode false e as três opções de     */
  /* "studio" em false.                                                  */
  /* ------------------------------------------------------------------ */
  site: {
    demoMode: true,            // true = avisos "demonstrativo" visíveis e botões de contato só mostram aviso
    studio: {
      showBar: true,           // faixa escura do topo ("Modelo Elegance")
      showCustomizer: true,    // personalizador de cores (desligado = usa sempre a paleta padrão)
      showTemplateNote: true,  // faixa "Sobre este modelo" depois do rodapé
      productName: "Elegance",
      modelName: "Modelo intermediário",
      version: "v2.0",
      compareUrl: ""           // opcional: link para comparar com outro modelo (vazio = escondido)
    }
  },

  /* ------------------------------------------------------------------ */
  /* Marca e profissional                                                */
  /* ------------------------------------------------------------------ */
  brand: {
    name: "Elegance Podologia",
    wordmark: "Elegance",        // parte grande do logotipo
    wordmarkSub: "Podologia",    // parte pequena do logotipo
    monogram: "E",
    tagline: "Podologia técnica, contemporânea e humanizada",
    city: "São Paulo",
    state: "SP",
    neighborhood: "Pinheiros"
  },

  professional: {
    name: "Rafael Mendes",
    firstName: "Rafael",
    role: "Podólogo",
    since: "2015",
    shortBio: "Atendo com método e sem pressa. Cada consulta começa por uma avaliação cuidadosa e termina com orientações claras, para que você entenda o que foi feito e saiba como continuar cuidando dos pés no dia a dia.",
    signatureQuote: "Técnica é o que garante a segurança do procedimento. Atenção é o que faz a pessoa voltar tranquila para casa."
  },

  /* ------------------------------------------------------------------ */
  /* Contato (um único lugar para todo o site)                           */
  /* ------------------------------------------------------------------ */
  contact: {
    /* WhatsApp: só dígitos, com 55 + DDD (ex.: "5511912345678").
       Nas mensagens, {nome} vira o primeiro nome do profissional e
       {servico}, o serviço do botão clicado. */
    whatsapp: {
      number: "5511900000000",
      display: "(11) 90000-0000",
      message: "Olá, {nome}! Vi o site da Elegance Podologia e gostaria de agendar um horário.",
      serviceMessage: "Olá, {nome}! Vi o site da Elegance Podologia e gostaria de informações sobre: {servico}."
    },
    phone: {
      display: "(11) 3000-0000",
      dial: "+551130000000"
    },
    email: "contato@elegancepodologia.exemplo",
    address: {
      line1: "Rua dos Pinheiros, 500 — conjunto 82",
      line2: "Pinheiros, São Paulo – SP",
      zip: "CEP 00000-000",
      reference: "A 5 minutos a pé da estação Faria Lima (referência ilustrativa)"
    },
    /* Endereço "src" do mapa incorporado do Google Maps (vazio = espaço reservado) */
    mapEmbedUrl: "",
    /* Link para abrir o endereço no aplicativo de mapas */
    mapsUrl: "https://www.google.com/maps/search/?api=1&query=Pinheiros+S%C3%A3o+Paulo",
    hours: [
      { days: "Segunda a sexta", time: "8h às 19h" },
      { days: "Sábado", time: "8h às 13h" },
      { days: "Domingo e feriados", time: "Fechado" }
    ],
    hoursNote: "Atendimento somente com hora marcada.",
    /* Redes sociais: com URL vira link; sem URL aparece só o nome de usuário (demonstração). */
    social: [
      { name: "Instagram", handle: "@elegancepodologia", url: "" },
      { name: "LinkedIn", handle: "Rafael Mendes, podólogo", url: "" }
    ]
  },

  /* ------------------------------------------------------------------ */
  /* Informações úteis (página A clínica e Contato)                      */
  /* ------------------------------------------------------------------ */
  usefulInfo: [
    { icon: "clock", title: "Pontualidade", text: "Cada horário é reservado para uma pessoa. Chegue com 5 minutos de antecedência." },
    { icon: "access", title: "Acessibilidade", text: "Prédio com elevador e entrada sem degraus." },
    { icon: "car", title: "Estacionamento", text: "Estacionamento conveniado ao lado do prédio (informação ilustrativa)." },
    { icon: "card", title: "Pagamento", text: "Pix, cartões de débito e crédito (informação ilustrativa)." }
  ],

  /* ------------------------------------------------------------------ */
  /* Fotos                                                               */
  /* id = foto do Unsplash (uso gratuito). Para usar foto própria, troque */
  /* por src, ex.: { src: "assets/img/retrato.jpg", alt: "..." }.         */
  /* Se uma foto não carregar, o site mostra um quadro nas cores da      */
  /* paleta, do mesmo tamanho.                                           */
  /* ------------------------------------------------------------------ */
  images: {
    portrait:     { id: "photo-1758691463333-c79215e8bc3b", alt: "Retrato ilustrativo do profissional, de uniforme e óculos, sentado à mesa do consultório", position: "50% 30%" },
    exam:         { id: "photo-1758654859934-2a03792260a0", alt: "Profissional examinando com atenção o pé e o tornozelo de uma pessoa" },
    heroHands:    { id: "photo-1675159364615-38e1f6b62282", alt: "Mãos de profissional cuidando de um pé apoiado sobre toalha branca" },
    heel:         { id: "photo-1768508236664-3f294aaf7d41", alt: "Close de um cuidado sendo realizado no calcanhar" },
    care:         { id: "photo-1712638932314-e2b185ca0930", alt: "Atendimento tranquilo com toalhas brancas" },
    massage:      { id: "photo-1545463913-5083aa7359a6", alt: "Mãos cuidando de um pé com delicadeza" },
    feetTowel:    { id: "photo-1608158432223-3c0d2f6d9e2f", alt: "Pés descansando sobre tecido branco" },
    cream:        { id: "photo-1638859471856-c6793be39109", alt: "Pés sobre toalha ao lado de um pote de creme hidratante" },
    feetHands:    { id: "photo-1529982412356-901cc3a363cf", alt: "Mãos apoiando pés descalços" },
    reception:    { id: "photo-1787496994323-59ac5cff09f9", alt: "Duas poltronas claras ao lado de uma planta, diante de parede ripada de madeira" },
    lounge:       { id: "photo-1629909614456-6b1c5c94cecc", alt: "Sofá azul ao lado de uma planta em vaso" },
    hallway:      { id: "photo-1787496994867-939269b4d323", alt: "Corredor claro com quadros botânicos e um pequeno banco" },
    room:         { id: "photo-1745327883290-1e9c6447b938", alt: "Sala de atendimento limpa e organizada, pronta para receber" },
    instruments:  { id: "photo-1688565631957-0306970fdd74", alt: "Bandeja com instrumentais metálicos organizados" },
    handwash:     { id: "photo-1584744646898-40ff0404e767", alt: "Pessoa lavando as mãos em uma pia" },
    cleaning:     { id: "photo-1628177142898-93e36e4e3a50", alt: "Mão com luva azul segurando um borrifador de limpeza" },
    towel:        { id: "photo-1620733723572-11c53f73a416", alt: "Toalha branca enrolada, difusor de varetas e velas acesas" },
    shelf:        { id: "photo-1786937680099-779e1da6f7f7", alt: "Prateleiras com produtos de cuidado em um corredor iluminado" },
    plant:        { id: "photo-1611920630905-426e08849c32", alt: "Planta verde sobre mesa de madeira" }
  },
  imageNote: "Fotos ilustrativas de banco de imagens. No site do cliente, entram as fotos reais do consultório e do profissional.",

  /* ------------------------------------------------------------------ */
  /* Página inicial                                                      */
  /* ------------------------------------------------------------------ */
  home: {
    heroKicker: "Podologia clínica em Pinheiros",
    heroTitle: "Podologia de *precisão*, com tempo para ouvir.",
    heroLead: "Sou o Rafael, podólogo. Uno técnica, biossegurança rigorosa e uma consulta sem pressa para cuidar de unhas, pele e pés sensíveis, sempre explicando cada etapa.",
    heroServices: ["Unhas encravadas", "Pés sensíveis e diabéticos", "Calos e calosidades"],
    heroFacts: [
      { value: "1:1", label: "um paciente por horário" },
      { value: "50 min", label: "na primeira consulta" }
    ],
    introTitle: "Um atendimento que começa pela *escuta*",
    highlights: [
      { icon: "ear", title: "Avaliação antes do procedimento", text: "A consulta começa com uma conversa sobre rotina, calçados, histórico e o que tem incomodado." },
      { icon: "shield", title: "Biossegurança visível", text: "Instrumentais esterilizados, embalagem aberta na sua frente e descartáveis quando indicado." },
      { icon: "book", title: "Explicação em linguagem clara", text: "Cada etapa é explicada antes de começar. Você pode pedir uma pausa a qualquer momento." },
      { icon: "leaf", title: "Orientação para o dia a dia", text: "Você sai sabendo como cuidar dos pés em casa e quais sinais merecem atenção." }
    ],
    featuredServices: ["avaliacao", "unhas-encravadas", "pes-sensiveis"],
    clinicFacts: [
      { icon: "clock", text: "Hora marcada, sem sala de espera cheia" },
      { icon: "shield", text: "Área separada para esterilização" },
      { icon: "access", text: "Prédio com elevador e acesso sem degraus" }
    ],
    steps: [
      { title: "Contato", text: "Você envia uma mensagem, conta o que sente e escolhe um horário." },
      { title: "Avaliação", text: "Conversamos sobre sua rotina e avaliamos pele, unhas e pisada." },
      { title: "Cuidado", text: "O procedimento combinado é feito com explicação a cada etapa." },
      { title: "Orientação", text: "Você recebe recomendações para casa e, se fizer sentido, um intervalo de retorno." }
    ]
  },

  /* ------------------------------------------------------------------ */
  /* Sobre mim                                                           */
  /* ------------------------------------------------------------------ */
  about: {
    heroTitle: "Muito prazer, eu sou o *Rafael*.",
    heroLead: "Podólogo com atuação em cuidado preventivo, unhas e pés sensíveis. Acredito em consultas com método, explicação clara e respeito ao seu tempo.",
    story: [
      "Meu interesse pela podologia começou no esporte. Joguei vôlei por anos e vi colegas de equipe deixarem de treinar por causa de unhas encravadas, bolhas e calos que ninguém tratava direito. Percebi cedo que cuidar dos pés era cuidar da autonomia de alguém.",
      "Na formação, me encantei pela parte técnica: entender a anatomia, os pontos de pressão e a forma como pequenos hábitos mudam tudo. Com o tempo, entendi que técnica sem escuta não basta. A pessoa precisa saber o que está acontecendo e se sentir segura.",
      "Hoje, na Elegance Podologia, cada horário é reservado para um único paciente. Isso me permite conversar, explicar cada etapa e montar um plano de cuidados que faça sentido para a rotina de quem eu atendo."
    ],
    philosophy: "Antes de qualquer procedimento, quero entender sua rotina, seus calçados e o que tem incomodado. Explico o que vou fazer, por que e como você pode continuar cuidando em casa. Quando percebo algo que precisa de avaliação médica, oriento a procurar o profissional adequado.",
    timeline: [
      { year: "2015", title: "Formação técnica", text: "Conclusão do curso de Podologia e primeiros atendimentos supervisionados." },
      { year: "2017", title: "Clínica multiprofissional", text: "Rotina em equipe, com foco em unhas, calosidades e atendimento a atletas amadores." },
      { year: "2020", title: "Pés sensíveis", text: "Aprofundamento no cuidado com pessoas com diabetes, idosos e gestantes." },
      { year: "2023", title: "Elegance Podologia", text: "Abertura do consultório próprio, com atendimento individual e hora marcada." }
    ],
    timelineNote: "Linha do tempo fictícia, criada para demonstração.",
    education: [
      { title: "Curso técnico em Podologia", place: "Instituição a ser informada pelo profissional" },
      { title: "Cuidados com o pé diabético", place: "Curso livre — exemplo de demonstração" },
      { title: "Biossegurança em serviços de saúde", place: "Atualização — exemplo de demonstração" },
      { title: "Órteses e reeducação ungueal", place: "Curso livre — exemplo de demonstração" }
    ],
    educationNote: "Formação ilustrativa. No site real, o profissional informa seus cursos e registros verdadeiros.",
    values: [
      { title: "Precisão", text: "Cada procedimento segue um método claro, com os materiais certos para cada caso." },
      { title: "Transparência", text: "Você sabe o que será feito antes de começar e pode pedir uma pausa a qualquer momento." },
      { title: "Segurança", text: "Protocolos de higiene e esterilização seguidos em todos os atendimentos, sem exceção." },
      { title: "Prevenção", text: "O objetivo é que você precise de menos correções e mais manutenção." }
    ],
    numbers: [
      { value: "10", label: "anos de atuação" },
      { value: "1", label: "paciente por horário" },
      { value: "50", label: "minutos na primeira consulta" }
    ],
    numbersNote: "Números fictícios de demonstração."
  },

  /* ------------------------------------------------------------------ */
  /* A clínica                                                           */
  /* ------------------------------------------------------------------ */
  clinic: {
    heroTitle: "Um consultório pensado para a sua *tranquilidade*",
    heroLead: "Luz natural, silêncio e organização. Cada ambiente foi planejado para que a consulta seja calma do momento em que você chega até a saída.",
    intro: [
      "A Elegance Podologia fica em um conjunto comercial em um prédio tranquilo, com elevador. Atendemos uma pessoa por vez, então você não divide a recepção com uma fila de espera.",
      "Cada ambiente tem uma função clara: a recepção para você chegar com calma, a sala de atendimento para o cuidado e uma área separada para limpeza e esterilização dos materiais."
    ],
    spaces: [
      {
        id: "recepcao",
        title: "Recepção",
        image: "reception",
        text: "Um lugar para chegar sem pressa, com água, espaço para guardar seus pertences e uma poltrona confortável para tirar os sapatos com calma.",
        points: ["Hora marcada, sem fila", "Ambiente climatizado", "Acessível por elevador"]
      },
      {
        id: "sala",
        title: "Sala de atendimento",
        image: "room",
        text: "Cadeira reclinável, iluminação adequada para o procedimento e tudo organizado ao alcance do profissional. A sala é higienizada entre um atendimento e outro.",
        points: ["Iluminação própria para o cuidado", "Superfícies higienizadas a cada atendimento", "Privacidade durante toda a consulta"]
      },
      {
        id: "organizacao",
        title: "Equipamentos e organização",
        image: "instruments",
        text: "Instrumentais separados por tipo de procedimento e guardados em embalagens próprias. Materiais descartáveis são usados sempre que indicado.",
        points: ["Instrumentais identificados e embalados", "Descartáveis de uso único quando indicado", "Armazenamento fechado e organizado"]
      }
    ],
    biosafety: [
      { title: "Higienização das mãos e EPIs", text: "Antes de cada atendimento: lavagem das mãos, luvas, máscara e demais equipamentos de proteção." },
      { title: "Limpeza das superfícies", text: "Cadeira, bancada e apoios são higienizados entre um atendimento e o próximo." },
      { title: "Esterilização dos instrumentais", text: "Os materiais passam por limpeza e esterilização e ficam em embalagem lacrada." },
      { title: "Embalagem aberta na sua frente", text: "Você vê o pacote ser aberto no início do seu atendimento." },
      { title: "Descarte adequado", text: "Materiais de uso único são descartados conforme as normas sanitárias." }
    ],
    biosafetyNote: "Descrição geral de boas práticas, para fins de demonstração. Cada consultório deve descrever os próprios protocolos.",
    experience: [
      { title: "Chegada", text: "Você é recebido no horário marcado, sem espera." },
      { title: "Conversa", text: "Falamos sobre sua rotina, histórico e o que tem incomodado." },
      { title: "Cuidado", text: "O procedimento é explicado e realizado com calma." },
      { title: "Saída", text: "Você recebe orientações para casa e tira as últimas dúvidas." }
    ],
    /* area = filtro da galeria. size: "wide" (largo), "tall" (alto) ou "" */
    gallery: [
      { image: "reception", caption: "Recepção com poltronas e luz natural", area: "Recepção", size: "wide" },
      { image: "room", caption: "Sala de atendimento preparada", area: "Sala de atendimento", size: "tall" },
      { image: "hallway", caption: "Corredor de acesso às salas", area: "Recepção", size: "" },
      { image: "instruments", caption: "Instrumentais organizados por procedimento", area: "Biossegurança", size: "" },
      { image: "towel", caption: "Toalhas limpas a cada atendimento", area: "Detalhes", size: "tall" },
      { image: "handwash", caption: "Higienização das mãos antes de começar", area: "Biossegurança", size: "" },
      { image: "lounge", caption: "Espaço de espera tranquilo", area: "Recepção", size: "wide" },
      { image: "cleaning", caption: "Limpeza das superfícies entre atendimentos", area: "Biossegurança", size: "" },
      { image: "shelf", caption: "Produtos de cuidado organizados", area: "Detalhes", size: "" },
      { image: "plant", caption: "Detalhes que deixam o ambiente acolhedor", area: "Detalhes", size: "" }
    ]
  },

  /* ------------------------------------------------------------------ */
  /* Serviços                                                            */
  /* ------------------------------------------------------------------ */
  servicesIntro: "Cada atendimento começa com uma avaliação. A partir dela, combinamos juntos o cuidado mais adequado para o seu caso. As descrições abaixo são gerais e não substituem a avaliação individual.",
  servicesDisclaimer: "A podologia não substitui o acompanhamento médico. Quando a avaliação indicar necessidade, você será orientado a procurar o profissional de saúde adequado.",
  services: [
    {
      id: "avaliacao",
      name: "Avaliação podológica",
      image: "exam",
      short: "O ponto de partida: uma análise completa da pele, das unhas e da pisada.",
      description: "Na avaliação, observamos com calma a pele, as unhas, os pontos de pressão e o tipo de calçado que você usa no dia a dia. Também conversamos sobre seu histórico, sua rotina e o que motivou a consulta.",
      goal: "Entender o que seus pés precisam e definir, junto com você, quais cuidados fazem sentido agora e quais podem ficar para depois.",
      how: ["Conversa sobre rotina, calçados e histórico", "Observação de pele, unhas e áreas de pressão", "Explicação do que foi observado, em linguagem simples", "Sugestão de plano de cuidados e intervalo de retorno"],
      forWho: ["Primeira consulta", "Quem quer prevenir incômodos", "Quem sente dor ou desconforto sem saber a causa"],
      info: ["Duração média ilustrativa: 50 minutos", "Se possível, traga os calçados que você mais usa", "Informe medicamentos e condições de saúde em acompanhamento"]
    },
    {
      id: "unhas-encravadas",
      name: "Unhas encravadas",
      image: "heel",
      short: "Cuidado técnico e cuidadoso para aliviar o incômodo e orientar a prevenção.",
      description: "A unha encravada acontece quando a borda da unha pressiona ou penetra a pele ao redor. O atendimento podológico cuida da região com técnica e delicadeza, sempre respeitando a sua sensibilidade.",
      goal: "Reduzir o desconforto causado pela borda da unha e orientar sobre corte, calçados e hábitos que ajudam a evitar novos episódios.",
      how: ["Avaliação da unha e da pele ao redor", "Manejo cuidadoso da borda da unha", "Orientação sobre corte correto e calçados", "Indicação de retorno, quando necessário"],
      forWho: ["Dor ou pressão na lateral da unha", "Episódios que se repetem", "Esportistas e quem usa calçado fechado por muitas horas"],
      info: ["Em caso de inflamação intensa, secreção ou febre, procure atendimento médico", "Evite cortar a região em casa antes da consulta", "Use um calçado aberto ou folgado no dia do atendimento"]
    },
    {
      id: "calos",
      name: "Calos e calosidades",
      image: "massage",
      short: "Remoção cuidadosa de áreas de pele endurecida, com foco no conforto ao caminhar.",
      description: "Calos e calosidades são espessamentos da pele que surgem em áreas de atrito ou pressão. O cuidado podológico reduz essas áreas de forma gradual e confortável, e investigamos juntos o que pode estar causando o atrito.",
      goal: "Trazer mais conforto para caminhar e identificar fatores do dia a dia, como calçados ou forma de pisar, que contribuem para o problema.",
      how: ["Identificação das áreas de pressão", "Redução cuidadosa da pele endurecida", "Hidratação da região", "Orientações sobre calçados e proteção"],
      forWho: ["Pele grossa ou ardência ao caminhar", "Corredores e quem passa o dia em pé", "Quem usa calçados de bico fino ou salto"],
      info: ["Não use lixas ou lâminas em casa nas áreas que serão tratadas", "Calos que voltam com frequência merecem investigação da causa", "Dor intensa ao pisar deve ser avaliada também por um médico"]
    },
    {
      id: "unhas-espessas",
      name: "Unhas espessas ou frágeis",
      image: "feetTowel",
      short: "Cuidado com unhas grossas, quebradiças ou com alteração de cor.",
      description: "Unhas podem ficar mais grossas, frágeis ou mudar de cor por vários motivos, como traumas repetidos, calçados apertados ou outras condições. O atendimento cuida do aspecto e do conforto da unha e ajuda a identificar quando é preciso investigar mais.",
      goal: "Deixar a unha mais confortável e bem cuidada, e orientar sobre quando procurar um médico para investigar a causa da alteração.",
      how: ["Avaliação da unha e do histórico", "Desbaste e limpeza cuidadosos", "Orientação sobre cuidados e calçados", "Encaminhamento médico quando indicado"],
      forWho: ["Unhas grossas que incomodam no calçado", "Unhas que quebram ou descamam", "Alterações de cor ou formato (com avaliação médica em paralelo)"],
      info: ["Alterações de cor ou formato devem ser investigadas por um médico", "Evite esmalte nos dias anteriores à consulta", "Os cuidados costumam ser contínuos, com retornos periódicos"]
    },
    {
      id: "pes-sensiveis",
      name: "Pés sensíveis e diabéticos",
      image: "feetHands",
      short: "Atendimento atento para pessoas com diabetes, idosos e gestantes.",
      description: "Algumas pessoas precisam de cuidado redobrado com os pés, como quem tem diabetes, pessoas idosas e gestantes. O atendimento é feito com ainda mais atenção à pele, à sensibilidade e à circulação, sempre em complemento ao acompanhamento médico.",
      goal: "Oferecer um cuidado seguro e preventivo, ajudando a pessoa e a família a perceberem sinais de alerta no dia a dia.",
      how: ["Conversa sobre condições de saúde e acompanhamento médico", "Avaliação cuidadosa da pele e das unhas", "Procedimentos com técnica suave", "Orientações para a pessoa e para quem cuida dela"],
      forWho: ["Pessoas com diabetes", "Idosos e quem tem mobilidade reduzida", "Gestantes"],
      info: ["Traga informações sobre seu tratamento atual, se tiver", "Acompanhantes são bem-vindos", "Este atendimento não substitui consultas médicas regulares"]
    },
    {
      id: "hidratacao",
      name: "Pele ressecada e rachaduras",
      image: "cream",
      short: "Cuidado com ressecamento e fissuras nos calcanhares.",
      description: "O ressecamento intenso pode levar a rachaduras nos calcanhares, que incomodam e podem doer ao caminhar. O atendimento cuida da pele endurecida e indica uma rotina de hidratação adequada ao seu tipo de pele.",
      goal: "Deixar a pele mais macia e confortável e criar com você uma rotina simples de cuidados em casa.",
      how: ["Avaliação da pele e das fissuras", "Redução cuidadosa da pele endurecida", "Hidratação durante o atendimento", "Indicação de rotina de cuidados para casa"],
      forWho: ["Calcanhares ressecados ou com fissuras", "Quem usa sandálias com frequência", "Pele que racha no inverno"],
      info: ["Rachaduras com sangramento ou dor forte devem ser avaliadas", "A melhora depende da continuidade dos cuidados em casa", "Informe se você tem alergia a algum produto"]
    }
  ],

  /* ------------------------------------------------------------------ */
  /* Avaliações (EXEMPLOS FICTÍCIOS)                                     */
  /* Substitua apenas por relatos verdadeiros, com autorização, e troque */
  /* reviewsAreReal para true.                                           */
  /* ------------------------------------------------------------------ */
  reviewsAreReal: false,
  reviewsIntro: "Cada pessoa chega ao consultório com uma história diferente. Os relatos abaixo mostram como um profissional pode apresentar a experiência de quem foi atendido.",
  reviewsDemoNote: "Todos os depoimentos desta página são exemplos fictícios, escritos apenas para demonstrar o layout. Eles não são avaliações de pacientes reais.",
  reviews: [
    { featured: true, name: "Marcos V.", context: "Unha encravada", text: "Cheguei com bastante incômodo e muito receio. O Rafael explicou cada etapa antes de começar, foi extremamente cuidadoso e ainda me ensinou a cortar as unhas do jeito certo. Saí aliviado e sabendo o que fazer daqui para frente." },
    { name: "Ana P.", context: "Primeira consulta", text: "Eu adiava a consulta por vergonha dos meus pés. Fui recebida com tanta naturalidade que esqueci o nervosismo nos primeiros minutos." },
    { name: "Ricardo M.", context: "Acompanhou a mãe", text: "Levei minha mãe, que tem os pés bem sensíveis. Gostei da paciência e de como cada etapa foi explicada para ela antes de começar." },
    { name: "Carla S.", context: "Atendimento de rotina", text: "Ambiente impecável, pontualidade e muita atenção. As dicas sobre calçado já mudaram minha rotina." },
    { name: "Seu Antônio", context: "Pés sensíveis", text: "Tenho diabetes e sempre tive receio. Ele olhou tudo com cuidado e me ensinou o que observar todos os dias." },
    { name: "Fernanda L.", context: "Corredora amadora", text: "Corro três vezes por semana e vivia com calos. Além do cuidado, entendi o que no meu tênis estava causando o atrito." },
    { name: "Beatriz R.", context: "Retorno", text: "Gosto de ver o material sendo aberto na minha frente. Passa muita segurança." },
    { name: "Juliana T.", context: "Gestante", text: "Na gravidez, meus pés incharam e eu não conseguia me cuidar sozinha. Foi um alívio ter um atendimento tão tranquilo." }
  ],

  /* ------------------------------------------------------------------ */
  /* Contato e agendamento                                               */
  /* ------------------------------------------------------------------ */
  contactPage: {
    heroTitle: "Vamos marcar o seu *horário*?",
    heroLead: "O agendamento é feito pelo WhatsApp. Conte brevemente o que você sente e escolha o melhor dia entre os horários disponíveis.",
    howTo: [
      { title: "Envie uma mensagem", text: "Diga seu nome e, se quiser, o que tem incomodado." },
      { title: "Escolha o horário", text: "Você recebe as opções disponíveis para os próximos dias." },
      { title: "Receba a confirmação", text: "Enviamos o endereço e algumas orientações para o dia." }
    ]
  },
  faq: [
    { q: "Preciso de pedido médico para agendar?", a: "Não. Você pode agendar diretamente. Se tiver exames ou informações sobre seu tratamento, traga no dia da consulta." },
    { q: "Quanto tempo dura a consulta?", a: "A primeira consulta costuma levar cerca de 50 minutos (tempo ilustrativo), porque inclui a conversa e a avaliação completa." },
    { q: "Como devo ir no dia do atendimento?", a: "Use, de preferência, um calçado confortável. Evite passar esmalte ou cortar as unhas nos dias anteriores." },
    { q: "Posso levar um acompanhante?", a: "Sim. Acompanhantes são bem-vindos, principalmente para pessoas idosas ou com mobilidade reduzida." },
    { q: "E se eu precisar remarcar?", a: "Avise pelo WhatsApp com pelo menos 24 horas de antecedência para que o horário possa ser oferecido a outra pessoa." },
    { q: "A podologia substitui o médico?", a: "Não. A podologia cuida da saúde dos pés e trabalha em conjunto com o acompanhamento médico. Quando necessário, você é orientado a procurar o profissional adequado." }
  ],

  /* ------------------------------------------------------------------ */
  /* Aparência                                                           */
  /* ------------------------------------------------------------------ */
  theme: {
    defaultPalette: "azul-petroleo",
    storageKey: "podologia-studio:elegance:theme:v2"
  }
};
