/* ==========================================================================
   PALETAS PREDEFINIDAS — Elegance
   Cada paleta define 8 cores-base e um raio de borda (personalidade).
   As cores de texto sobre botões, links e seções escuras são calculadas
   automaticamente pelo motor de temas para manter a legibilidade.

   Papel de cada cor:
     primary     cor principal (botões, links, destaques)
     secondary   cor de apoio (faixas e fundos suaves)
     accent      cor de destaque (detalhes, números, filetes)
     background  fundo geral da página
     surface     fundo de cartões
     text        texto principal
     muted       texto secundário
     deep        seções escuras e base do rodapé

   Para criar uma paleta: copie um bloco e troque id, nome, clima e cores.
   No personalizador, "Copiar como paleta" gera um bloco pronto.
   ========================================================================== */

window.PS = window.PS || {};

window.PS.palettes = [
  {
    id: "azul-petroleo",
    name: "Azul-Petróleo",
    mood: "Identidade original",
    radius: 4,
    colors: {
      primary: "#174c57",
      secondary: "#e9e5da",
      accent: "#b77b54",
      background: "#f4f7f5",
      surface: "#ffffff",
      text: "#29383b",
      muted: "#56666a",
      deep: "#12343d"
    }
  },
  {
    id: "azul-marinho",
    name: "Azul-Marinho",
    mood: "Clássico e profissional",
    radius: 4,
    colors: {
      primary: "#1f3a68",
      secondary: "#e3e7ee",
      accent: "#b08d57",
      background: "#f6f7fa",
      surface: "#ffffff",
      text: "#1b2433",
      muted: "#535e71",
      deep: "#14233f"
    }
  },
  {
    id: "verde-escuro",
    name: "Verde-Escuro",
    mood: "Natural e sofisticado",
    radius: 6,
    colors: {
      primary: "#234a3a",
      secondary: "#e6e2d4",
      accent: "#a68754",
      background: "#f5f6f2",
      surface: "#ffffff",
      text: "#1f2b25",
      muted: "#55625a",
      deep: "#18342a"
    }
  },
  {
    id: "bordo",
    name: "Bordô",
    mood: "Elegante e marcante",
    radius: 4,
    colors: {
      primary: "#6e2335",
      secondary: "#efe3df",
      accent: "#b5856a",
      background: "#faf7f6",
      surface: "#ffffff",
      text: "#2c1f22",
      muted: "#69595c",
      deep: "#3e1620"
    }
  },
  {
    id: "grafite-cobre",
    name: "Grafite & Cobre",
    mood: "Contemporâneo",
    radius: 2,
    colors: {
      primary: "#2f3437",
      secondary: "#e8e3dd",
      accent: "#b06d43",
      background: "#f5f4f2",
      surface: "#ffffff",
      text: "#222527",
      muted: "#5c6164",
      deep: "#1e2224"
    }
  },
  {
    id: "areia-chocolate",
    name: "Areia & Chocolate",
    mood: "Acolhedor e premium",
    radius: 8,
    colors: {
      primary: "#5a3a2a",
      secondary: "#eadfcf",
      accent: "#b4885a",
      background: "#f8f4ee",
      surface: "#fffdf9",
      text: "#2e221b",
      muted: "#695a4f",
      deep: "#3a271d"
    }
  },
  {
    id: "cinza-azul",
    name: "Cinza & Azul",
    mood: "Minimalista",
    radius: 2,
    colors: {
      primary: "#3b5871",
      secondary: "#e5e8eb",
      accent: "#8aa5bc",
      background: "#f7f8f9",
      surface: "#ffffff",
      text: "#1f2933",
      muted: "#58646f",
      deep: "#253a4c"
    }
  },
  {
    id: "preto-champagne",
    name: "Preto & Champagne",
    mood: "Luxuoso e noturno",
    radius: 2,
    colors: {
      primary: "#d2bd92",
      secondary: "#2a2724",
      accent: "#e6d6b3",
      background: "#141413",
      surface: "#1d1c1a",
      text: "#f2ede3",
      muted: "#b3ab9e",
      deep: "#26231f"
    }
  },
  {
    id: "verde-esmeralda",
    name: "Verde-Esmeralda",
    mood: "Moderno e refinado",
    radius: 6,
    colors: {
      primary: "#0e6553",
      secondary: "#dcebe4",
      accent: "#c29d57",
      background: "#f4f8f6",
      surface: "#ffffff",
      text: "#13302a",
      muted: "#4d635d",
      deep: "#0b3f34"
    }
  }
];
