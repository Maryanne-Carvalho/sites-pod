/* ==========================================================================
   MOTOR DE TEMAS — Elegance
   Recebe uma paleta (+ ajustes manuais), calcula as cores derivadas que
   garantem legibilidade (WCAG AA) e aplica tudo como variáveis CSS no
   <html>. Não depende do personalizador: no site publicado, basta
   PS.theme.init() com a paleta padrão de js/content.js.

   Cores editáveis à mão: principal, secundária, destaque, fundo e texto.

   A escolha acompanha o visitante por TODAS as páginas. Fica guardada em:
     1. localStorage (permanece entre visitas);
     2. window.name (permanece entre páginas da mesma aba, mesmo quando o
        navegador bloqueia o localStorage em arquivos abertos localmente).
   Abas abertas ao mesmo tempo também são sincronizadas.
   ========================================================================== */

window.PS = window.PS || {};

window.PS.theme = (function () {
  "use strict";

  var C = window.PS.color;
  var content = window.PS.content || {};
  var config = content.theme || {};
  var palettes = window.PS.palettes;
  var root = document.documentElement;

  var EDITABLE = ["primary", "secondary", "accent", "background", "text"];
  var LABELS = {
    primary: "Cor principal",
    secondary: "Cor secundária",
    accent: "Cor de destaque",
    background: "Cor de fundo",
    text: "Cor dos textos"
  };

  /* Sem personalizador (site publicado), a paleta é sempre a padrão */
  var studio = (content.site && content.site.studio) || {};
  var persist = studio.showCustomizer !== false;

  var state = {
    paletteId: config.defaultPalette,
    overrides: {}
  };

  var transitionTimer = null;
  var lastResult = null;

  function getPalette(id) {
    for (var i = 0; i < palettes.length; i++) {
      if (palettes[i].id === id) return palettes[i];
    }
    return palettes[0];
  }

  /* ---------- Cálculo das cores ---------- */
  function compute(palette, overrides) {
    var ov = {};
    Object.keys(overrides || {}).forEach(function (k) {
      var v = C.normalizeHex(overrides[k]);
      if (v && EDITABLE.indexOf(k) !== -1) ov[k] = v;
    });

    var base = {};
    Object.keys(palette.colors).forEach(function (k) { base[k] = C.normalizeHex(palette.colors[k]); });

    var c = Object.assign({}, base, ov);
    var paletteDark = C.isDark(base.background);
    var darkTheme = C.isDark(c.background);
    var flipped = darkTheme !== paletteDark;

    // Fundo trocado: cartões e (se o tema virou claro/escuro) cores dependentes
    if (ov.background) {
      c.surface = darkTheme ? C.mix("#ffffff", c.background, 0.06) : C.mix("#ffffff", c.background, 0.6);
      if (flipped) {
        c.deep = darkTheme ? C.mix("#ffffff", c.background, 0.08) : C.mix(c.primary, "#151515", 0.4);
        if (!ov.secondary) c.secondary = C.mix(c.primary, c.background, darkTheme ? 0.22 : 0.18);
        if (!ov.text) c.text = darkTheme ? C.mix("#ffffff", c.background, 0.92) : C.mix("#000000", c.background, 0.86);
      }
    }
    // Texto secundário acompanha texto e fundo quando algum deles muda
    if (ov.background || ov.text) c.muted = C.mix(c.text, c.background, 0.68);

    var lightInk = darkTheme ? c.text : "#ffffff";
    var darkInk = darkTheme ? c.background : c.text;

    // Fundos "claros" onde aparecem textos (iguais aos color-mix do CSS)
    var secondarySoft = C.mix(c.secondary, c.background, 0.55);
    var primarySoft = C.mix(c.primary, c.surface, 0.12);
    var accentSoft = C.mix(c.accent, c.surface, 0.22);
    var readingBgs = [c.background, c.surface, secondarySoft];

    var text = C.ensureContrast(c.text, readingBgs, 4.5);
    var muted = C.ensureContrast(c.muted, readingBgs, 4.5);

    var onPrimaryPref = C.luminance(c.primary) < 0.3 ? [lightInk, "#ffffff", darkInk, "#111111"] : [darkInk, "#111111", lightInk, "#ffffff"];
    var onPrimary = C.pickReadable(c.primary, onPrimaryPref, 4.5);
    var onAccent = C.pickReadable(c.accent, [darkInk, "#111111", lightInk, "#ffffff"], 4.5);

    var primaryInk = C.ensureContrast(c.primary, readingBgs.concat([primarySoft]), 4.5);
    var accentInk = C.ensureContrast(c.accent, readingBgs.concat([accentSoft]), 4.5);

    var onDeep = C.pickReadable(c.deep, [c.background, c.surface, "#ffffff", c.text], 7);
    var footerBg = C.mix(c.deep, "#000000", 0.88);
    var accentOnDeep = C.ensureContrast(c.accent, [c.deep, footerBg], 4.5);
    var mutedOnDeep = C.ensureContrast(C.mix(onDeep, c.deep, 0.78), [c.deep, footerBg], 4.5);

    var tokens = {
      "--color-primary": c.primary,
      "--color-secondary": c.secondary,
      "--color-accent": c.accent,
      "--color-background": c.background,
      "--color-surface": c.surface,
      "--color-text": text,
      "--color-muted": muted,
      "--color-deep": c.deep,
      "--color-on-primary": onPrimary,
      "--color-on-accent": onAccent,
      "--color-on-deep": onDeep,
      "--color-primary-ink": primaryInk,
      "--color-accent-ink": accentInk,
      "--color-accent-on-deep": accentOnDeep,
      "--color-muted-on-deep": mutedOnDeep,
      "--radius-base": (palette.radius || 14) + "px"
    };

    var checks = [
      { id: "text", name: "Texto sobre o fundo", fg: text, bg: c.background },
      { id: "muted", name: "Texto secundário", fg: muted, bg: c.background },
      { id: "card", name: "Texto nos cartões", fg: text, bg: c.surface },
      { id: "button", name: "Botão principal", fg: onPrimary, bg: c.primary },
      { id: "link", name: "Links e destaques", fg: primaryInk, bg: c.background },
      { id: "deep", name: "Seções escuras", fg: onDeep, bg: c.deep }
    ].map(function (chk) {
      chk.ratio = C.contrast(chk.fg, chk.bg);
      chk.grade = C.grade(chk.ratio);
      return chk;
    });

    // Avisos: quando a cor escolhida à mão foi adaptada para manter a leitura
    var notes = [];
    if (ov.text && text !== ov.text) {
      notes.push({ key: "text", chosen: ov.text, applied: text,
        message: "Texto: para manter a leitura, o site usa " + text.toUpperCase() + " no lugar de " + ov.text.toUpperCase() + "." });
    }
    if (ov.primary && primaryInk !== ov.primary) {
      notes.push({ key: "primary", chosen: ov.primary, applied: primaryInk,
        message: "Cor principal: em links e textos aparece como " + primaryInk.toUpperCase() + " (versão mais legível). Nos botões, a cor escolhida é mantida." });
    }
    if (ov.accent && accentInk !== ov.accent) {
      notes.push({ key: "accent", chosen: ov.accent, applied: accentInk,
        message: "Destaque: em textos pequenos aparece como " + accentInk.toUpperCase() + "." });
    }
    if (ov.background) {
      notes.push({ key: "background", chosen: ov.background, applied: ov.background,
        message: "Fundo: cartões" + (flipped ? ", seções escuras, cor secundária e textos" : " e texto secundário") + " foram recalculados para combinar." });
    }

    return { colors: c, tokens: tokens, checks: checks, notes: notes, dark: darkTheme };
  }

  /* ---------- Aplicação ---------- */
  function apply(options) {
    var opts = options || {};
    var palette = getPalette(state.paletteId);
    var result = compute(palette, state.overrides);

    if (opts.animate !== false) {
      root.classList.add("is-theming");
      clearTimeout(transitionTimer);
      transitionTimer = setTimeout(function () { root.classList.remove("is-theming"); }, 650);
    }

    Object.keys(result.tokens).forEach(function (name) {
      root.style.setProperty(name, result.tokens[name]);
    });
    root.style.colorScheme = result.dark ? "dark" : "light";
    root.setAttribute("data-palette", palette.id);
    root.setAttribute("data-theme", result.dark ? "dark" : "light");

    var meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute("content", result.colors.background);

    lastResult = {
      palette: palette,
      overrides: Object.assign({}, state.overrides),
      customized: Object.keys(state.overrides).length > 0,
      colors: result.colors,
      tokens: result.tokens,
      checks: result.checks,
      notes: result.notes,
      dark: result.dark
    };

    if (opts.save !== false) save();
    document.dispatchEvent(new CustomEvent("ps:themechange", { detail: lastResult }));
    return lastResult;
  }

  /* ---------- Persistência (falha em silêncio) ---------- */
  var NAME_PREFIX = "ps-elegance:";

  function serialize() {
    return JSON.stringify({ paletteId: state.paletteId, overrides: state.overrides });
  }

  function save() {
    if (!persist) return;
    var data = serialize();
    try { localStorage.setItem(config.storageKey, data); } catch (e) { /* sem localStorage */ }
    try { window.name = NAME_PREFIX + data; } catch (e) { /* sem window.name */ }
  }

  function parse(raw) {
    if (!raw) return false;
    try {
      var data = JSON.parse(raw);
      if (!data || typeof data.paletteId !== "string") return false;
      state.paletteId = getPalette(data.paletteId).id;
      state.overrides = {};
      if (data.overrides && typeof data.overrides === "object") {
        EDITABLE.forEach(function (k) {
          var v = C.normalizeHex(data.overrides[k]);
          if (v) state.overrides[k] = v;
        });
      }
      return true;
    } catch (e) { return false; }
  }

  function load() {
    if (!persist) return;
    var fromStorage = null;
    try { fromStorage = localStorage.getItem(config.storageKey); } catch (e) { fromStorage = null; }
    if (parse(fromStorage)) return;
    try {
      if (typeof window.name === "string" && window.name.indexOf(NAME_PREFIX) === 0) {
        parse(window.name.slice(NAME_PREFIX.length));
      }
    } catch (e) { /* usa o padrão */ }
  }

  // Mantém abas abertas ao mesmo tempo com a mesma paleta
  window.addEventListener("storage", function (event) {
    if (!persist || event.key !== config.storageKey || !event.newValue) return;
    if (parse(event.newValue)) apply({ animate: true, save: false });
  });

  /* ---------- API pública ---------- */
  function setPalette(id) {
    state.paletteId = getPalette(id).id;
    state.overrides = {};
    return apply();
  }

  function setOverride(key, hex, opts) {
    var v = C.normalizeHex(hex);
    if (!v || EDITABLE.indexOf(key) === -1) return lastResult;
    var base = C.normalizeHex(getPalette(state.paletteId).colors[key]);
    if (v === base) delete state.overrides[key];
    else state.overrides[key] = v;
    return apply(opts);
  }

  function clearOverride(key, opts) {
    delete state.overrides[key];
    return apply(opts);
  }

  function restore() {
    state.overrides = {};
    return apply();
  }

  function resetOriginal() {
    state.paletteId = getPalette(config.defaultPalette).id;
    state.overrides = {};
    return apply();
  }

  function exportCss() {
    if (!lastResult) return "";
    var lines = Object.keys(lastResult.tokens).map(function (k) {
      return "  " + k + ": " + lastResult.tokens[k] + ";";
    });
    var brand = content.brand && content.brand.name ? content.brand.name + " — " : "";
    return "/* " + brand + "paleta \"" + lastResult.palette.name + "\"" +
      (lastResult.customized ? " (personalizada)" : "") + " */\n:root {\n" + lines.join("\n") + "\n}\n";
  }

  function exportPalette() {
    if (!lastResult) return "";
    var c = lastResult.colors;
    var keys = ["primary", "secondary", "accent", "background", "surface", "text", "muted", "deep"];
    var name = lastResult.palette.name + (lastResult.customized ? " (personalizada)" : "");
    var id = lastResult.palette.id + (lastResult.customized ? "-personalizada" : "");
    return "  {\n" +
      "    id: \"" + id + "\",\n" +
      "    name: \"" + name + "\",\n" +
      "    mood: \"" + lastResult.palette.mood + "\",\n" +
      "    radius: " + (lastResult.palette.radius || 4) + ",\n" +
      "    colors: {\n" +
      keys.map(function (k) { return "      " + k + ": \"" + c[k] + "\""; }).join(",\n") +
      "\n    }\n  },\n";
  }

  function init() {
    load();
    return apply({ animate: false });
  }

  return {
    init: init,
    setPalette: setPalette,
    setOverride: setOverride,
    clearOverride: clearOverride,
    restore: restore,
    resetOriginal: resetOriginal,
    exportCss: exportCss,
    exportPalette: exportPalette,
    compute: compute,
    getPalette: getPalette,
    getState: function () { return lastResult; },
    editable: EDITABLE.slice(),
    labels: LABELS
  };
})();
