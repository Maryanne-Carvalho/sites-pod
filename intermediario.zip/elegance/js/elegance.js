/* ==========================================================================
   ELEGANCE — montagem das páginas e interações
   1. Ícones, cabeçalho, rodapé e camada do modelo (iguais nas seis páginas)
   2. Textos e listas a partir de js/content.js
   3. Fotos com quadro alternativo
   4. WhatsApp, telefone, e-mail e mapa conforme o modo de demonstração
   5. Menu móvel, FAQ, galeria com filtros e ampliação, índice de serviços,
      revelação ao rolar, voltar ao topo e avisos
   O personalizador de cores fica em js/customizer.js.
   ========================================================================== */

(function () {
  "use strict";

  var PS = window.PS;
  var C = PS.content;
  var SITE = C.site || {};
  var STUDIO = SITE.studio || {};
  var DEMO = SITE.demoMode !== false;
  var page = document.body.getAttribute("data-page") || "inicio";
  var reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  var root = document.documentElement;

  if (!DEMO) root.classList.add("is-live");

  /* Páginas do site, na ordem do menu */
  var PAGES = [
    { id: "inicio", href: "index.html", label: "Início", intro: "A apresentação do consultório e do profissional.", image: "heroHands" },
    { id: "sobre", href: "sobre.html", label: "Sobre mim", intro: "História, formação, filosofia e trajetória.", image: "portrait" },
    { id: "clinica", href: "clinica.html", label: "A clínica", intro: "Ambientes, galeria, biossegurança e informações úteis.", image: "reception" },
    { id: "servicos", href: "servicos.html", label: "Serviços", intro: "Seis atendimentos explicados em detalhes.", image: "exam" },
    { id: "avaliacoes", href: "avaliacoes.html", label: "Avaliações", intro: "A experiência de quem é atendido.", image: "care" },
    { id: "contato", href: "contato.html", label: "Contato", intro: "WhatsApp, endereço, horários e dúvidas frequentes.", image: "hallway" }
  ];

  /* ------------------------------------------------------------------ */
  /* Utilitários                                                         */
  /* ------------------------------------------------------------------ */
  function esc(value) {
    return String(value == null ? "" : value)
      .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
  }

  /* Texto com *destaque* → <em>destaque</em>, sempre escapado */
  function rich(value) {
    return esc(value).replace(/\*([^*]+)\*/g, "<em>$1</em>");
  }

  function get(path) {
    return path.split(".").reduce(function (obj, key) { return obj == null ? undefined : obj[key]; }, C);
  }

  function $(sel, ctx) { return (ctx || document).querySelector(sel); }
  function $all(sel, ctx) { return Array.prototype.slice.call((ctx || document).querySelectorAll(sel)); }

  function icon(name, cls) {
    return '<svg class="icon' + (cls ? " " + cls : "") + '" aria-hidden="true"><use href="#i-' + name + '"/></svg>';
  }

  function pad(n) { return (n < 10 ? "0" : "") + n; }

  function fig(key, opts) {
    var o = opts || {};
    return '<figure class="ph ' + (o.cls || "") + '" data-img="' + esc(key) + '"' + (o.w ? ' data-w="' + o.w + '"' : "") + "></figure>";
  }

  function service(id) {
    for (var i = 0; i < C.services.length; i++) if (C.services[i].id === id) return C.services[i];
    return null;
  }

  function demoNote(text) {
    return '<p class="demo-note" data-demo-only>' + icon("info") + "<span>" + esc(text) + "</span></p>";
  }

  function firstName() { return (C.professional && (C.professional.firstName || C.professional.name)) || ""; }

  /* ------------------------------------------------------------------ */
  /* 1. Ícones                                                           */
  /* ------------------------------------------------------------------ */
  var ICONS = {
    foot: '<path d="M8.6 9.2c3.3-1 7.3-.2 8.2 2.6.8 2.4-1 4.3-1.8 6.6-.7 2-1.6 3.6-4.2 3.6-3 0-4.6-2.6-4.4-5.8.2-3.3-.9-6.1 2.2-7z"/><circle cx="8.4" cy="5.3" r="1.5"/><circle cx="11.6" cy="4.3" r="1.2"/><circle cx="14.3" cy="4.7" r="1"/><circle cx="16.4" cy="6" r=".9"/>',
    leaf: '<path d="M5 19C5 11 10 6 19.5 5 19.5 14 14.5 19 6 19z"/><path d="M5 19l8.5-8.5"/>',
    heart: '<path d="M12 20s-7.5-4.6-7.5-10.4A4.1 4.1 0 0 1 12 7.3a4.1 4.1 0 0 1 7.5 2.3C19.5 15.4 12 20 12 20z"/>',
    shield: '<path d="M12 3l7 3v5.2c0 4.8-3.3 8.3-7 9.8-3.7-1.5-7-5-7-9.8V6z"/><path d="M9 12l2.2 2.2L15.5 10"/>',
    ear: '<path d="M7 9a5 5 0 0 1 10 0c0 3-2.5 3.6-3 6-.4 2-1.6 3.5-3.5 3.5A2.5 2.5 0 0 1 8 16"/><path d="M10 9.5a2 2 0 0 1 4 0"/>',
    book: '<path d="M4 5.5A2.5 2.5 0 0 1 6.5 3H20v15H6.5A2.5 2.5 0 0 0 4 20.5z"/><path d="M4 20.5A2.5 2.5 0 0 1 6.5 18H20v3H6.5"/>',
    check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
    arrow: '<path d="M5 12h14M13 6l6 6-6 6"/>',
    "arrow-left": '<path d="M19 12H5M11 6l-6 6 6 6"/>',
    "arrow-up": '<path d="M12 19V5M6 11l6-6 6 6"/>',
    "arrow-ne": '<path d="M7 17L17 7M9 7h8v8"/>',
    chevron: '<path d="M6 9l6 6 6-6"/>',
    whatsapp: '<path d="M4 20.5l1.3-4.1A8.3 8.3 0 1 1 8.2 19.2z"/><path d="M9 8.6c-.4 3.5 2.9 6.8 6.4 6.4l.7-1.6-2-1-.9.9a4.3 4.3 0 0 1-2.5-2.5l.9-.9-1-2z"/>',
    phone: '<path d="M5 4h3.5l1.5 4-2 1.3a10 10 0 0 0 6.7 6.7L16 14l4 1.5V19a2 2 0 0 1-2 2A15 15 0 0 1 3 6a2 2 0 0 1 2-2z"/>',
    pin: '<path d="M12 21s-7-6.2-7-11.5a7 7 0 0 1 14 0C19 14.8 12 21 12 21z"/><circle cx="12" cy="9.5" r="2.5"/>',
    clock: '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>',
    mail: '<rect x="3.5" y="5.5" width="17" height="13" rx="2"/><path d="M4 7l8 6 8-6"/>',
    calendar: '<rect x="3.5" y="5" width="17" height="15.5" rx="2"/><path d="M3.5 10h17M8 3v4M16 3v4"/>',
    palette: '<path d="M12 3a9 9 0 1 0 0 18c1 0 1.6-.7 1.6-1.5 0-1.2-1-1.6-1-2.6 0-1 .8-1.6 1.9-1.6H17a4 4 0 0 0 4-4C21 6.8 17 3 12 3z"/><circle cx="7.4" cy="11.6" r="1.1"/><circle cx="9.6" cy="7.4" r="1.1"/><circle cx="14.4" cy="7.2" r="1.1"/>',
    close: '<path d="M6 6l12 12M18 6L6 18"/>',
    menu: '<path d="M4 8h16M4 16h16"/>',
    image: '<rect x="3.5" y="5" width="17" height="14" rx="2"/><circle cx="9" cy="10" r="1.6"/><path d="M20.5 15.5l-4.5-4.5-8.5 8"/>',
    user: '<circle cx="12" cy="8" r="4"/><path d="M4.5 20.5c1.4-3.7 4.3-5.5 7.5-5.5s6.1 1.8 7.5 5.5"/>',
    expand: '<path d="M14 4h6v6M10 20H4v-6M20 4l-7 7M4 20l7-7"/>',
    reset: '<path d="M4.5 12a7.5 7.5 0 1 0 2.4-5.5"/><path d="M4.5 4.5v4h4"/>',
    sparkle: '<path d="M12 4c.6 4.3 3.7 7.4 8 8-4.3.6-7.4 3.7-8 8-.6-4.3-3.7-7.4-8-8 4.3-.6 7.4-3.7 8-8z"/>',
    info: '<circle cx="12" cy="12" r="8.5"/><path d="M12 11v5M12 8h.01"/>',
    compare: '<rect x="3.5" y="4.5" width="7" height="15" rx="1.5"/><rect x="13.5" y="4.5" width="7" height="15" rx="1.5"/>',
    quote: '<path d="M10 7H6.5A2.5 2.5 0 0 0 4 9.5V13h6zM10 13c0 2.5-1.5 4-4 4.5M20 7h-3.5A2.5 2.5 0 0 0 14 9.5V13h6zM20 13c0 2.5-1.5 4-4 4.5"/>',
    link: '<path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1"/>',
    copy: '<rect x="8.5" y="8.5" width="11.5" height="11.5" rx="2"/><path d="M15.5 8.5V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v7.5a2 2 0 0 0 2 2h2.5"/>',
    code: '<path d="M8.5 7L3.5 12l5 5M15.5 7l5 5-5 5"/>',
    access: '<circle cx="12" cy="4.8" r="1.6"/><path d="M5.5 8.5l6.5 1.5 6.5-1.5M12 10v4.5M9 21l3-6.5 3 6.5"/>',
    car: '<path d="M5 16.5h14M6.5 16.5v2M17.5 16.5v2M4.5 16.5V12l2-5h11l2 5v4.5z"/><path d="M4.5 12h15"/><circle cx="8" cy="14" r=".6"/><circle cx="16" cy="14" r=".6"/>',
    card: '<rect x="3.5" y="6" width="17" height="12" rx="2"/><path d="M3.5 10h17M7 14.5h3"/>',
    instagram: '<rect x="4" y="4" width="16" height="16" rx="4.5"/><circle cx="12" cy="12" r="3.6"/><circle cx="16.6" cy="7.4" r=".6"/>',
    linkedin: '<rect x="4" y="4" width="16" height="16" rx="2.5"/><path d="M8 10.5V16M8 8v.01M11.5 16v-3.2a2 2 0 0 1 4 0V16M11.5 10.5V16"/>',
    star: '<path d="M12 4l2.4 5 5.4.6-4 3.7 1.1 5.4L12 16l-4.9 2.7 1.1-5.4-4-3.7 5.4-.6z"/>'
  };

  (function injectSprite() {
    var svg = '<svg xmlns="http://www.w3.org/2000/svg" width="0" height="0" style="position:absolute" aria-hidden="true" focusable="false">';
    Object.keys(ICONS).forEach(function (k) { svg += '<symbol id="i-' + k + '" viewBox="0 0 24 24">' + ICONS[k] + "</symbol>"; });
    document.body.insertAdjacentHTML("afterbegin", svg + "</svg>");
  })();

  function socialIcon(name) {
    var n = String(name || "").toLowerCase();
    if (n.indexOf("insta") === 0) return "instagram";
    if (n.indexOf("linked") === 0) return "linkedin";
    return "link";
  }

  function brandHtml(href, label) {
    return '<a class="brand" href="' + href + '" aria-label="' + esc(label) + '">' +
      '<span class="brand__mark" aria-hidden="true">' + esc(C.brand.monogram || (C.brand.wordmark || "E").charAt(0)) + "</span>" +
      '<span class="brand__text"><span class="brand__name">' + esc(C.brand.wordmark) + "</span>" +
      '<span class="brand__sub">' + esc(C.brand.wordmarkSub) + "</span></span></a>";
  }

  /* ------------------------------------------------------------------ */
  /* Contato: textos e links conforme o modo de demonstração             */
  /* ------------------------------------------------------------------ */
  function phoneHtml() {
    var p = C.contact.phone || {};
    if (!DEMO && p.dial) return '<a href="tel:' + esc(p.dial) + '">' + esc(p.display) + "</a>";
    return esc(p.display) + (DEMO ? ' <small data-demo-only>(demonstrativo)</small>' : "");
  }

  function emailHtml() {
    var e = C.contact.email;
    if (!e) return "";
    if (!DEMO) return '<a href="mailto:' + esc(e) + '">' + esc(e) + "</a>";
    return esc(e) + ' <small data-demo-only>(demonstrativo)</small>';
  }

  function socialItems() {
    return (C.contact.social || []).filter(function (s) { return s.url || (DEMO && s.handle); });
  }

  function socialHtml(cls) {
    return socialItems().map(function (s) {
      var label = esc(s.name) + (s.handle ? '<span class="sr-only">: </span><span class="social__handle">' + esc(s.handle) + "</span>" : "");
      if (s.url) return '<a class="' + cls + '" href="' + esc(s.url) + '" target="_blank" rel="noopener">' + icon(socialIcon(s.name)) + label + "</a>";
      return '<span class="' + cls + '">' + icon(socialIcon(s.name)) + label + "</span>";
    }).join("");
  }

  /* ------------------------------------------------------------------ */
  /* Cabeçalho, barra do modelo, rodapé e nota do modelo                 */
  /* ------------------------------------------------------------------ */
  function renderChrome() {
    var headerSlot = $("[data-site-header]");
    if (headerSlot) {
      var links = PAGES.map(function (p, i) {
        var current = p.id === page ? ' aria-current="page"' : "";
        return '<li><a class="nav__link" href="' + p.href + '"' + current + '><span class="nav__num" aria-hidden="true">' + pad(i + 1) + "</span>" + esc(p.label) + "</a></li>";
      }).join("");

      var bar = "";
      if (STUDIO.showBar !== false) {
        bar = '<div class="model-bar" role="note"><div class="container model-bar__inner">' +
          "<p><strong>" + esc(STUDIO.productName || "Elegance") + '</strong><span class="model-bar__tag">' + esc([STUDIO.modelName, STUDIO.version].filter(Boolean).join(" · ")) + "</span>" +
          '<span class="model-bar__long"> · modelo demonstrativo e personalizável, com conteúdo fictício</span></p>' +
          '<div class="model-bar__actions">' +
            (STUDIO.compareUrl ? '<a href="' + esc(STUDIO.compareUrl) + '">' + icon("compare") + "Comparar modelos</a>" : "") +
            '<button type="button" data-cz-open aria-controls="cz" aria-expanded="false">' + icon("palette") + "Cores</button>" +
          "</div></div></div>";
      }

      var h0 = C.contact.hours[0] || { days: "", time: "" };
      headerSlot.outerHTML = bar +
        '<header class="hdr" data-header><div class="container hdr__inner">' +
          brandHtml("index.html", C.brand.name + " — página inicial") +
          '<nav class="nav" id="site-nav" aria-label="Navegação principal" data-nav>' +
            '<ul class="nav__list" role="list">' + links + "</ul>" +
            '<div class="nav__extra">' +
              '<a class="btn btn--lg btn--block" href="contato.html" data-whatsapp>' + icon("whatsapp") + "Agendar pelo WhatsApp</a>" +
              "<p>" + esc(C.contact.address.line2) + "<br>" + esc(h0.days) + ", " + esc(h0.time) + "</p>" +
            "</div>" +
          "</nav>" +
          '<div class="hdr__actions">' +
            '<a class="btn btn--sm hdr__cta" href="contato.html" aria-label="Agendar um horário">' + icon("calendar") + '<span class="hdr__cta-text">Agendar</span></a>' +
            '<button class="menu-toggle" type="button" aria-expanded="false" aria-controls="site-nav" data-menu-toggle>' +
              '<span class="sr-only" data-menu-label>Abrir menu</span>' + icon("menu", "icon-open") + icon("close", "icon-close") +
            "</button>" +
          "</div>" +
        "</div></header>";
    }

    var footerSlot = $("[data-site-footer]");
    if (footerSlot) {
      var pageLinks = PAGES.map(function (p) {
        var current = p.id === page ? ' aria-current="page"' : "";
        return '<li><a href="' + p.href + '"' + current + ">" + esc(p.label) + "</a></li>";
      }).join("");
      var hours = C.contact.hours.map(function (h) {
        return "<li><span>" + esc(h.days) + "</span><span>" + esc(h.time) + "</span></li>";
      }).join("");
      var social = socialHtml("");

      var note = "";
      if (STUDIO.showTemplateNote !== false) {
        note = '<aside class="tpl-note" aria-labelledby="tpl-note-title"><div class="container tpl-note__inner">' +
          "<div>" +
            '<p class="tpl-note__kicker">' + esc(STUDIO.productName || "Elegance") + " · " + esc(STUDIO.modelName || "") + "</p>" +
            '<h2 class="tpl-note__title" id="tpl-note-title">Este site é um modelo. Tudo nele pode ser seu.</h2>' +
            '<p class="tpl-note__text">' + esc(C.professional.name) + " é um profissional fictício. No seu site, entram a sua marca, as suas cores, a sua história, os seus serviços e o seu contato.</p>" +
          "</div>" +
          '<ul class="tpl-note__list" role="list"><li>Cores</li><li>Identidade visual</li><li>Nome e história</li><li>Textos e serviços</li><li>Fotos</li><li>Contato e endereço</li></ul>' +
          '<button class="tpl-note__btn" type="button" data-cz-open aria-controls="cz" aria-expanded="false">' + icon("palette") + "Testar as cores da sua marca</button>" +
        "</div></aside>";
      }

      footerSlot.outerHTML =
        '<footer class="ftr"><div class="container">' +
          '<div class="ftr__top">' +
            '<p class="ftr__claim">' + rich(C.home.heroTitle) + "</p>" +
            '<a class="btn btn--on-deep btn--lg" href="contato.html">' + icon("calendar") + "Agendar um horário" + icon("arrow", "icon--go") + "</a>" +
          "</div>" +
          '<div class="ftr__grid">' +
            "<div>" + brandHtml("index.html", C.brand.name + " — voltar ao início") +
              '<p class="ftr__about">' + esc(C.professional.name) + ", " + esc(C.professional.role.toLowerCase()) + ". " + esc(C.brand.tagline) + ", em " + esc(C.brand.neighborhood) + ", " + esc(C.brand.city) + ".</p>" +
              (social ? '<div class="ftr__social">' + social + "</div>" : "") +
            "</div>" +
            '<nav aria-label="Páginas do site"><p class="ftr__title">Páginas</p><ul class="ftr__list" role="list">' + pageLinks + "</ul></nav>" +
            '<div><p class="ftr__title">Contato</p><ul class="ftr__list" role="list">' +
              '<li><a href="contato.html" data-whatsapp>WhatsApp ' + esc(C.contact.whatsapp.display) + "</a></li>" +
              "<li>" + phoneHtml() + "</li>" +
              "<li>" + emailHtml() + "</li>" +
              "<li>" + esc(C.contact.address.line1) + "<br>" + esc(C.contact.address.line2) + "</li>" +
            "</ul></div>" +
            '<div><p class="ftr__title">Horários</p><ul class="ftr__hours" role="list">' + hours + "</ul></div>" +
          "</div>" +
          '<div class="ftr__bottom">' +
            "<p>© <span data-year>2026</span> " + esc(C.brand.name) + '.<span data-demo-only> Modelo demonstrativo: profissional, depoimentos e contatos fictícios.</span> Não substitui orientação médica.</p>' +
            '<div class="ftr__bottom-actions">' +
              '<button type="button" data-cz-open aria-controls="cz" aria-expanded="false">' + icon("palette") + "Personalizar cores</button>" +
              '<button type="button" data-to-top-inline>' + icon("arrow-up") + "Voltar ao topo</button>" +
            "</div>" +
          "</div>" +
        "</div></footer>" + note;
    }
  }

  /* ------------------------------------------------------------------ */
  /* 2. Renderizadores de conteúdo                                       */
  /* ------------------------------------------------------------------ */
  var R = {};

  /* Início ----------------------------------------------------------- */
  R["home-hero-services"] = function () {
    return C.home.heroServices.map(function (s, i) {
      return '<li><span class="hh-svc__n">' + pad(i + 1) + "</span>" + esc(s) + "</li>";
    }).join("");
  };

  R["home-hero-facts"] = function () {
    return C.home.heroFacts.map(function (f) {
      return '<li><span class="hh-fact__v">' + esc(f.value) + '</span><span class="hh-fact__l">' + esc(f.label) + "</span></li>";
    }).join("");
  };

  R["home-highlights"] = function () {
    return C.home.highlights.map(function (h, i) {
      return '<li class="hl" data-reveal style="--reveal-delay:' + (i * 80) + 'ms"><span class="hl__n">' + pad(i + 1) + "</span>" +
        '<span class="hl__icon">' + icon(h.icon || "check") + "</span>" +
        "<h3>" + esc(h.title) + "</h3><p>" + esc(h.text) + "</p></li>";
    }).join("");
  };

  R["home-services"] = function () {
    return C.home.featuredServices.map(service).filter(Boolean).map(function (s, i) {
      var idx = C.services.indexOf(s) + 1;
      return '<li class="fsvc" data-reveal style="--reveal-delay:' + (i * 90) + 'ms">' +
        '<a class="fsvc__link" href="servicos.html#' + esc(s.id) + '">' +
          fig(s.image, { cls: "ph--land fsvc__img", w: 800 }) +
          '<span class="fsvc__n">' + pad(idx) + " / " + pad(C.services.length) + "</span>" +
          '<span class="fsvc__name">' + esc(s.name) + "</span>" +
          '<span class="fsvc__text">' + esc(s.short) + "</span>" +
          '<span class="fsvc__go">Ver detalhes' + icon("arrow") + "</span>" +
        "</a></li>";
    }).join("");
  };

  R["home-clinic-facts"] = function () {
    return C.home.clinicFacts.map(function (f) {
      return "<li>" + icon(f.icon || "check") + "<span>" + esc(f.text) + "</span></li>";
    }).join("");
  };

  R["home-gallery"] = function () {
    return C.clinic.gallery.slice(0, 3).map(function (g, i) {
      return '<li class="hc-col__item hc-col__item--' + (i + 1) + '">' + fig(g.image, { cls: "ph--fill", w: 900 }) + "</li>";
    }).join("");
  };

  R["home-steps"] = function () {
    return C.home.steps.map(function (s, i) {
      return '<li class="step" data-reveal style="--reveal-delay:' + (i * 90) + 'ms"><span class="step__n">' + pad(i + 1) + "</span><h3>" + esc(s.title) + "</h3><p>" + esc(s.text) + "</p></li>";
    }).join("");
  };

  R["home-reviews"] = function () {
    var feat = C.reviews.filter(function (r) { return r.featured; })[0] || C.reviews[0];
    var rest = C.reviews.filter(function (r) { return r !== feat; }).slice(0, 2);
    var tag = C.reviewsAreReal ? "" : '<span class="demo-tag" data-demo-only>Exemplo de demonstração</span>';
    return '<figure class="hr-feat" data-reveal>' +
        icon("quote", "hr-feat__mark") +
        '<blockquote><p>' + esc(feat.text) + "</p></blockquote>" +
        '<figcaption><strong>' + esc(feat.name) + "</strong><span>" + esc(feat.context) + "</span></figcaption>" + tag +
      "</figure>" +
      '<ul class="hr-side" role="list">' + rest.map(function (r) {
        return '<li class="hr-card" data-reveal><blockquote><p>' + esc(r.text) + "</p></blockquote>" +
          '<p class="hr-card__by"><strong>' + esc(r.name) + "</strong> · " + esc(r.context) + "</p>" + tag + "</li>";
      }).join("") + "</ul>";
  };

  R["explore"] = function () {
    return PAGES.filter(function (p) { return p.id !== page && p.id !== "inicio"; }).map(function (p) {
      var n = PAGES.indexOf(p) + 1;
      return '<li><a class="xpl" href="' + p.href + '">' +
        '<span class="xpl__n">' + pad(n) + "</span>" +
        '<span class="xpl__title">' + esc(p.label) + "</span>" +
        '<span class="xpl__text">' + esc(p.intro) + "</span>" +
        fig(p.image, { cls: "ph--square xpl__img", w: 300 }) +
        '<span class="xpl__go" aria-hidden="true">' + icon("arrow-ne") + "</span>" +
      "</a></li>";
    }).join("");
  };

  /* Sobre ------------------------------------------------------------ */
  R["about-numbers"] = function () {
    return C.about.numbers.map(function (n) {
      return '<li class="num"><span class="num__v">' + esc(n.value) + '</span><span class="num__l">' + esc(n.label) + "</span></li>";
    }).join("");
  };

  R["about-story"] = function () {
    return C.about.story.map(function (p) { return "<p>" + esc(p) + "</p>"; }).join("");
  };

  R["about-timeline"] = function () {
    return C.about.timeline.map(function (t, i) {
      return '<li class="tl__item" data-reveal style="--reveal-delay:' + (i * 90) + 'ms"><span class="tl__year">' + esc(t.year) + '</span><span class="tl__dot" aria-hidden="true"></span>' +
        '<div class="tl__body"><h3>' + esc(t.title) + "</h3><p>" + esc(t.text) + "</p></div></li>";
    }).join("");
  };

  R["about-education"] = function () {
    return C.about.education.map(function (e, i) {
      return '<li class="edu__item"><span class="edu__n">' + pad(i + 1) + '</span><div><h3>' + esc(e.title) + "</h3><p>" + esc(e.place) + "</p></div></li>";
    }).join("");
  };

  R["about-values"] = function () {
    return C.about.values.map(function (v, i) {
      return '<li class="val" data-reveal style="--reveal-delay:' + (i * 80) + 'ms"><span class="val__n">' + pad(i + 1) + "</span><h3>" + esc(v.title) + "</h3><p>" + esc(v.text) + "</p></li>";
    }).join("");
  };

  R["about-diff"] = function () {
    return C.home.highlights.map(function (h) {
      return "<li>" + icon("check") + "<span><strong>" + esc(h.title) + ".</strong> " + esc(h.text) + "</span></li>";
    }).join("");
  };

  /* Clínica ---------------------------------------------------------- */
  R["clinic-intro"] = function () {
    return C.clinic.intro.map(function (p) { return "<p>" + esc(p) + "</p>"; }).join("");
  };

  R["clinic-anchors"] = function () {
    return C.clinic.spaces.map(function (s) { return '<li><a href="#' + esc(s.id) + '">' + esc(s.title) + "</a></li>"; }).join("") +
      '<li><a href="#galeria">Galeria</a></li><li><a href="#biosseguranca">Biossegurança</a></li><li><a href="#informacoes">Informações úteis</a></li>';
  };

  R["clinic-spaces"] = function () {
    return C.clinic.spaces.map(function (s, i) {
      var points = s.points.map(function (p) { return "<li>" + icon("check") + "<span>" + esc(p) + "</span></li>"; }).join("");
      return '<article class="space' + (i % 2 ? " space--flip" : "") + '" id="' + esc(s.id) + '" data-reveal>' +
        '<div class="space__media">' + fig(s.image, { cls: "ph--land", w: 1100 }) + "</div>" +
        '<div class="space__body"><p class="space__n">' + pad(i + 1) + " — Ambiente</p><h3>" + esc(s.title) + "</h3><p>" + esc(s.text) + '</p><ul class="ticks" role="list">' + points + "</ul></div>" +
      "</article>";
    }).join("");
  };

  R["gallery-filters"] = function () {
    var areas = [];
    C.clinic.gallery.forEach(function (g) { if (areas.indexOf(g.area) === -1) areas.push(g.area); });
    return '<button type="button" class="gfilter" aria-pressed="true" data-filter="*">Todos <span>' + C.clinic.gallery.length + "</span></button>" +
      areas.map(function (a) {
        var n = C.clinic.gallery.filter(function (g) { return g.area === a; }).length;
        return '<button type="button" class="gfilter" aria-pressed="false" data-filter="' + esc(a) + '">' + esc(a) + " <span>" + n + "</span></button>";
      }).join("");
  };

  R["gallery"] = function () {
    return C.clinic.gallery.map(function (g, i) {
      return '<li class="gal__item' + (g.size ? " gal__item--" + g.size : "") + '" data-area="' + esc(g.area) + '">' +
        '<button type="button" class="gal__btn" data-lightbox-index="' + i + '" aria-label="Ampliar foto: ' + esc(g.caption) + '">' +
          fig(g.image, { cls: "ph--fill", w: g.size === "wide" ? 1200 : 800 }) +
          '<span class="gal__cap"><span>' + esc(g.area) + "</span>" + esc(g.caption) + "</span>" +
          '<span class="gal__zoom" aria-hidden="true">' + icon("expand") + "</span>" +
        "</button></li>";
    }).join("");
  };

  R["biosafety"] = function () {
    return C.clinic.biosafety.map(function (b, i) {
      return '<li class="bio__step" data-reveal style="--reveal-delay:' + (i * 70) + 'ms"><span class="bio__n">' + pad(i + 1) + "</span><div><h3>" + esc(b.title) + "</h3><p>" + esc(b.text) + "</p></div></li>";
    }).join("");
  };

  R["experience"] = function () {
    return C.clinic.experience.map(function (e, i) {
      return '<li class="xp__item" data-reveal style="--reveal-delay:' + (i * 80) + 'ms"><span class="xp__n">' + pad(i + 1) + "</span><h3>" + esc(e.title) + "</h3><p>" + esc(e.text) + "</p></li>";
    }).join("");
  };

  R["hours"] = function () {
    return C.contact.hours.map(function (h) {
      return "<li><span>" + esc(h.days) + "</span><span>" + esc(h.time) + "</span></li>";
    }).join("");
  };

  R["useful-info"] = function () {
    return (C.usefulInfo || []).map(function (u) {
      return '<li class="uinfo"><span class="uinfo__icon">' + icon(u.icon || "info") + "</span><div><h3>" + esc(u.title) + "</h3><p>" + esc(u.text) + "</p></div></li>";
    }).join("");
  };

  /* Serviços --------------------------------------------------------- */
  R["services-index"] = function () {
    return C.services.map(function (s, i) {
      return '<li><a href="#' + esc(s.id) + '" data-svc-link><span>' + pad(i + 1) + "</span>" + esc(s.name) + "</a></li>";
    }).join("");
  };

  R["services-count"] = function () { return String(C.services.length); };

  R["services-full"] = function () {
    return C.services.map(function (s, i) {
      var how = s.how.map(function (h) { return "<li>" + esc(h) + "</li>"; }).join("");
      var who = (s.forWho || []).map(function (h) { return "<li>" + icon("check") + "<span>" + esc(h) + "</span></li>"; }).join("");
      var info = s.info.map(function (h) { return "<li>" + icon("info") + "<span>" + esc(h) + "</span></li>"; }).join("");
      return '<article class="svc" id="' + esc(s.id) + '" aria-labelledby="' + esc(s.id) + '-t">' +
        '<header class="svc__head">' +
          '<p class="svc__count"><span>' + pad(i + 1) + "</span> / " + pad(C.services.length) + "</p>" +
          '<h2 id="' + esc(s.id) + '-t">' + esc(s.name) + "</h2>" +
          '<p class="svc__short">' + esc(s.short) + "</p>" +
        "</header>" +
        fig(s.image, { cls: "ph--wide svc__img", w: 1400 }) +
        '<div class="svc__grid">' +
          '<div class="svc__block svc__block--desc"><h3>Descrição</h3><p>' + esc(s.description) + "</p></div>" +
          '<div class="svc__block svc__block--goal"><h3>Objetivo</h3><p>' + esc(s.goal) + "</p></div>" +
          '<div class="svc__block"><h3>Como funciona</h3><ol class="svc__steps" role="list">' + how + "</ol></div>" +
          (who ? '<div class="svc__block"><h3>Para quem pode ser indicado</h3><ul class="ticks" role="list">' + who + "</ul></div>" : "") +
          '<aside class="svc__info" aria-label="Antes de agendar: ' + esc(s.name) + '"><h3>Antes de agendar</h3><ul role="list">' + info + "</ul>" +
            '<a class="btn btn--sm" href="contato.html" data-whatsapp data-service="' + esc(s.name) + '">' + icon("whatsapp") + "Pedir informações</a>" +
          "</aside>" +
        "</div>" +
      "</article>";
    }).join("");
  };

  /* Avaliações ------------------------------------------------------- */
  function reviewTag() {
    return C.reviewsAreReal ? "" : '<span class="demo-tag" data-demo-only>Exemplo de demonstração</span>';
  }

  R["review-featured"] = function () {
    var r = C.reviews.filter(function (x) { return x.featured; })[0] || C.reviews[0];
    return '<span class="feat-quote__mark" aria-hidden="true">“</span>' +
      '<blockquote class="feat-quote__text"><p>' + esc(r.text) + "</p></blockquote>" +
      '<figcaption class="feat-quote__by"><span class="rv__avatar" aria-hidden="true">' + esc(r.name.replace(/^(Seu|Dona)\s+/i, "").charAt(0)) + "</span><span><strong>" + esc(r.name) + "</strong>" + esc(r.context) + "</span></figcaption>" +
      reviewTag();
  };

  R["reviews-grid"] = function () {
    return C.reviews.filter(function (x) { return !x.featured; }).map(function (r, i) {
      var initial = r.name.replace(/^(Seu|Dona)\s+/i, "").charAt(0);
      return '<li class="rv' + (i % 3 === 1 ? " rv--tint" : "") + (i % 4 === 2 ? " rv--deep" : "") + '" data-reveal>' +
        icon("quote", "rv__mark") +
        "<blockquote><p>" + esc(r.text) + "</p></blockquote>" +
        '<div class="rv__by"><span class="rv__avatar" aria-hidden="true">' + esc(initial) + "</span>" +
          "<p><strong>" + esc(r.name) + "</strong><span>" + esc(r.context) + "</span></p></div>" +
        reviewTag() +
      "</li>";
    }).join("");
  };

  /* Contato ---------------------------------------------------------- */
  R["contact-cards"] = function () {
    var a = C.contact.address;
    var hours = C.contact.hours.map(function (h) { return "<li><span>" + esc(h.days) + "</span><span>" + esc(h.time) + "</span></li>"; }).join("");
    var social = socialHtml("ccard__social-link");
    var cards = [
      { ic: "whatsapp", label: "WhatsApp", body: '<p class="ccard__value">' + esc(C.contact.whatsapp.display) + '</p><a class="text-link" href="contato.html" data-whatsapp>Abrir conversa' + icon("arrow") + "</a>" },
      { ic: "phone", label: "Telefone", body: '<p class="ccard__value">' + phoneHtml() + "</p>" },
      { ic: "mail", label: "E-mail", body: '<p class="ccard__value ccard__value--sm">' + emailHtml() + "</p>" },
      { ic: "pin", label: "Endereço", body: '<p class="ccard__value ccard__value--sm">' + esc(a.line1) + "<br>" + esc(a.line2) + "</p><p class=\"ccard__extra\">" + esc(a.zip) + " · " + esc(a.reference) + '</p><a class="text-link" href="contato.html#onde" data-maps>Abrir no mapa' + icon("arrow") + "</a>" },
      { ic: "clock", label: "Horários", body: '<ul class="hours-list" role="list">' + hours + '</ul><p class="ccard__extra">' + esc(C.contact.hoursNote) + "</p>" },
      { ic: "instagram", label: "Redes sociais", body: social ? '<div class="ccard__social">' + social + "</div>" : '<p class="ccard__extra">As redes sociais aparecem aqui quando os endereços forem configurados.</p>' }
    ];
    return cards.map(function (c, i) {
      return '<li class="ccard" data-reveal style="--reveal-delay:' + (i * 60) + 'ms"><div class="ccard__head"><span class="ccard__icon">' + icon(c.ic) + '</span><p class="ccard__label">' + esc(c.label) + "</p></div>" + c.body + "</li>";
    }).join("");
  };

  R["howto"] = function () {
    return C.contactPage.howTo.map(function (h, i) {
      return '<li class="howto__item"><span class="howto__n">' + pad(i + 1) + "</span><h3>" + esc(h.title) + "</h3><p>" + esc(h.text) + "</p></li>";
    }).join("");
  };

  R["map"] = function () {
    if (C.contact.mapEmbedUrl) {
      return '<iframe class="map__frame" src="' + esc(C.contact.mapEmbedUrl) + '" title="Mapa com a localização do consultório" loading="lazy" referrerpolicy="no-referrer-when-downgrade" allowfullscreen></iframe>';
    }
    return '<div class="map__empty">' +
      '<svg class="map__lines" viewBox="0 0 400 260" preserveAspectRatio="xMidYMid slice" aria-hidden="true">' +
        '<path d="M-10 170 C80 150 140 190 220 160 S340 110 420 130"/><path d="M70 -10 L120 270"/><path d="M260 -10 C250 80 280 160 270 270"/>' +
        '<path class="thin" d="M-10 60 L420 48"/><path class="thin" d="M-10 220 L420 210"/><path class="thin" d="M180 -10 L196 270"/><path class="thin" d="M345 -10 L330 270"/>' +
      "</svg>" +
      '<span class="map__pin">' + icon("pin") + "</span>" +
      '<p class="map__msg"><strong>Espaço reservado para o mapa</strong>Quando o endereço real for definido, o mapa incorporado aparece aqui.</p>' +
    "</div>";
  };

  R["faq"] = function () {
    return C.faq.map(function (f, i) {
      return '<div class="accordion__item"><h3>' +
        '<button class="accordion__trigger" type="button" aria-expanded="false" aria-controls="faq-' + i + '" id="faq-' + i + '-btn">' +
          "<span>" + esc(f.q) + '</span><span class="accordion__sign" aria-hidden="true"></span></button></h3>' +
        '<div class="accordion__panel" id="faq-' + i + '" role="region" aria-labelledby="faq-' + i + '-btn" hidden><div><p>' + esc(f.a) + "</p></div></div>" +
      "</div>";
    }).join("");
  };

  /* Navegação entre páginas ----------------------------------------- */
  R["next-pages"] = function () {
    var idx = 0;
    PAGES.forEach(function (p, i) { if (p.id === page) idx = i; });
    var prev = PAGES[(idx - 1 + PAGES.length) % PAGES.length];
    var next = PAGES[(idx + 1) % PAGES.length];
    return '<a class="next-link next-link--prev" href="' + prev.href + '"><span class="next-link__dir">' + icon("arrow-left") + "Página anterior</span>" +
        '<span class="next-link__title">' + esc(prev.label) + '</span><span class="next-link__text">' + esc(prev.intro) + "</span></a>" +
      '<a class="next-link next-link--next" href="' + next.href + '"><span class="next-link__dir">Próxima página' + icon("arrow") + "</span>" +
        '<span class="next-link__title">' + esc(next.label) + '</span><span class="next-link__text">' + esc(next.intro) + "</span></a>";
  };

  function renderContent() {
    $all("[data-bind]").forEach(function (el) {
      var v = get(el.getAttribute("data-bind"));
      if (v == null) return;
      if (el.hasAttribute("data-rich")) el.innerHTML = rich(v);
      else el.textContent = v;
    });
    $all("[data-render]").forEach(function (el) {
      var fn = R[el.getAttribute("data-render")];
      if (fn) el.innerHTML = fn();
    });
    $all("[data-demo-note]").forEach(function (el) {
      var v = get(el.getAttribute("data-demo-note"));
      if (v) el.outerHTML = demoNote(v);
      else el.remove();
    });
    // Avaliações reais: esconde avisos de "fictício" específicos da página
    if (C.reviewsAreReal) $all("[data-reviews-demo]").forEach(function (el) { el.hidden = true; });
  }

  /* ------------------------------------------------------------------ */
  /* 3. Fotos                                                            */
  /* ------------------------------------------------------------------ */
  function imageUrl(key, width) {
    var data = C.images[key];
    if (!data) return "";
    if (data.src) return data.src;
    if (!data.id) return "";
    return "https://images.unsplash.com/" + data.id + "?auto=format&fit=crop&w=" + (width || 1000) + "&q=72";
  }

  function prepareFigure(figure) {
    var key = figure.getAttribute("data-img");
    var data = C.images[key] || {};
    if (!figure.querySelector("img")) {
      figure.insertAdjacentHTML("afterbegin",
        '<img alt="" decoding="async"' + (figure.hasAttribute("data-eager") ? ' fetchpriority="high"' : ' loading="lazy"') + ">" +
        '<span class="ph__fallback" aria-hidden="true">' + icon(key === "portrait" ? "user" : "image") + "<span>" + (key === "portrait" ? "Foto do profissional" : "Foto ilustrativa") + "</span></span>");
    }
    var img = figure.querySelector("img");
    img.alt = data.alt || "";
    if (data.position) img.style.objectPosition = data.position;
    return img;
  }

  function fallback(figure, img) {
    figure.classList.remove("is-loaded");
    figure.classList.add("is-fallback");
    figure.setAttribute("role", "img");
    figure.setAttribute("aria-label", (img.alt || "Foto ilustrativa") + " (imagem indisponível)");
    img.setAttribute("aria-hidden", "true");
  }

  function loadFigure(figure) {
    if (figure.getAttribute("data-loading")) return;
    figure.setAttribute("data-loading", "1");
    var img = prepareFigure(figure);
    var src = imageUrl(figure.getAttribute("data-img"), Number(figure.getAttribute("data-w")) || 1000);
    if (!src) return fallback(figure, img);
    var timer = setTimeout(function () {
      if (!img.complete || img.naturalWidth === 0) fallback(figure, img);
    }, 10000);
    img.addEventListener("load", function () {
      clearTimeout(timer);
      if (!img.naturalWidth) return fallback(figure, img);
      figure.classList.remove("is-fallback");
      figure.removeAttribute("role");
      figure.removeAttribute("aria-label");
      img.removeAttribute("aria-hidden");
      figure.classList.add("is-loaded");
    });
    img.addEventListener("error", function () { clearTimeout(timer); fallback(figure, img); });
    img.src = src;
  }

  function initImages() {
    var figures = $all("[data-img]");
    figures.forEach(prepareFigure);
    var lazy = figures.filter(function (f) {
      if (f.hasAttribute("data-eager")) { loadFigure(f); return false; }
      return true;
    });
    if ("IntersectionObserver" in window) {
      var io = new IntersectionObserver(function (entries) {
        entries.forEach(function (e) { if (e.isIntersecting) { io.unobserve(e.target); loadFigure(e.target); } });
      }, { rootMargin: "600px 0px" });
      lazy.forEach(function (f) { io.observe(f); });
    } else {
      lazy.forEach(loadFigure);
    }
  }

  /* ------------------------------------------------------------------ */
  /* Aviso flutuante                                                     */
  /* ------------------------------------------------------------------ */
  var toastEl, toastText, toastTimer;
  function toast(msg, ms) {
    if (!toastEl) {
      document.body.insertAdjacentHTML("beforeend", '<div class="toast" role="status" aria-live="polite">' + icon("info") + "<span></span></div>");
      toastEl = $(".toast");
      toastText = toastEl.querySelector("span");
    }
    toastText.textContent = msg;
    toastEl.classList.add("is-visible");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { toastEl.classList.remove("is-visible"); }, ms || 3200);
  }
  PS.toast = toast;

  /* ------------------------------------------------------------------ */
  /* 4. Botões de contato                                                */
  /* ------------------------------------------------------------------ */
  function fillMessage(template, svc) {
    return String(template || "").replace(/\{nome\}/g, firstName()).replace(/\{servico\}/g, svc || "");
  }

  function initContact() {
    var w = C.contact.whatsapp;
    var number = String(w.number || "").replace(/\D/g, "");
    $all("[data-whatsapp]").forEach(function (link) {
      var svc = link.getAttribute("data-service") || "";
      if (!DEMO && number) {
        link.href = "https://wa.me/" + number + "?text=" + encodeURIComponent(fillMessage(svc ? w.serviceMessage : w.message, svc));
        link.target = "_blank";
        link.rel = "noopener";
        return;
      }
      if (!DEMO) return; // publicado sem número: o link leva à página de contato
      link.addEventListener("click", function (event) {
        event.preventDefault();
        toast("Demonstração: no site publicado, este botão abre o WhatsApp" +
          (svc ? " já com o assunto “" + svc + "”." : " com uma mensagem pronta."), 4200);
      });
    });

    $all("[data-maps]").forEach(function (link) {
      var url = C.contact.mapsUrl;
      if (!url) { link.hidden = true; return; }
      if (!DEMO) { link.href = url; link.target = "_blank"; link.rel = "noopener"; return; }
      link.addEventListener("click", function (event) {
        event.preventDefault();
        toast("Demonstração: no site publicado, este botão abre o endereço no aplicativo de mapas.", 3800);
      });
    });

    $all("[data-wa-status]").forEach(function (el) {
      el.textContent = DEMO
        ? "Modo de demonstração: o botão mostra um aviso em vez de abrir uma conversa real."
        : "O botão abre uma conversa no WhatsApp com uma mensagem pronta.";
    });
  }

  /* ------------------------------------------------------------------ */
  /* 5. Menu móvel e cabeçalho                                           */
  /* ------------------------------------------------------------------ */
  function initMenu() {
    var nav = $("[data-nav]");
    var toggle = $("[data-menu-toggle]");
    var label = $("[data-menu-label]");
    var header = $("[data-header]");
    if (!nav || !toggle || !header) return;

    function setTop() { root.style.setProperty("--nav-top", Math.max(0, header.getBoundingClientRect().bottom) + "px"); }

    function setOpen(open) {
      if (open) setTop();
      nav.classList.toggle("is-open", open);
      root.classList.toggle("menu-open", open);
      toggle.setAttribute("aria-expanded", open ? "true" : "false");
      if (label) label.textContent = open ? "Fechar menu" : "Abrir menu";
    }
    toggle.addEventListener("click", function () { setOpen(!nav.classList.contains("is-open")); });
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape" && nav.classList.contains("is-open")) { setOpen(false); toggle.focus(); }
    });
    document.addEventListener("click", function (e) {
      if (nav.classList.contains("is-open") && !header.contains(e.target)) setOpen(false);
    });
    nav.addEventListener("click", function (e) { if (e.target.closest("a")) setOpen(false); });
    var mq = window.matchMedia("(min-width: 1100px)");
    var onMq = function (m) { if (m.matches) setOpen(false); };
    if (mq.addEventListener) mq.addEventListener("change", onMq); else if (mq.addListener) mq.addListener(onMq);

    document.body.insertAdjacentHTML("beforeend", '<button class="to-top" type="button" aria-label="Voltar ao topo da página">' + icon("arrow-up") + "</button>");
    var toTop = $(".to-top");

    function scrollTop() {
      window.scrollTo({ top: 0, behavior: reduceMotion ? "auto" : "smooth" });
      var brand = $(".hdr .brand");
      if (brand) brand.focus({ preventScroll: true });
    }
    toTop.addEventListener("click", scrollTop);
    $all("[data-to-top-inline]").forEach(function (b) { b.addEventListener("click", scrollTop); });

    var ticking = false;
    function onScroll() {
      var y = window.scrollY || window.pageYOffset;
      header.classList.toggle("is-scrolled", y > 10);
      toTop.classList.toggle("is-visible", y > 900);
      ticking = false;
    }
    window.addEventListener("scroll", function () {
      if (!ticking) { requestAnimationFrame(onScroll); ticking = true; }
    }, { passive: true });
    onScroll();
  }

  /* ------------------------------------------------------------------ */
  /* FAQ                                                                 */
  /* ------------------------------------------------------------------ */
  function initAccordion() {
    $all("[data-accordion]").forEach(function (acc) {
      var triggers = $all(".accordion__trigger", acc);
      function setOpen(t, open) {
        var item = t.closest(".accordion__item");
        var panel = document.getElementById(t.getAttribute("aria-controls"));
        t.setAttribute("aria-expanded", open ? "true" : "false");
        if (open) {
          panel.hidden = false;
          void panel.offsetHeight;
          item.classList.add("is-open");
        } else {
          item.classList.remove("is-open");
          setTimeout(function () { if (!item.classList.contains("is-open")) panel.hidden = true; }, reduceMotion ? 0 : 300);
        }
      }
      triggers.forEach(function (t, i) {
        t.addEventListener("click", function () {
          var willOpen = t.getAttribute("aria-expanded") !== "true";
          triggers.forEach(function (o) { if (o !== t && o.getAttribute("aria-expanded") === "true") setOpen(o, false); });
          setOpen(t, willOpen);
        });
        t.addEventListener("keydown", function (e) {
          var target = null;
          if (e.key === "ArrowDown") target = triggers[(i + 1) % triggers.length];
          if (e.key === "ArrowUp") target = triggers[(i - 1 + triggers.length) % triggers.length];
          if (e.key === "Home") target = triggers[0];
          if (e.key === "End") target = triggers[triggers.length - 1];
          if (target) { e.preventDefault(); target.focus(); }
        });
      });
    });
  }

  /* ------------------------------------------------------------------ */
  /* Galeria: filtros + ampliação                                        */
  /* ------------------------------------------------------------------ */
  function initGallery() {
    var buttons = $all("[data-lightbox-index]");
    if (!buttons.length) return;
    var items = C.clinic.gallery;
    var filters = $all("[data-filter]");
    var status = $("[data-gallery-status]");

    function visibleIndexes() {
      return buttons.filter(function (b) { return !b.closest(".gal__item").hidden; })
        .map(function (b) { return Number(b.getAttribute("data-lightbox-index")); });
    }

    filters.forEach(function (f) {
      f.addEventListener("click", function () {
        var area = f.getAttribute("data-filter");
        filters.forEach(function (o) { o.setAttribute("aria-pressed", o === f ? "true" : "false"); });
        $all(".gal__item").forEach(function (li) {
          li.hidden = !(area === "*" || li.getAttribute("data-area") === area);
          if (!li.hidden) {
            var fg = li.querySelector("[data-img]");
            if (fg && !fg.classList.contains("is-loaded") && !fg.classList.contains("is-fallback")) loadFigure(fg);
          }
        });
        var n = visibleIndexes().length;
        if (status) status.textContent = (area === "*" ? "Mostrando todas as " : "Mostrando ") + n + (n === 1 ? " foto" : " fotos") + (area === "*" ? "." : " de " + area + ".");
      });
    });

    document.body.insertAdjacentHTML("beforeend",
      '<div class="lightbox" role="dialog" aria-modal="true" aria-label="Galeria de fotos do consultório" hidden data-lightbox>' +
        '<div class="lightbox__stage">' +
          '<button class="lightbox__btn lightbox__close" type="button" data-lb-close aria-label="Fechar galeria">' + icon("close") + "</button>" +
          '<figure class="lightbox__figure"><img class="lightbox__img" alt=""><div class="lightbox__fallback"><p>Foto ilustrativa indisponível no momento.</p></div></figure>' +
          '<div class="lightbox__bar">' +
            '<p class="lightbox__caption" aria-live="polite"><strong data-lb-caption></strong><span data-lb-area></span></p>' +
            '<div class="lightbox__controls"><span class="lightbox__count" data-lb-count></span>' +
              '<button class="lightbox__btn" type="button" data-lb-prev aria-label="Foto anterior">' + icon("arrow-left") + "</button>" +
              '<button class="lightbox__btn" type="button" data-lb-next aria-label="Próxima foto">' + icon("arrow") + "</button>" +
            "</div>" +
          "</div>" +
        "</div>" +
      "</div>");

    var lb = $("[data-lightbox]");
    var img = $(".lightbox__img", lb);
    var stage = $(".lightbox__stage", lb);
    var closeBtn = $("[data-lb-close]", lb);
    var order = [];
    var pos = 0;
    var opener = null;
    var hideTimer;

    function show(p) {
      pos = (p + order.length) % order.length;
      var g = items[order[pos]];
      var data = C.images[g.image] || {};
      lb.classList.remove("is-fallback");
      img.onerror = function () { lb.classList.add("is-fallback"); };
      img.onload = function () { if (!img.naturalWidth) lb.classList.add("is-fallback"); };
      var src = imageUrl(g.image, 1800);
      if (!src) lb.classList.add("is-fallback"); else img.src = src;
      img.alt = data.alt || g.caption;
      $("[data-lb-caption]", lb).textContent = g.caption;
      $("[data-lb-area]", lb).textContent = g.area + (DEMO ? ". Foto ilustrativa." : ".");
      $("[data-lb-count]", lb).textContent = (pos + 1) + " de " + order.length;
    }

    function open(i, btn) {
      clearTimeout(hideTimer);
      opener = btn;
      order = visibleIndexes();
      show(Math.max(0, order.indexOf(i)));
      lb.hidden = false;
      void lb.offsetWidth;
      lb.classList.add("is-visible");
      root.classList.add("no-scroll");
      closeBtn.focus();
    }

    function close() {
      if (lb.hidden) return;
      lb.classList.remove("is-visible");
      root.classList.remove("no-scroll");
      hideTimer = setTimeout(function () { lb.hidden = true; }, reduceMotion ? 0 : 280);
      if (opener) opener.focus();
    }

    buttons.forEach(function (b) {
      b.addEventListener("click", function () { open(Number(b.getAttribute("data-lightbox-index")), b); });
    });
    closeBtn.addEventListener("click", close);
    $("[data-lb-prev]", lb).addEventListener("click", function () { show(pos - 1); });
    $("[data-lb-next]", lb).addEventListener("click", function () { show(pos + 1); });

    lb.addEventListener("click", function (e) {
      if (e.target === lb || e.target === stage || e.target.classList.contains("lightbox__figure")) close();
    });

    // Gesto de deslizar no celular
    var touchX = null;
    lb.addEventListener("touchstart", function (e) { touchX = e.touches[0].clientX; }, { passive: true });
    lb.addEventListener("touchend", function (e) {
      if (touchX === null) return;
      var dx = e.changedTouches[0].clientX - touchX;
      if (Math.abs(dx) > 50) show(pos + (dx < 0 ? 1 : -1));
      touchX = null;
    });

    document.addEventListener("keydown", function (e) {
      if (lb.hidden) return;
      if (e.key === "Escape") { e.preventDefault(); close(); }
      if (e.key === "ArrowRight") show(pos + 1);
      if (e.key === "ArrowLeft") show(pos - 1);
      if (e.key === "Tab") {
        var f = $all("button", lb);
        var first = f[0], last = f[f.length - 1];
        if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
        else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
      }
    });
  }

  /* ------------------------------------------------------------------ */
  /* Índice lateral dos serviços                                         */
  /* ------------------------------------------------------------------ */
  function initServiceIndex() {
    var links = $all("[data-svc-link]");
    if (!links.length || !("IntersectionObserver" in window)) return;
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (!en.isIntersecting) return;
        links.forEach(function (a) {
          var on = a.getAttribute("href") === "#" + en.target.id;
          a.classList.toggle("is-active", on);
          if (on) a.setAttribute("aria-current", "location"); else a.removeAttribute("aria-current");
        });
      });
    }, { rootMargin: "-35% 0px -60% 0px" });
    C.services.forEach(function (s) {
      var el = document.getElementById(s.id);
      if (el) io.observe(el);
    });
  }

  /* ------------------------------------------------------------------ */
  /* Revelação ao rolar                                                  */
  /* ------------------------------------------------------------------ */
  function initReveal() {
    var els = $all("[data-reveal]");
    if (!("IntersectionObserver" in window) || reduceMotion) {
      els.forEach(function (el) { el.classList.add("is-visible"); });
      return;
    }
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (!en.isIntersecting) return;
        en.target.classList.add("is-visible");
        io.unobserve(en.target);
      });
    }, { rootMargin: "0px 0px -6% 0px", threshold: 0.04 });
    els.forEach(function (el) { io.observe(el); });
  }

  /* ------------------------------------------------------------------ */
  /* Início                                                              */
  /* ------------------------------------------------------------------ */
  renderChrome();
  renderContent();
  initImages();
  initContact();
  initMenu();
  initAccordion();
  initGallery();
  initServiceIndex();
  initReveal();

  $all("[data-year]").forEach(function (el) { el.textContent = String(new Date().getFullYear()); });

  // Ao chegar por um link com âncora (ex.: servicos.html#calos), posiciona após montar o conteúdo
  if (location.hash) {
    var target = document.getElementById(decodeURIComponent(location.hash.slice(1)));
    if (target) setTimeout(function () { target.scrollIntoView({ behavior: "auto" }); }, 40);
  }

  PS.site = { pages: PAGES, demo: DEMO, toast: toast };
})();
