# Elegance Podologia — modelo intermediário (v2.0)

Site institucional **multipágina** (6 páginas) para podólogos e clínicas de podologia, com identidade editorial própria e um **Ateliê de cores** para o cliente ver a própria marca aplicada em tempo real, em todas as páginas.

O profissional "Rafael Mendes", a marca "Elegance Podologia", os depoimentos, a formação, os números, o endereço e os contatos são **fictícios**.

## Como abrir

Dê dois cliques em `index.html`. Não precisa de servidor, instalação nem etapa de build.
Com internet, carregam as fontes (Google Fonts) e as fotos (Unsplash). Sem internet, o site usa fontes do sistema e quadros nas cores da paleta no lugar das fotos.

## Páginas

| Arquivo | Página | O que tem |
|---|---|---|
| `index.html` | Início | Hero com o profissional, apresentação, serviços em destaque, clínica, diferenciais, etapas, avaliações, chamada para agendar, índice das páginas |
| `sobre.html` | Sobre mim | Apresentação, história, filosofia, linha do tempo, formação, valores e diferenciais |
| `clinica.html` | A clínica | Foto ampla, espaços, galeria com filtros e ampliação, biossegurança, experiência, horários e informações úteis |
| `servicos.html` | Serviços | 6 serviços com descrição, objetivo, como funciona, para quem é indicado, o que saber antes e botão de WhatsApp |
| `avaliacoes.html` | Avaliações | Depoimento em destaque, mosaico de relatos e espaço preparado para avaliações reais |
| `contato.html` | Contato | WhatsApp, telefone, e-mail, endereço, horários, redes sociais, mapa e perguntas frequentes |

## Estrutura

```
elegance/
├── index.html, sobre.html, clinica.html, servicos.html, avaliacoes.html, contato.html
├── README.md · RELATORIO.md
├── assets/img/            Fotos próprias do cliente (veja LEIA-ME.txt)
├── css/
│   ├── elegance.css       Tokens, tipografia, botões, cabeçalho, rodapé, FAQ, galeria ampliada, avisos
│   ├── pages.css          Composição de cada página
│   └── customizer.css     Visual neutro do Ateliê de cores
└── js/
    ├── content.js         ★ TODO o conteúdo e as opções de publicação (editar aqui)
    ├── palettes.js        As 9 paletas
    ├── color-utils.js     Contraste (WCAG) e mistura de cores
    ├── theme.js           Motor de cores: aplica a paleta e guarda a escolha entre páginas
    ├── elegance.js        Cabeçalho, rodapé, conteúdo, fotos, contato, menu, FAQ, galeria
    └── customizer.js      Ateliê de cores (paletas, ajuste fino, legibilidade)
```

## Adaptar para um cliente real (passo a passo)

1. **`js/content.js`**: troque marca (`brand`), profissional (`professional`), contato (`contact`: WhatsApp, telefone, e-mail, endereço, mapa, horários, redes sociais), textos de cada página (`home`, `about`, `clinic`, `contactPage`), serviços (`services`), perguntas frequentes (`faq`) e fotos (`images`). Textos entre `*asteriscos*` aparecem em itálico na cor de destaque.
2. **Fotos**: coloque os arquivos em `assets/img/` e troque `id` por `src` em `images` (ex.: `portrait: { src: "assets/img/retrato.jpg", alt: "..." }`).
3. **Depoimentos**: use apenas relatos reais e autorizados. Depois, troque `reviewsAreReal` para `true` (somem os avisos "exemplo de demonstração").
4. **Cores**: escolha no Ateliê e então use "Copiar CSS" (cole no bloco de tokens de `css/elegance.css`) **ou** "Copiar paleta" (cole em `js/palettes.js` e coloque o `id` em `theme.defaultPalette`).
5. **`<head>` de cada página**: edite `<title>` e `<meta name="description">`. Prévias de link no WhatsApp e no Google não leem o `content.js`.
6. **Mapa**: cole o endereço "src" do mapa incorporado do Google Maps em `contact.mapEmbedUrl` e o link normal em `contact.mapsUrl`.

## Publicar

No `content.js`:

```js
site: {
  demoMode: false,          // botões abrem WhatsApp, telefone, e-mail e mapa de verdade; avisos "demonstrativo" somem
  studio: {
    showBar: false,         // tira a faixa escura "Modelo Elegance"
    showCustomizer: false,  // tira o Ateliê de cores (e ignora cores salvas no navegador)
    showTemplateNote: false // tira a faixa "Este site é um modelo"
  }
}
```

Remova também `<meta name="robots" content="noindex">` das seis páginas.

## Ateliê de cores

- 9 paletas: Azul-Petróleo (original), Azul-Marinho, Verde-Escuro, Bordô, Grafite & Cobre, Areia & Chocolate, Cinza & Azul, Preto & Champagne, Verde-Esmeralda.
- Ajuste de 5 cores (principal, secundária, destaque, fundo, texto) com seletor visual, campo HEX editável e botão para restaurar cada cor.
- Avisos de correção automática quando uma cor prejudica a leitura, e aba de legibilidade com 6 verificações WCAG AA.
- Restaurar paleta, configuração original, copiar CSS e copiar paleta.
- A escolha vale para as 6 páginas e fica salva no navegador (com reserva via `window.name` quando o armazenamento está bloqueado). O painel lembra se estava aberto e em qual aba.
- Desktop: painel flutuante. Celular: folha inferior com modo minimizado (só a faixa de paletas).
